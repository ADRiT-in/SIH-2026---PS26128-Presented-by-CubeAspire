export type AIMode = "chat" | "tip" | "care" | "vetdraft";

export interface AIMessageInput {
  role: "user" | "assistant";
  content: string;
}

export interface AIRequest {
  messages: AIMessageInput[];
  image?: string;
  lang?: "en" | "hi" | "auto";
  mode?: AIMode;
  seed?: string;
  context?: string;
  // Hint from the app's real connectivity / toggle state.
  appMode?: "online" | "offline";
}

export interface AIResult {
  reply: string;
  source: "live" | "local";
  model?: string;
  grounded?: boolean;
  limitedMode?: boolean;
  requestId?: string;
}

interface AIClientOptions {
  attempts?: number;
  timeoutMs?: number;
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Shared resilient client used by every VETTO AI surface.
 * The API itself has provider + model failover; this retries transport failures only.
 */
export async function requestAI(
  payload: AIRequest,
  options: AIClientOptions = {}
): Promise<AIResult> {
  const attempts = Math.max(1, options.attempts ?? 2);
  const timeoutMs = Math.max(8000, options.timeoutMs ?? 42000);
  let lastError: Error = new Error("AI service unavailable");

  for (let attempt = 0; attempt < attempts; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Vetto-AI-Client": "web-v1",
        },
        body: JSON.stringify(payload),
        signal: ctrl.signal,
        cache: "no-store",
      });

      const data = (await res.json().catch(() => null)) as Partial<AIResult> | null;
      const reply = typeof data?.reply === "string" ? data.reply.trim() : "";
      if (res.ok && reply.length >= 2) {
        return {
          reply,
          source: data?.source === "live" ? "live" : "local",
          model: data?.model,
          grounded: Boolean(data?.grounded),
          limitedMode: Boolean(data?.limitedMode),
          requestId: data?.requestId,
        };
      }
      lastError = new Error(`AI request failed (${res.status})`);
    } catch (err) {
      lastError = err instanceof Error ? err : new Error("AI transport failed");
    } finally {
      clearTimeout(timer);
    }

    if (attempt + 1 < attempts) {
      await wait(450 * 2 ** attempt + Math.floor(Math.random() * 250));
    }
  }

  throw lastError;
}
