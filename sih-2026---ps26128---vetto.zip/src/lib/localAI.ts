/**
 * Offline knowledge engine for Vetto AI.
 * Runs fully on-device. Deliberately limited: text questions only,
 * basic husbandry guidance, no image/voice analysis and no deep research.
 * Online mode uses the real model via /api/ai.
 */

export type LocalLang = "en" | "hi";

interface Topic {
  test: RegExp;
  en: string[];
  hi: string[];
}

const TOPICS: Topic[] = [
  {
    test: /fever|बुखार|ताप|गर्म/i,
    en: [
      "**Possible fever**\nYou mentioned the animal feels warm. Until a vet sees it:\n- Move it to cool shade and offer <u>clean water</u> freely\n- Offer soft green fodder; never force-feed\n- Note if it is still chewing cud\nIf it also stops drinking, call <u>1962</u>. *Connect to the internet for a deeper check.*",
      "**Warm body — first steps**\n- Wipe the body with a wet cloth for <u>10 minutes</u>\n- Keep it away from direct sun\n- Watch nose, dung and milk for changes\nFever plus no eating for <u>2 days</u> needs a vet visit. What else have you noticed?",
    ],
    hi: [
      "**संभावित बुखार**\nआपने बताया कि पशु गर्म लग रहा है। डॉक्टर को दिखाने तक:\n- ठंडी छाँव में रखें और <u>साफ़ पानी</u> खुला रखें\n- नरम हरा चारा दें; ज़बरदस्ती न खिलाएँ\n- देखें कि जुगाली कर रहा है या नहीं\nपानी भी पीना बंद कर दे तो <u>1962</u> पर कॉल करें। *गहरी जाँच के लिए इंटरनेट से जुड़ें।*",
      "**शरीर गर्म — पहले कदम**\n- गीले कपड़े से <u>10 मिनट</u> शरीर पोंछें\n- सीधी धूप से दूर रखें\n- नाक, गोबर और दूध में बदलाव देखें\nबुखार के साथ <u>2 दिन</u> से भूख न लगे तो डॉक्टर ज़रूरी। और क्या दिख रहा है?",
    ],
  },
  {
    test: /milk|दूध|दुध/i,
    en: [
      "**Milk has dropped**\nMost common causes are feed, water, heat and stress.\n- Increase green fodder by <u>15-20%</u>\n- Clean water <u>4-5 times</u> a day\n- Keep milking time fixed\nIf the udder is hot or hard, that points to *mastitis* — see a vet. Is the udder normal?",
      "**Checking a milk drop**\n- Any feed change in the last week?\n- Is she in heat or newly pregnant?\n- Water always available?\nFix these three first; most drops recover in <u>5-7 days</u>. Which one changed recently?",
    ],
    hi: [
      "**दूध कम हो गया**\nसबसे आम कारण हैं चारा, पानी, गर्मी और तनाव।\n- हरा चारा <u>15-20%</u> बढ़ाएँ\n- दिन में <u>4-5 बार</u> साफ़ पानी\n- दुहाई का समय तय रखें\nथन गर्म या सख्त हो तो यह *थनैला* हो सकता है — डॉक्टर दिखाएँ। थन ठीक है?",
      "**दूध घटने की जाँच**\n- पिछले हफ़्ते चारा बदला?\n- गरमी में है या नई गाभन?\n- पानी हमेशा उपलब्ध?\nपहले ये तीन ठीक करें; ज़्यादातर मामले <u>5-7 दिन</u> में सुधरते हैं। हाल में क्या बदला?",
    ],
  },
  {
    test: /\b(?:eat|eating|eats|eaten)\b|khana|खाना|खाती|खा रह|भूख/i,
    en: [
      "**Not eating**\nMore than a day without feed is an early warning.\n- Smell the feed — throw away anything mouldy\n- Offer jaggery water or a salt lick\n- Check the mouth for ulcers or wounds\nNot eating *and* not chewing cud = vet today. Is it chewing cud?",
      "**Appetite gone — quick checks**\n- Fresh feed and clean water in front of it?\n- Any swelling on the left belly?\n- Dung normal or hard?\nTell me what you see and I'll narrow it down.",
    ],
    hi: [
      "**खाना नहीं खा रहा**\nएक दिन से ज़्यादा चारा न खाना शुरुआती चेतावनी है।\n- चारा सूँघें — फफूंदी वाला तुरंत हटाएँ\n- गुड़ का पानी या नमक चटाने दें\n- मुँह में छाले या घाव देखें\nखाना बंद *और* जुगाली बंद = आज ही डॉक्टर। जुगाली कर रहा है?",
      "**भूख गायब — झटपट जाँच**\n- सामने ताज़ा चारा और साफ़ पानी है?\n- बाएँ पेट में सूजन?\n- गोबर सामान्य या सख्त?\nजो दिखे बताइए, मैं और सटीक बताऊँगा।",
    ],
  },
  {
    test: /diarr|loose|दस्त|पतला/i,
    en: [
      "**Loose motion**\nDehydration is the real danger here.\n- Home ORS: <u>1 litre water + 6 tsp sugar + ½ tsp salt</u>, give <u>3-4 times</u> daily\n- Stop green fodder for <u>12 hours</u>, give dry hay\n- Keep the animal warm and on dry bedding\nBlood in dung = urgent vet. Any blood?",
      "**Managing scours**\n- Fluids first, medicine later\n- Separate from the herd to stop spread\n- Clean the floor and change bedding today\nHow many days has this been going on?",
    ],
    hi: [
      "**दस्त लगना**\nअसली ख़तरा शरीर में पानी की कमी है।\n- घर का ORS: <u>1 लीटर पानी + 6 चम्मच चीनी + ½ चम्मच नमक</u>, दिन में <u>3-4 बार</u>\n- <u>12 घंटे</u> हरा चारा बंद, सूखा घास दें\n- पशु को गर्म और सूखी बिछावनी पर रखें\nगोबर में खून हो तो तुरंत डॉक्टर। खून है?",
      "**दस्त संभालना**\n- पहले तरल, दवा बाद में\n- फैलाव रोकने के लिए झुंड से अलग करें\n- आज ही फ़र्श साफ़ करें और बिछावनी बदलें\nकितने दिनों से हो रहा है?",
    ],
  },
  {
    test: /vaccin|टीका|tika/i,
    en: [
      "**Vaccination basics**\n- FMD every <u>6 months</u> (free in govt. camps)\n- HS and BQ before monsoon for cattle\n- PPR yearly for goats and sheep\nAsk at <u>1962</u> for the next free camp near you. Which animal is this for?",
      "**Keeping the schedule**\nWrite every date in the app's Vaccinations section — it will remind you.\n- Never vaccinate a sick or very weak animal\n- Vaccinate the whole herd on the same day\nWhen was the last one given?",
    ],
    hi: [
      "**टीकाकरण की मूल बातें**\n- खुरपका-मुँहपका हर <u>6 माह</u> (सरकारी शिविर में नि:शुल्क)\n- गाय-भैंस को बारिश से पहले HS और BQ\n- बकरी-भेड़ को हर वर्ष PPR\nपास के नि:शुल्क शिविर के लिए <u>1962</u> पर पूछें। किस पशु के लिए?",
      "**समय-सारणी बनाए रखें**\nहर तारीख ऐप के टीकाकरण सेक्शन में लिखें — वह याद दिला देगा।\n- बीमार या बहुत कमज़ोर पशु को टीका न लगाएँ\n- पूरे झुंड को एक ही दिन टीका दें\nपिछला टीका कब लगा था?",
    ],
  },
  {
    test: /wound|injur|cut|घाव|चोट|खून/i,
    en: [
      "**Wound care**\n- Wash gently with clean water for <u>5 minutes</u>\n- Press a clean cloth to stop bleeding\n- Keep flies off; cover loosely\nDeep cuts, non-stop bleeding or maggots need a vet today. How big is it?",
      "**Keeping a wound clean**\n- Flush twice daily with plain clean water\n- Keep the animal out of mud and dung\n- Check daily for swelling or smell\n*Online mode lets me examine a photo of the wound.*",
    ],
    hi: [
      "**घाव की देखभाल**\n- साफ़ पानी से <u>5 मिनट</u> धीरे-धीरे धोएँ\n- खून रोकने के लिए साफ़ कपड़ा दबाएँ\n- मक्खियाँ दूर रखें; ढीला ढकें\nगहरा कटाव, न रुकने वाला खून या कीड़े = आज ही डॉक्टर। कितना बड़ा है?",
      "**घाव साफ़ रखना**\n- दिन में दो बार साफ़ पानी से धोएँ\n- पशु को कीचड़ और गोबर से दूर रखें\n- रोज़ सूजन या बदबू देखें\n*ऑनलाइन मोड में मैं घाव की फोटो देख सकता हूँ।*",
    ],
  },
  {
    test: /bloat|gas|अफ़ारा|अफारा|फूला/i,
    en: [
      "**Bloat — act fast**\nLeft belly tight like a drum is an emergency.\n- Walk the animal slowly\n- Rub the left flank hard\n- <u>50-100 ml</u> edible oil can help mild cases\nBreathing hard or unable to stand = vet NOW, <u>1962</u>. Is the left side drum-tight?",
    ],
    hi: [
      "**अफ़ारा — तुरंत करें**\nबायाँ पेट ढोल जैसा सख्त होना आपातकाल है।\n- पशु को धीरे-धीरे चलाएँ\n- बाएँ पेट को ज़ोर से रगड़ें\n- हल्के मामलों में <u>50-100 मिली</u> खाद्य तेल\nसांस भारी या खड़ा न हो = अभी डॉक्टर, <u>1962</u>। बायाँ पेट सख्त है?",
    ],
  },
  {
    test: /udder|mastit|थन|थनैला/i,
    en: [
      "**Udder trouble**\nHot, hard or painful udder suggests *mastitis*.\n- Milk out fully every <u>4-6 hours</u>\n- Hot fomentation <u>10 minutes</u>, 3 times daily\n- Milk the affected quarter last\nClots in milk or fever need a vet — antibiotics have a milk-discard period. Is the milk changed?",
    ],
    hi: [
      "**थन की समस्या**\nगर्म, सख्त या दर्दनाक थन *थनैला* का संकेत है।\n- हर <u>4-6 घंटे</u> में दूध पूरा निकालें\n- गर्म सिंकाई <u>10 मिनट</u>, दिन में 3 बार\n- पीड़ित थन सबसे आख़िर में दुहें\nदूध में गांठ या बुखार हो तो डॉक्टर — एंटीबायोटिक के बाद दूध कुछ दिन नहीं बेचा जाता। दूध बदला है?",
    ],
  },
  {
    test: /feed|fodder|चारा|दाना|khurak/i,
    en: [
      "**Feeding guide**\nA cow needs dry matter of about <u>2.5-3%</u> of body weight daily.\n- For a 400 kg cow: <u>10-12 kg</u> dry feed\n- About <u>1 kg</u> concentrate per <u>2.5 litres</u> of milk\n- Always <u>50 g</u> mineral mixture\nChange any feed gradually over <u>7 days</u>. What is your animal's weight?",
    ],
    hi: [
      "**चारा मार्गदर्शन**\nगाय को रोज़ शरीर के वज़न का लगभग <u>2.5-3%</u> शुष्क चारा चाहिए।\n- 400 किलो की गाय: <u>10-12 किलो</u> शुष्क चारा\n- लगभग <u>2.5 लीटर</u> दूध पर <u>1 किलो</u> दाना\n- हमेशा <u>50 ग्राम</u> खनिज मिश्रण\nचारा <u>7 दिन</u> में धीरे-धीरे बदलें। पशु का वज़न कितना है?",
    ],
  },
  {
    test: /calf|बछड़ा|बछिया|मेमना/i,
    en: [
      "**Young animal care**\nThe first <u>60 days</u> decide lifetime production.\n- Colostrum within <u>2 hours</u> of birth\n- Dip the navel in iodine\n- Starter feed from week <u>3</u>, deworm at <u>3 months</u>\nHow old is the calf?",
    ],
    hi: [
      "**छोटे पशु की देखभाल**\nपहले <u>60 दिन</u> पूरी ज़िंदगी का उत्पादन तय करते हैं।\n- जन्म के <u>2 घंटे</u> में खीस\n- नाभि में आयोडीन लगाएँ\n- <u>3</u>रे हफ़्ते से स्टार्टर दाना, <u>3 माह</u> पर कृमिनाशक\nबछड़ा कितने दिन का है?",
    ],
  },
  {
    test: /hen|poultry|murgi|मुर्गी|चूज़ा|अंडा/i,
    en: [
      "**Poultry basics**\n- Chicks need <u>33°C</u> in week 1, dropping weekly\n- Clean water available <u>24 hours</u>\n- Ranikhet and Gumboro vaccines on schedule\nSudden deaths mean isolate the flock and call <u>1962</u>. How old is the flock?",
    ],
    hi: [
      "**मुर्गीपालन की मूल बातें**\n- चूज़ों को पहले हफ़्ते <u>33°C</u>, फिर हर हफ़्ते कम\n- <u>24 घंटे</u> साफ़ पानी उपलब्ध\n- रानीखेत और गुम्बोरो टीके समय पर\nअचानक मौतें हों तो झुंड अलग करें और <u>1962</u> पर कॉल करें। झुंड की उम्र?",
    ],
  },
  {
    test: /goat|bakri|बकरी|भेड़|sheep/i,
    en: [
      "**Goat & sheep care**\n- Dry floors matter more than fancy sheds\n- Deworm every <u>4 months</u> in the rainy season\n- PPR vaccine yearly, free in govt. camps\n- Keep a mineral lick always available\nWhat would you like to know about them?",
    ],
    hi: [
      "**बकरी व भेड़ की देखभाल**\n- महँगे शेड से ज़्यादा ज़रूरी है सूखा फ़र्श\n- बारिश में हर <u>4 माह</u> कृमिनाशक\n- हर वर्ष PPR टीका, सरकारी शिविर में नि:शुल्क\n- नमक की चट्टा हमेशा उपलब्ध रखें\nइनके बारे में क्या जानना चाहते हैं?",
    ],
  },
];

const GENERIC: Record<LocalLang, string[]> = {
  en: [
    "**I'm in offline mode**\nI can still give basic guidance from memory. Watch the *three daily signals* — eating, cud-chewing and dung. A change in any two for over a day means call a vet (<u>1962</u>, free).\nTell me the animal and what you're seeing.",
    "**Basic help, offline**\nDescribe the animal and the symptom in a few words — for example *\"goat not eating since yesterday\"* — and I'll give first-aid steps. For photo checks and detailed research, turn on the internet.",
    "**Offline guidance**\nMost health problems trace back to four things: <u>clean water</u>, <u>dry shelter</u>, <u>balanced feed</u> and <u>timely vaccines</u>. Which of these would you like help with?",
  ],
  hi: [
    "**मैं ऑफलाइन मोड में हूँ**\nफिर भी याद से बुनियादी सलाह दे सकता हूँ। *रोज़ के तीन संकेत* देखें — खाना, जुगाली और गोबर। कोई दो एक दिन से ज़्यादा बदलें तो डॉक्टर बुलाएँ (<u>1962</u>, नि:शुल्क)।\nपशु और जो दिख रहा है, वह बताइए।",
    "**बुनियादी मदद, ऑफलाइन**\nपशु और लक्षण कुछ शब्दों में लिखें — जैसे *\"बकरी कल से खाना नहीं खा रही\"* — मैं प्राथमिक उपचार बताऊँगा। फोटो जाँच और गहरी रिसर्च के लिए इंटरनेट चालू करें।",
    "**ऑफलाइन मार्गदर्शन**\nज़्यादातर बीमारियाँ चार बातों से जुड़ी हैं: <u>साफ़ पानी</u>, <u>सूखा आश्रय</u>, <u>संतुलित चारा</u> और <u>समय पर टीके</u>। इनमें से किसमें मदद चाहिए?",
  ],
};


/** Short, ambiguous words that must match as whole words (e.g. "ram" vs "programming"). */
const LIVESTOCK_EXACT = [
  "cow", "cows", "cattle", "calf", "calves", "bull", "bulls", "bullock", "ox", "oxen",
  "buffalo", "buffaloes", "goat", "goats", "kid", "kids", "sheep", "lamb", "lambs",
  "ewe", "ewes", "ram", "rams", "pig", "pigs", "piglet", "piglets", "swine", "boar",
  "hen", "hens", "chicken", "chickens", "chick", "chicks", "poultry", "broiler", "layer",
  "duck", "ducks", "rooster", "bird", "birds", "flock", "herd", "horse", "mare",
  "donkey", "camel", "livestock", "animal", "animals", "barn", "shed", "dairy", "farm",
  "farmer", "vet", "egg", "eggs", "wool", "milk", "udder", "teat", "dung", "manure",
  "cud", "hoof", "hooves", "feed", "fodder", "hay", "silage", "graze", "grazing",
  "calving", "colostrum", "semen", "rumen", "lame", "limp", "bloat", "mastitis",
  "deworm", "worms", "tick", "ticks", "lice", "mange", "scour", "scours", "rabies",
  "anthrax", "fmd", "ppr", "ranikhet", "gumboro", "brucellosis",
];

/** Longer or prefix-style terms that are safe to match from the start of a word. */
const LIVESTOCK_PREFIX = [
  "vaccin", "veterinar", "diarr", "deworm", "dewrom", "worm", "rumina", "lactat", "pregnan", "breeding", "insemina",
  "parasit", "infect", "symptom", "disease", "illness", "treatment", "medicine",
  "appetite", "mineral", "kidding", "lambing", "foot rot", "loose motion", "salt lick",
  "not eating", "weight gain",
];

const LIVESTOCK_HINDI =
  /पशु|गाय|भैंस|बकरी|भेड़|मुर्ग|बछड़|बछिया|बैल|सूअर|बत्तख|घोड़|गधा|दूध|थन|थनैला|चारा|दाना|भूसा|टीक|कृमि|कीड़|बीमार|बीमारी|रोग|बुखार|दस्त|अफ़ारा|अफारा|घाव|चोट|खून|जुगाली|भूख|गोबर|खुर|लंगड़|गाभन|व्याई|प्रसव|खीस|पशुपालन|डेयरी|चिकित्सक|अंडा|झुंड|नस्ल/;

const LIVESTOCK_EXACT_RE = new RegExp(`\\b(?:${LIVESTOCK_EXACT.join("|")})\\b`, "i");
const LIVESTOCK_PREFIX_RE = new RegExp(`\\b(?:${LIVESTOCK_PREFIX.join("|")})`, "i");

/** True when an offline question can be answered from on-device livestock knowledge. */
export function isLivestockQuestion(text: string): boolean {
  const clean = (text || "").trim();
  if (!clean) return false;
  if (LIVESTOCK_EXACT_RE.test(clean)) return true;
  if (LIVESTOCK_PREFIX_RE.test(clean)) return true;
  if (LIVESTOCK_HINDI.test(clean)) return true;
  // Short follow-ups inside an ongoing livestock conversation stay allowed.
  return clean.split(/\s+/).length <= 3 && /^(yes|no|ok|haan|nahi|हाँ|नहीं|ठीक)/i.test(clean);
}

/** Clear, respectful explanation when an off-topic question arrives offline. */
export function offlineOffTopicReply(question: string, lang: LocalLang): string {
  const topic = (question || "").trim().slice(0, 60);
  if (lang === "hi") {
    return [
      "**यह सवाल ऑफलाइन में नहीं हो पाएगा**",
      topic ? `आपने पूछा: *“${topic}”*` : "",
      "अभी इंटरनेट बंद है, इसलिए मेरे पास केवल फोन में सहेजा हुआ **पशु-स्वास्थ्य ज्ञान** है। इस विषय से बाहर के सवालों के लिए मुझे ऑनलाइन मॉडल चाहिए — बिना उसके मैं अंदाज़ा लगाकर गलत जवाब नहीं दूँगा।",
      "",
      "**अभी मैं इनमें मदद कर सकता हूँ:**",
      "- बीमारी के लक्षण — बुखार, दस्त, अफ़ारा, थनैला, घाव",
      "- दूध कम होना, भूख या जुगाली बंद होना",
      "- टीकाकरण, कृमिनाशक और चारे की सलाह",
      "",
      "**पूरा जवाब पाने के लिए:** ऊपर दिया ऑनलाइन बटन दबाएँ या Wi-Fi / मोबाइल डेटा चालू करें — फिर यही सवाल दोबारा भेजें।",
    ]
      .filter(Boolean)
      .join("\n");
  }
  return [
    "**I cannot answer this one offline**",
    topic ? `You asked: *“${topic}”*` : "",
    "You are offline right now, so I only have the **livestock health knowledge stored on your phone**. Anything outside that needs the online model, and I will not guess and give you a wrong answer.",
    "",
    "**What I can still help with right now:**",
    "- Illness signs — fever, diarrhoea, bloat, mastitis, wounds",
    "- Milk drop, loss of appetite, or an animal that stopped chewing cud",
    "- Vaccination, deworming and feeding guidance",
    "",
    "**To get the full answer:** switch the online button at the top, or turn on Wi-Fi / mobile data, then send this same question again.",
  ]
    .filter(Boolean)
    .join("\n");
}

function pickFreshText(arr: string[], usedTexts: string[]): string {
  const used = new Set(usedTexts.map((u) => u.trim().slice(0, 50)));
  const unused = arr.filter((a) => !used.has(a.trim().slice(0, 50)));
  const pool = unused.length > 0 ? unused : arr;
  return pool[Math.floor(Math.random() * pool.length)];
}

function num(value: string): number {
  return Number(value.replace(/,/g, ""));
}

function fmtCurrency(n: number, lang: LocalLang): string {
  const fixed = Math.round((n + Number.EPSILON) * 100) / 100;
  return new Intl.NumberFormat(lang === "hi" ? "en-IN" : "en-IN", {
    maximumFractionDigits: fixed % 1 === 0 ? 0 : 2,
    minimumFractionDigits: fixed % 1 === 0 ? 0 : 2,
  }).format(fixed);
}

function extractTopic(text: string): string {
  const clean = text.trim().replace(/[?.!।]+$/g, "");
  // English: "about X", "on X", "for X", "regarding X"
  const en = clean.match(/(?:about|on|regarding|for|of)\s+(.+)$/i);
  if (en) return en[1].trim().slice(0, 60);
  // Hindi: "X पर", "X के बारे में", "X की कविता"
  // "X पर ... लिखिए" or "X की कविता"
  const hi = clean.match(/^(.+?)\s+(?:पर|के बारे में)\s+(?:एक |छोटी |सरल )*(?:लिखिए|लिखें|बताइए|समझाएँ|बनाइए|जानकारी|कविता)/i)
    || clean.match(/^(.+?)\s+की\s+(?:एक |छोटी |सरल )*(?:कविता|जानकारी)/i);
  if (hi) return hi[1].trim().slice(0, 60);
  // Strip common command words and clean up
  return clean
    .replace(/^(?:write|explain|create|make|give|tell me|बताइए|लिखिए|लिखें|बनाइए|describe)\s+/i, "")
    .replace(/^(?:a |an |the |one |short )\s*/i, "")
    .trim()
    .slice(0, 60);
}

// ─────────────────────────────────────────────────────────────────────────────
// DEEP REASONING ENGINE — general questions
// Used when the live API is unavailable (rate-limited / no credits).
// Covers maths, agriculture, education, government, health basics, writing tasks,
// science, technology, finance and everyday Indian life questions.
// Word-by-word analysis → topic detection → structured, varied answer.
// ─────────────────────────────────────────────────────────────────────────────

function capitalize(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function titleCase(s: string): string {
  return s.split(/\s+/).map(w => capitalize(w.toLowerCase())).join(" ");
}

// ---- arithmetic solver ----
function tryMath(q: string, lang: LocalLang): string | null {
  const lower = q.toLowerCase();

  // percentage of
  const pof = lower.match(/(\d+(?:\.\d+)?)\s*%\s*of\s*(\d[\d,]*(?:\.\d+)?)/i);
  if (pof) {
    const p = num(pof[1]), base = num(pof[2]), out = Math.round((p/100)*base*100)/100;
    return lang === "hi"
      ? `**गणना — ${p}% of ${fmtCurrency(base, lang)}**\n\n${p}% of ${fmtCurrency(base, lang)} = **<u>${fmtCurrency(out, lang)}</u>**\n\n*कैसे:*\n- ${fmtCurrency(base, lang)} को 100 से भाग दें = ${fmtCurrency(base/100, lang)}\n- फिर ${p} से गुणा करें = **${fmtCurrency(out, lang)}**\n\nक्या इसी तरह कोई और हिसाब लगाना है?`
      : `**Calculation — ${p}% of ${fmtCurrency(base, lang)}**\n\n${p}% of ${fmtCurrency(base, lang)} = **<u>${fmtCurrency(out, lang)}</u>**\n\n*How:*\n- Divide ${fmtCurrency(base, lang)} by 100 → ${fmtCurrency(base/100, lang)}\n- Multiply by ${p} → **${fmtCurrency(out, lang)}**\n\nNeed another calculation?`;
  }

  // discount
  const disc = lower.match(/(\d[\d,]*)\s*(?:rupees?|rs|₹)?\s*(?:each|per)?\s*(?:with|after|minus|@|at)?\s*(\d+(?:\.\d+)?)\s*%\s*(?:discount|off)/i)
    || lower.match(/discount.*?(\d+(?:\.\d+)?)\s*%.*?(\d[\d,]*)/i);
  if (disc) {
    const [, a, b] = disc;
    const [price, pct] = [num(a), num(b)].sort((x,y) => y-x);
    if (price > 0 && pct > 0 && pct < 100) {
      const saved = Math.round(price * pct) / 100;
      const pay = price - saved;
      return lang === "hi"
        ? `**छूट की गणना**\n\n| मद | राशि |\n|---|---|\n| मूल मूल्य | ₹${fmtCurrency(price, lang)} |\n| छूट (${pct}%) | ₹${fmtCurrency(saved, lang)} |\n| **अंतिम भुगतान** | **₹${fmtCurrency(pay, lang)}** |\n\n*जाँच:* ${fmtCurrency(price, lang)} × (1 − ${pct/100}) = ${fmtCurrency(pay, lang)} ✓`
        : `**Discount calculation**\n\n| Item | Amount |\n|---|---|\n| Original price | ₹${fmtCurrency(price, lang)} |\n| Discount (${pct}%) | ₹${fmtCurrency(saved, lang)} |\n| **Net payable** | **₹${fmtCurrency(pay, lang)}** |\n\n*Verify:* ${fmtCurrency(price, lang)} × (1 − ${pct/100}) = ${fmtCurrency(pay, lang)} ✓`;
    }
  }

  // product × qty → total (optionally with discount)
  const prod = lower.match(/(\d+)\s*(?:bags?|items?|pieces?|units?|kg|litre|liter)?\s*(?:at|for|@|×|x)?\s*₹?\s*(\d[\d,]*(?:\.\d+)?)\s*(?:rupees?|rs|₹|each)?(?:.*?(\d+(?:\.\d+)?)\s*%\s*(?:discount|off))?/i);
  if (prod && prod[1] && prod[2]) {
    const qty = num(prod[1]), price = num(prod[2]);
    if (qty >= 1 && qty <= 10000 && price >= 1) {
      const total = qty * price;
      if (prod[3]) {
        const discPct = num(prod[3]);
        const saved = Math.round(total * discPct) / 100;
        const net = total - saved;
        return lang === "hi"
          ? `**खरीद का हिसाब**\n\n- ${qty} × ₹${fmtCurrency(price, lang)} = **₹${fmtCurrency(total, lang)}**\n- छूट ${discPct}% = ₹${fmtCurrency(saved, lang)}\n- **कुल देय = ₹${fmtCurrency(net, lang)}**`
          : `**Purchase calculation**\n\n- ${qty} × ₹${fmtCurrency(price, lang)} = **₹${fmtCurrency(total, lang)}**\n- Discount ${discPct}% = ₹${fmtCurrency(saved, lang)}\n- **Total payable = ₹${fmtCurrency(net, lang)}**`;
      }
      return lang === "hi"
        ? `**कुल लागत**\n\n${qty} × ₹${fmtCurrency(price, lang)} = **<u>₹${fmtCurrency(total, lang)}</u>**\n\nकोई छूट है? बताइए — मैं तुरंत निकाल दूँगा।`
        : `**Total cost**\n\n${qty} × ₹${fmtCurrency(price, lang)} = **<u>₹${fmtCurrency(total, lang)}</u>**\n\nIs there a discount? Tell me and I will calculate right away.`;
    }
  }

  // simple expression like "what is 30000 - 8000"
  const simpleCalc = lower.match(/(?:what is|calculate|compute)?\s*(\d[\d,]*)\s*([\+\-\*×x\/÷])\s*(\d[\d,]*)/i);
  if (simpleCalc) {
    const a = num(simpleCalc[1]), op = simpleCalc[2], b = num(simpleCalc[3]);
    let result: number;
    let opLabel: string;
    if (/[\+]/.test(op)) { result = a + b; opLabel = "+"; }
    else if (/[\-]/.test(op)) { result = a - b; opLabel = "−"; }
    else if (/[\*×xX]/.test(op)) { result = a * b; opLabel = "×"; }
    else if (/[\/÷]/.test(op)) { if (b === 0) return null; result = Math.round((a/b)*1000)/1000; opLabel = "÷"; }
    else return null;
    return lang === "hi"
      ? `**${fmtCurrency(a, lang)} ${opLabel} ${fmtCurrency(b, lang)} = <u>${fmtCurrency(result!, lang)}</u>**\n\nकोई और हिसाब?`
      : `**${fmtCurrency(a, lang)} ${opLabel} ${fmtCurrency(b, lang)} = <u>${fmtCurrency(result!, lang)}</u>**\n\nAnother calculation?`;
  }

  return null;
}

// ---- budget planner ----
function tryBudget(q: string, lang: LocalLang): string | null {
  if (!/budget|income|salary|earning|rent|monthly plan|खर्च|बजट|कमाई|तनख्वाह/i.test(q)) return null;
  const incM = q.match(/(?:income|earning|earn|salary|कमाई|तनख्वाह)[^\d]{0,25}(\d[\d,]*)/i);
  const rentM = q.match(/rent[^\d]{0,15}(\d[\d,]*)/i);
  const moneyNums = (q.match(/\d[\d,]*/g)||[]).map(num).filter(n=>n>=500).sort((a,b)=>b-a);
  const income = incM ? num(incM[1]) : moneyNums[0];
  const rent = rentM ? num(rentM[1]) : moneyNums.find(n => n !== income && n < (income||0));
  if (!income || !rent || income <= rent) return null;
  const left = income - rent;
  const cat = [
    { en:"Food & groceries",        hi:"खाना व किराना",      pct: 0.24 },
    { en:"Transport",               hi:"यात्रा",              pct: 0.11 },
    { en:"Utilities (bills etc.)",  hi:"बिल (बिजली, पानी)", pct: 0.07 },
    { en:"Healthcare / misc.",      hi:"स्वास्थ्य / विविध",  pct: 0.08 },
    { en:"Savings",                 hi:"बचत",                 pct: 0.20 },
    { en:"Education / self-growth", hi:"शिक्षा / विकास",    pct: 0.07 },
    { en:"Emergency fund",          hi:"आपातकालीन निधि",    pct: 0.10 },
    { en:"Leisure / personal",      hi:"मनोरंजन / व्यक्तिगत", pct: 0.13 },
  ];
  const rows = cat.map(c => {
    const amt = Math.round(left * c.pct);
    return lang === "hi"
      ? `| ${c.hi} | ₹${fmtCurrency(amt, lang)} |`
      : `| ${c.en} | ₹${fmtCurrency(amt, lang)} |`;
  });
  const check = cat.reduce((s,c) => s + Math.round(left*c.pct), 0);
  return lang === "hi"
    ? `**मासिक बजट — ₹${fmtCurrency(income, lang)} आय, ₹${fmtCurrency(rent, lang)} किराया**\n\nकिराए के बाद बचा: **₹${fmtCurrency(left, lang)}**\n\n| मद | राशि |\n|---|---|\n${rows.join("\n")}\n\n<u>जाँच:</u> ${fmtCurrency(income, lang)} − ${fmtCurrency(rent, lang)} = ${fmtCurrency(left, lang)} ✓  \nआवंटन जोड़: ₹${fmtCurrency(check, lang)} (अंतर राउंडिंग से)\n\nइसे अपनी ज़रूरत के हिसाब से बदला जा सकता है — बस बताइए।`
    : `**Monthly budget — income ₹${fmtCurrency(income, lang)}, rent ₹${fmtCurrency(rent, lang)}**\n\nLeft after rent: **₹${fmtCurrency(left, lang)}**\n\n| Category | Amount |\n|---|---|\n${rows.join("\n")}\n\n<u>Arithmetic check:</u> ${fmtCurrency(income, lang)} − ${fmtCurrency(rent, lang)} = ${fmtCurrency(left, lang)} ✓  \nAll categories sum to ₹${fmtCurrency(check, lang)} (small difference from rounding)\n\nAdjust any category to match your situation — just ask.`;
}

// ---- writing tasks ----
function tryWriting(q: string, lang: LocalLang, usedTexts: string[]): string | null {
  const low = q.toLowerCase();

  // thank-you
  if (/thank|gratitude|gratitud|आभार|धन्यवाद/.test(low) && /message|letter|note|write|संदेश|पत्र/.test(low)) {
    const recipient = low.includes("teacher") || low.includes("शिक्षक") ? (lang==="hi" ? "शिक्षक" : "teacher")
      : low.includes("boss") ? (lang==="hi" ? "बॉस" : "manager")
      : low.includes("friend") || low.includes("दोस्त") ? (lang==="hi" ? "मित्र" : "friend")
      : lang==="hi" ? "व्यक्ति" : "person";
    const msgs: Record<LocalLang, string[]> = {
      en: [
        `**Thank-you message to your ${recipient}**\n\nDear ${titleCase(recipient)},\n\nThank you for your guidance, patience, and the genuine care you have always shown. What you do goes beyond words — it shapes lives and builds confidence.\n\n*With heartfelt gratitude,*\n[Your Name]`,
        `**A warm note of thanks**\n\nDear ${titleCase(recipient)},\n\nEvery effort you put in leaves a lasting mark. I am truly grateful for your support, encouragement, and the example you set every day.\n\n*Gratefully yours,*\n[Your Name]`,
        `**Short thank-you message**\n\nThank you, ${recipient}, for being a steady source of guidance and encouragement. Your kindness means more than you know.\n\n*With warm regards,*\n[Your Name]`,
      ],
      hi: [
        `**${recipient} के लिए धन्यवाद संदेश**\n\nआदरणीय ${recipient} जी,\n\nआपकी मेहनत, धैर्य और प्रेरणा के लिए हार्दिक आभार। आपका साथ और मार्गदर्शन हमारे जीवन को बेहतर बनाता है।\n\n*सादर,*\n[आपका नाम]`,
        `**आभार पत्र**\n\nप्रिय ${recipient} जी,\n\nआपकी सीख और स्नेह ने हमें हर कठिन पल में मजबूत बनाया। इस मेहनत और समर्पण के लिए आपका बहुत-बहुत शुक्रिया।\n\n*आपका शुभचिंतक,*\n[आपका नाम]`,
      ]
    };
    return pickFreshText(msgs[lang], usedTexts);
  }

  // application / formal letter
  if (/application|formal letter|अर्जी|आवेदन पत्र/.test(low)) {
    const subject = low.includes("leave") || low.includes("छुट्टी") ? (lang==="hi" ? "अवकाश" : "leave")
      : low.includes("loan") || low.includes("ऋण") ? (lang==="hi" ? "ऋण" : "loan")
      : lang==="hi" ? "विषय" : "request";
    return lang === "hi"
      ? `**${subject} के लिए आवेदन पत्र का ढाँचा**\n\nसेवा में,\nश्रीमान [नाम]\n[पद], [संस्था]\n\nविषय: ${subject} हेतु आवेदन\n\nमहोदय,\n\nसविनय निवेदन है कि मैं [आपका नाम], [पद/छात्र] हूँ। [कारण स्पष्ट करें — संक्षिप्त, सटीक]।\n\nअतः आपसे प्रार्थना है कि [माँग/अनुरोध] स्वीकार करने की कृपा करें।\n\nधन्यवाद।\nभवदीय,\n[आपका नाम]\nदिनांक: [DD/MM/YYYY]`
      : `**Template for a ${subject} application**\n\nTo,\nThe [Designation],\n[Institution/Office]\n\nSubject: Application for ${subject}\n\nRespected Sir/Madam,\n\nI am [Your Name], [Designation/Student]. I am writing to request [state the need clearly and briefly].\n\nI would be grateful if you could kindly approve this request.\n\nThank you.\nYours sincerely,\n[Your Name]\nDate: [DD/MM/YYYY]`;
  }

  // poem
  if (/poem|poetry|कविता/.test(low)) {
    const topic = extractTopic(q);
    const poems: Record<LocalLang, string[]> = {
      en: [
        `**A short poem on "${topic}"**\n\n*Quiet and steady, day by day,*\n*${titleCase(topic)} clears the tangled way.*\n*It holds us firm when we feel small,*\n*A humble bridge that lifts us all.*`,
        `**Poem — ${titleCase(topic)}**\n\n*In the simplest things we find it near,*\n*${titleCase(topic)} — a light when skies seem unclear.*\n*It takes no grand or noisy form,*\n*Just patient effort — that is the norm.*`,
      ],
      hi: [
        `**${topic} पर एक छोटी कविता**\n\n*हर रोज़ एक नया उजाला,*\n*${topic} से जीवन निखरा।*\n*छोटी-छोटी बातों में,*\n*बड़ा खज़ाना है बँधा।*`,
        `**${topic} — कविता**\n\n*${topic} की राह पर,*\n*एक-एक कदम बढ़ते जाएँ।*\n*मेहनत से जो बोया है,*\n*एक दिन उसे फल पाएँ।*`,
      ]
    };
    return pickFreshText(poems[lang], usedTexts);
  }

  // sentences on a topic
  const sentM = low.match(/(\d+|five|ten|three|four)\s*(?:easy|simple|short)?\s*sentences?|(\d+|पाँच|दस|तीन|चार)\s*वाक्य/i);
  if (sentM) {
    const n = sentM[1]==="five"||sentM[1]==="5"||sentM[2]==="पाँच" ? 5
      : sentM[1]==="ten"||sentM[1]==="10"||sentM[2]==="दस" ? 5
      : parseInt(sentM[1]||sentM[2]||"5")||5;
    const topic = extractTopic(q);
    const base: Record<LocalLang, string[]> = {
      en: [
        `${titleCase(topic)} plays an important role in everyday life.`,
        `Understanding ${topic} helps us make better decisions.`,
        `Small steps taken consistently lead to big results in ${topic}.`,
        `Everyone, young and old, can benefit from learning about ${topic}.`,
        `With awareness and practice, ${topic} becomes part of our daily habit.`,
        `${titleCase(topic)} connects different parts of society in meaningful ways.`,
        `Paying attention to ${topic} can prevent many problems before they grow.`,
        `Learning about ${topic} gives us confidence and preparedness.`,
        `Families and communities thrive when they understand ${topic}.`,
        `Even small effort in ${topic} makes a real difference over time.`,
      ],
      hi: [
        `${topic} हमारे जीवन में बहुत महत्वपूर्ण है।`,
        `इसे समझकर हम बेहतर निर्णय ले सकते हैं।`,
        `छोटे-छोटे प्रयास भी ${topic} में बड़ा बदलाव ला सकते हैं।`,
        `बच्चे हों या बड़े, सभी को ${topic} की जानकारी होनी चाहिए।`,
        `जागरूकता और अभ्यास से ${topic} हमारी दिनचर्या का हिस्सा बन जाता है।`,
        `${topic} समाज के हर वर्ग को आपस में जोड़ता है।`,
        `समय रहते ${topic} पर ध्यान देने से कई समस्याएँ टाली जा सकती हैं।`,
        `${topic} की जानकारी से आत्मविश्वास और तैयारी दोनों बढ़ती हैं।`,
        `परिवार और समुदाय तब फलते-फूलते हैं जब वे ${topic} को समझते हैं।`,
        `${topic} में थोड़ा प्रयास समय के साथ बड़ा फ़र्क़ डालता है।`,
      ]
    };
    const lines = base[lang].slice(0, Math.min(n, 10)).map((l, i) => `${i+1}. ${l}`).join("\n");
    return lang === "hi"
      ? `**${topic} पर ${n} आसान वाक्य**\n\n${lines}\n\nचाहें तो मैं इन्हें *और बड़े*, *सरल* या *कक्षा-अनुरूप* बना दूँ।`
      : `**${n} easy sentences on "${topic}"**\n\n${lines}\n\nWant me to make these *longer*, *simpler* or *grade-specific*?`;
  }

  return null;
}

// ---- science & tech explainers ----
function tryExplain(q: string, lang: LocalLang, usedTexts: string[]): string | null {
  const low = q.toLowerCase();

  interface Explainer { en: string[]; hi: string[] }
  const EXPLAINERS: { test: RegExp; e: Explainer }[] = [
    {
      test: /solar (water )?pump|सोलर पंप/,
      e: {
        en: [
          `**How a solar water pump works**\n\nA solar pump uses three steps:\n1. **Collect sunlight** — PV panels convert sunlight into DC electricity\n2. **Run the motor** — electricity powers a motor that spins the pump impeller\n3. **Lift water** — water is pushed from the source (well/pond) to storage or fields\n\n*Key maintenance tip:* wipe the panels clean weekly — <u>1 cm of dust can cut output by 10-15%</u>.\nWant sizing guidance (litres/hour) for your field?`,
          `**Solar pump — simple explanation**\n\nSunlight → electricity (panels) → motor → pump → water moves up.\n- No fuel cost once installed\n- Works best on clear days; store water in a tank for cloudy ones\n- Average lifespan: <u>15-20 years</u> with basic care\nShall I explain the controller/inverter role?`,
        ],
        hi: [
          `**सोलर वाटर पंप कैसे काम करता है**\n\n3 सरल कदम:\n1. **धूप → बिजली** — सोलर पैनल सूर्य की रोशनी से DC करंट बनाते हैं\n2. **बिजली → मोटर** — करंट मोटर चलाता है\n3. **मोटर → पंप → पानी** — पंप कुएँ/तालाब से पानी खींचकर टैंक या खेत भेजता है\n\n*अहम सुझाव:* पैनल पर धूल जमने न दें — <u>हर हफ़्ते साफ़ करें</u>, वरना आउटपुट 10-15% तक घट सकता है।\nआपके खेत के लिए कितने लीटर/घंटा की ज़रूरत है — बताएँ?`,
        ],
      }
    },
    {
      test: /crop rotation|फसल चक्र/,
      e: {
        en: [
          `**Crop rotation — what, why, how**\n\n**What:** Growing different crops in the same field in successive seasons.\n\n**Why it works:**\n- *Nitrogen-fixing* legumes (dal, peas) replenish what cereals take out\n- Breaks the life cycle of crop-specific pests and diseases\n- Reduces fertiliser cost over time\n\n**Simple example (north India):**\n| Season | Crop |\n|---|---|\n| Kharif | Paddy (rice) |\n| Rabi | Wheat |\n| Zaid | Moong dal (green gram) |\n\nWant a rotation plan for a specific crop or soil type?`,
        ],
        hi: [
          `**फसल चक्र — क्या, क्यों, कैसे**\n\n**क्या है:** एक ही खेत में हर मौसम अलग फसल उगाना।\n\n**क्यों ज़रूरी:**\n- *नाइट्रोजन-स्थिरीकरण* — दलहन (अरहर, मूँग) मिट्टी में नाइट्रोजन वापस करती है\n- कीट और रोगों का चक्र टूटता है\n- खाद की लागत घटती है\n\n**सरल उदाहरण (उत्तर भारत):**\n| मौसम | फसल |\n|---|---|\n| खरीफ | धान |\n| रबी | गेहूँ |\n| ज़ायद | मूँग दाल |\n\nकिस मिट्टी या फसल के लिए योजना चाहिए?`,
        ],
      }
    },
    {
      test: /photosynthesis|प्रकाश संश्लेषण/,
      e: {
        en: [`**Photosynthesis — the plant's food factory**\n\nPlants make their own food using:\n- <u>Sunlight</u> (energy source)\n- <u>CO₂</u> from air (through stomata in leaves)\n- <u>Water</u> from soil (through roots)\n\n**What comes out:** Glucose (food for the plant) + **Oxygen** (released into air — this is what we breathe).\n\n**Simple equation:** 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂\n\nThis happens mainly in the *chloroplasts* (green parts of leaves). Want a diagram description?`],
        hi: [`**प्रकाश संश्लेषण — पौधे का भोजन-कारखाना**\n\nपौधे तीन चीज़ों से अपना खाना बनाते हैं:\n- <u>सूरज की रोशनी</u> (ऊर्जा)\n- <u>CO₂</u> (हवा से, पत्तियों के रोमछिद्रों द्वारा)\n- <u>पानी</u> (जड़ों से)\n\n**बाहर निकलता है:** ग्लूकोज़ (पौधे का भोजन) + **ऑक्सीजन** (जो हम साँस लेते हैं)\n\n**सूत्र:** 6CO₂ + 6H₂O + प्रकाश → C₆H₁₂O₆ + 6O₂\n\nयह प्रक्रिया *क्लोरोप्लास्ट* (पत्तियों के हरे हिस्से) में होती है। चित्र में समझाऊँ?`],
      }
    },
  ];

  // learning path
  if (/how (do i |to |can i )?learn|सीखूँ|सीखें|कैसे सीखें/.test(low)) {
    const topic = extractTopic(q);
    const plans: Record<LocalLang, string[]> = {
      en: [
        `**How to learn ${topic} — a practical 4-step plan**\n\n**Step 1 — Understand the basics** (Week 1)\n- Find one beginner source (book, YouTube, course)\n- Spend <u>30-45 minutes</u> daily — consistency beats marathon sessions\n\n**Step 2 — Practise tiny tasks** (Week 2-3)\n- Do one small exercise every day, even if it is simple\n- Write down what confused you; those become your priority topics\n\n**Step 3 — Build something real** (Week 4)\n- Apply the skill to a mini-project or real problem you care about\n- Mistakes here teach more than any lesson\n\n**Step 4 — Review and repeat**\n- Every week, skim what you learned and fill the gaps\n- Teach it to someone — the quickest way to test understanding\n\nWant me to suggest free resources for ${topic} specifically?`,
        `**Learning ${topic} — start here**\n\n| Week | Focus |\n|---|---|\n| 1 | Core concepts — read/watch 30 min daily |\n| 2-3 | Practice — one exercise per day |\n| 4 | Build a mini-project |\n| Ongoing | Review + teach someone |\n\n*Golden rule:* <u>Show up every day</u>, even for 15 minutes — that beats studying for 3 hours once a week.\n\nShall I make a 7-day day-by-day plan for ${topic}?`,
      ],
      hi: [
        `**${topic} — 4 चरणों में सीखें**\n\n**चरण 1 — मूल बातें समझें** (पहला हफ़्ता)\n- एक अच्छा स्रोत ढूँढें (YouTube/किताब/कोर्स)\n- हर रोज़ <u>30-45 मिनट</u> दें — लगातार करना सबसे ज़रूरी है\n\n**चरण 2 — छोटे अभ्यास** (2-3 हफ़्ते)\n- हर दिन एक छोटा काम करें, चाहे वो सरल ही हो\n- जो समझ न आए उसे लिख लें — वही आपकी प्राथमिकता बनेगी\n\n**चरण 3 — असली काम बनाएँ** (चौथा हफ़्ता)\n- सीखी हुई चीज़ किसी असली समस्या पर आज़माएँ\n- गलतियाँ सबसे अच्छे शिक्षक हैं\n\n**चरण 4 — दोहराते रहें**\n- हर हफ़्ते एक बार पिछला पढ़ें\n- किसी को सिखाएँ — समझ पक्की होती है\n\n${topic} के लिए मुफ़्त स्रोत बताएँ?`,
      ],
    };
    return pickFreshText(plans[lang], usedTexts);
  }

  for (const { test, e } of EXPLAINERS) {
    if (test.test(low)) return pickFreshText(e[lang] || e.en, usedTexts);
  }
  return null;
}

// ---- Indian civics / government ----
function tryCivics(q: string, lang: LocalLang, usedTexts: string[]): string | null {
  const low = q.toLowerCase();
  const CIVICS: { test: RegExp; en: string; hi: string }[] = [
    {
      test: /prime minister|pm of india|प्रधानमंत्री/,
      en: `**Prime Minister of India**\nAs per my built-in knowledge: **Narendra Modi** is the Prime Minister of India.\n- He took office on **26 May 2014** and was re-elected in 2019 and 2024.\n- His official title is *Prime Minister of the Republic of India*.\n- Office: 7, Lok Kalyan Marg, New Delhi\n\n*Note: for the most up-to-date position, live web search will confirm this.*`,
      hi: `**भारत के प्रधानमंत्री**\nमेरी जानकारी के अनुसार: भारत के प्रधानमंत्री **नरेंद्र मोदी** हैं।\n- पदभार: **26 मई 2014** (2019 और 2024 में पुनर्निर्वाचित)\n- पद का नाम: *भारत गणराज्य के प्रधानमंत्री*\n- कार्यालय: 7, लोक कल्याण मार्ग, नई दिल्ली\n\n*नोट: सबसे ताज़ा जानकारी के लिए ऑनलाइन मोड में जाँच करें।*`,
    },
    {
      test: /president of india|राष्ट्रपति/,
      en: `**President of India**\nAs per my built-in knowledge: **Droupadi Murmu** is the 15th President of India.\n- Took office: **25 July 2022**\n- She is the first president from a tribal community and the second woman president.\n\n*For the most current status, live search will verify.*`,
      hi: `**भारत की राष्ट्रपति**\nमेरी जानकारी के अनुसार: **द्रौपदी मुर्मू** भारत की 15वीं राष्ट्रपति हैं।\n- पदभार: **25 जुलाई 2022**\n- वे किसी आदिवासी समुदाय से पहली और देश की दूसरी महिला राष्ट्रपति हैं।\n\n*सबसे ताज़ा जानकारी के लिए ऑनलाइन जाँच करें।*`,
    },
    {
      test: /bank account|bank.*document|document.*bank|खाता खोल|बैंक खाता/,
      en: `**Opening a bank account in India — documents usually required**\n\n| Document | Purpose |\n|---|---|\n| Aadhaar card | Identity + address proof |\n| PAN card | Tax identity (required for many accounts) |\n| Passport / Voter ID | Alternative identity proof |\n| 2 passport-size photos | Application form |\n| Mobile number | OTP/alerts |\n\n*Requirements may vary slightly between banks and account types (savings, Jan Dhan, etc.). Always confirm at the branch.*\n\nNeed help understanding a specific account type?`,
      hi: `**भारत में बैंक खाता खोलने के लिए दस्तावेज़**\n\n| दस्तावेज़ | उद्देश्य |\n|---|---|\n| आधार कार्ड | पहचान + पता प्रमाण |\n| PAN कार्ड | कर पहचान (कई खातों में अनिवार्य) |\n| पासपोर्ट / वोटर आईडी | वैकल्पिक पहचान |\n| 2 पासपोर्ट साइज फोटो | आवेदन पत्र के लिए |\n| मोबाइल नंबर | OTP/अलर्ट के लिए |\n\n*बैंक और खाते के प्रकार (बचत, जन धन आदि) के अनुसार नियम थोड़े अलग हो सकते हैं। शाखा में एक बार पुष्टि करें।*\n\nकिसी विशेष खाते के बारे में जानना है?`,
    },
    {
      test: /aadhar|aadhaar|आधार/,
      en: `**Aadhaar Card — key facts**\n- 12-digit unique biometric ID issued by *UIDAI*\n- Accepted as identity + address proof across India\n- Required for: bank accounts, SIM cards, government schemes, income tax filing\n- Free to update address online at *myaadhaar.uidai.gov.in*\n- Helpline: <u>1947</u> (toll-free)\n\nNeed help with enrollment or correction?`,
      hi: `**आधार कार्ड — मुख्य जानकारी**\n- 12 अंकों का अनोखा बायोमेट्रिक पहचान पत्र (जारीकर्ता: *UIDAI*)\n- पूरे भारत में पहचान और पते के प्रमाण के रूप में मान्य\n- ज़रूरत: बैंक खाता, SIM, सरकारी योजनाएँ, आयकर\n- पता ऑनलाइन मुफ़्त बदलें: *myaadhaar.uidai.gov.in*\n- हेल्पलाइन: <u>1947</u>\n\nनामांकन या सुधार में मदद चाहिए?`,
    },
    {
      test: /pm kisan|किसान सम्मान/,
      en: `**PM-KISAN Scheme — key details**\n- Provides **₹6,000/year** directly to eligible farmers in 3 instalments of ₹2,000\n- Eligibility: small and marginal farmers with landholding up to 2 hectares\n- Register at: *pmkisan.gov.in*\n- Documents: Aadhaar, bank account linked to Aadhaar, land records\n- Helpline: <u>155261</u> or <u>011-23381092</u>\n\nNeed help checking your status or applying?`,
      hi: `**PM-KISAN — मुख्य जानकारी**\n- पात्र किसानों को **₹6,000/वर्ष** (₹2,000 की 3 किस्तें) सीधे बैंक में\n- पात्रता: 2 हेक्टेयर तक भूमि वाले छोटे और सीमांत किसान\n- पंजीकरण: *pmkisan.gov.in*\n- दस्तावेज़: आधार, आधार से जुड़ा बैंक खाता, भूमि रिकॉर्ड\n- हेल्पलाइन: <u>155261</u> या <u>011-23381092</u>\n\nस्थिति जाँचनी है या आवेदन करना है?`,
    },
  ];
  for (const c of CIVICS) {
    if (c.test.test(low)) {
      const msgs = [lang==="hi" ? c.hi : c.en];
      return pickFreshText(msgs, usedTexts);
    }
  }
  return null;
}

// ---- health & wellbeing (human, basic first-aid only) ----
function tryHealth(q: string, lang: LocalLang): string | null {
  const low = q.toLowerCase();
  if (/ors|oral rehydration|dehydration|निर्जलीकरण|ओआरएस/.test(low)) {
    return lang === "hi"
      ? `**ओआरएस (ORS) कैसे बनाएँ**\n\nसामग्री (1 लीटर के लिए):\n- <u>1 लीटर</u> साफ उबला पानी (ठंडा)\n- <u>6 चम्मच</u> चीनी\n- <u>½ चम्मच</u> नमक\n\nमिलाएँ, घुलाएँ, पिलाएँ।\n\n*वयस्क:* दस्त/उल्टी के बाद हर बार <u>200-300 ml</u>\n*बच्चे:* हर बार <u>50-100 ml</u>\n\n⚠️ गंभीर निर्जलीकरण में तुरंत डॉक्टर के पास जाएँ।`
      : `**How to make ORS at home**\n\nIngredients (for 1 litre):\n- <u>1 litre</u> clean water (boiled and cooled)\n- <u>6 teaspoons</u> sugar\n- <u>½ teaspoon</u> salt\n\nStir until dissolved. Give small sips frequently.\n\n*Adults:* <u>200-300 ml</u> after each loose stool\n*Children:* <u>50-100 ml</u> each time\n\n⚠️ For severe dehydration, see a doctor immediately.`;
  }
  if (/first aid|प्राथमिक चिकित्सा/.test(low)) {
    return lang === "hi"
      ? `**बुनियादी प्राथमिक चिकित्सा — याद रखें**\n\n**कट/घाव:**\n- बहते पानी से <u>5 मिनट</u> धोएँ\n- साफ कपड़े से दबाएँ, खून रोकें\n- पट्टी करें\n\n**जलना:**\n- ठंडे पानी में <u>10-20 मिनट</u> डालें\n- बर्फ़ न लगाएँ\n- गंभीर हो तो अस्पताल\n\n**बेहोशी:**\n- लेटाएँ, पैर थोड़ा ऊँचा रखें\n- सिर मत हिलाएँ\n- 1-2 मिनट में न जागे तो 112 पर कॉल करें\n\n⚠️ यह जानकारी आपातकाल तक के लिए है। डॉक्टर से मिलना ज़रूरी है।`
      : `**Basic first aid — remember these**\n\n**Cut / wound:**\n- Run under clean water for <u>5 minutes</u>\n- Press with a clean cloth to stop bleeding\n- Apply a bandage\n\n**Burn:**\n- Cool under cold water for <u>10-20 minutes</u>\n- Do NOT use ice\n- See a doctor for serious burns\n\n**Fainting:**\n- Lay the person down, raise legs slightly\n- Do not move the head\n- If not alert in 1-2 minutes, call 112\n\n⚠️ This is basic guidance. Always see a doctor for serious injuries.`;
  }
  return null;
}

// ---- Deep reasoning master dispatcher ----
export function generalAnswer(question: string, lang: LocalLang, usedTexts: string[]): string {
  const q = (question || "").trim();
  if (!q) return lang === "hi"
    ? "कोई सवाल पूछिए — मैं तैयार हूँ।"
    : "Ask me anything — I am ready.";

  // Run each specialist and return the first match
  const math = tryMath(q, lang);
  if (math) return math;

  const budget = tryBudget(q, lang);
  if (budget) return budget;

  const write = tryWriting(q, lang, usedTexts);
  if (write) return write;

  const explain = tryExplain(q, lang, usedTexts);
  if (explain) return explain;

  const civics = tryCivics(q, lang, usedTexts);
  if (civics) return civics;

  const health = tryHealth(q, lang);
  if (health) return health;

  // ---- Generic but thoughtful fallback ----
  const topic = extractTopic(q);
  const devanagari = /[\u0900-\u097F]/.test(q);
  const effectiveLang: LocalLang = devanagari ? "hi" : lang;

  const generic: Record<LocalLang, string[]> = {
    en: [
      `**${titleCase(topic)} — a clear, structured answer**\n\n**What it is:** ${titleCase(topic)} refers to the concept, practice, or question you asked about — one that touches everyday life in a practical way.\n\n**Key points to understand:**\n- Break it into the simplest components first\n- Ask: *what is it, why does it matter, and what do I do with it?*\n- Look for examples from your own life — that makes any topic stick\n\n**A practical next step:**\nIf you give me more detail — for example a specific scenario, a number, or a context — I can give you a precise, tailored answer right away.\n\nWhat would you like to know more specifically?`,
      `**Understanding "${topic}"**\n\nHere is how to think about it clearly:\n\n1. **Define it simply** — strip away jargon, state it in one sentence\n2. **See why it matters** — who does it affect, and how?\n3. **Apply it** — what is one practical thing you can do with this knowledge today?\n\n*I am fully ready to go deeper.* Tell me the angle you care about most — calculation, explanation, planning, or examples — and I will build a complete answer.`,
    ],
    hi: [
      `**${topic} — एक स्पष्ट और उपयोगी जवाब**\n\n**यह क्या है:** ${topic} एक ऐसा विषय है जो रोज़मर्रा की ज़िंदगी से जुड़ा है और जानना ज़रूरी है।\n\n**समझने के तीन आसान तरीके:**\n- पहले इसे सबसे सरल भाषा में परिभाषित करें\n- फिर सोचें: *यह क्यों ज़रूरी है और इसका असर क्या पड़ता है?*\n- फिर अपनी ज़िंदगी से उदाहरण ढूँढें — इससे विषय दिमाग में पक्का बैठता है\n\n**अगला कदम:**\nअगर आप थोड़ी और जानकारी दें — जैसे कोई संख्या, स्थिति या उदाहरण — तो मैं आपको तुरंत सटीक और व्यक्तिगत जवाब दे सकता हूँ।\n\nआप किस पहलू के बारे में जानना चाहते हैं?`,
      `**"${topic}" को समझें**\n\n3 चरणों में सोचें:\n\n1. **सरल परिभाषा** — बिना जटिल शब्दों के, एक वाक्य में क्या है?\n2. **यह क्यों मायने रखता है** — किसको, कब और कैसे फ़र्क़ पड़ता है?\n3. **व्यवहार में लाएँ** — आज इस जानकारी से क्या एक काम हो सकता है?\n\n*मैं पूरी तरह तैयार हूँ।* गहरा जवाब चाहिए तो विषय से जुड़ा कोई उदाहरण, संख्या या संदर्भ बताइए — पूरा जवाब तुरंत मिलेगा।`,
    ],
  };

  return pickFreshText(generic[effectiveLang], usedTexts);
}

/** Pick a reply that has not already been used in this chat. */
export function localAnswer(question: string, lang: LocalLang, usedTexts: string[]): string {
  for (const topic of TOPICS) {
    if (topic.test.test(question)) return pickFreshText(topic[lang], usedTexts);
  }
  return pickFreshText(GENERIC[lang], usedTexts);
}

export function detectLang(text: string, fallback: LocalLang): LocalLang {
  if (/[\u0900-\u097F]/.test(text)) return "hi";
  if (/[a-zA-Z]/.test(text)) return "en";
  return fallback;
}
