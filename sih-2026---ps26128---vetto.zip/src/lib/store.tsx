"use client";

import React, {
  createContext, useCallback, useContext, useEffect, useMemo, useState,
} from "react";
import { Lang, TKey, translate } from "./i18n";
import { AnimalType, qtyToNumber } from "./animals";

export interface LocationInfo {
  lat: number;
  lon: number;
  label: string;
  landmark?: string;
  updatedAt: number;
}

export interface Profile {
  name: string;
  photo?: string;
  phone?: string;
  email?: string;
  location?: LocationInfo;
}

export interface AnimalEntry {
  id: string;
  type: AnimalType;
  qty: string;
  addedAt: number;
}

export interface Vaccine {
  id: string;
  animalType: AnimalType;
  name: string;
  date: string; // ISO yyyy-mm-dd
  createdAt: number;
}

export interface Note {
  id: string;
  title: string;
  body: string;
  animalType: string; // AnimalType | 'general'
  createdAt: number;
}

export type ReportStatus = "queued" | "synced" | "draft";
export interface Report {
  id: string;
  kind: "photo" | "voice" | "chat";
  text: string;
  image?: string;
  animalType?: string;
  createdAt: number;
  status: ReportStatus;
}

export interface Session {
  mode: "guest" | "phone" | "google";
  phone?: string;
  email?: string;
  at: number;
}

export type Role = "farmer" | "vet" | "guest";

export interface CaseAttachment {
  name: string;
  type: string;
  size: number;
  dataUrl?: string;
}

export interface CaseResponse {
  id: string;
  author: string;
  authorRole: "vet" | "official";
  text: string;
  attachments: CaseAttachment[];
  createdAt: number;
}

export type CaseStatus = "new" | "in_review" | "answered";
export type CaseUrgency = "normal" | "urgent" | "emergency";

export interface VetCase {
  id: string;
  code: string;
  farmerName: string;
  village?: string;
  animalType: string;
  count: string;
  symptoms: string;
  duration: string;
  urgency: CaseUrgency;
  images: string[];
  createdAt: number;
  status: CaseStatus;
  responses: CaseResponse[];
  demo?: boolean;
}

interface Persisted {
  lang: Lang;
  theme: "light" | "dark";
  manualOffline: boolean;
  session: Session | null;
  role: Role | null;
  activeView: "farmer" | "vet";
  vetCases: VetCase[];
  profile: Profile;
  animals: AnimalEntry[];
  vaccines: Vaccine[];
  notes: Note[];
  reports: Report[];
}

const DEFAULTS: Persisted = {
  lang: "en",
  theme: "light",
  manualOffline: false,
  session: null,
  role: null,
  activeView: "farmer",
  vetCases: [],
  profile: { name: "" },
  animals: [],
  vaccines: [],
  notes: [],
  reports: [],
};


const HOUR = 3600000;
function seedCases(): VetCase[] {
  const now = Date.now();
  const mk = (
    n: number, farmerName: string, village: string, animalType: string, count: string,
    symptoms: string, duration: string, urgency: CaseUrgency, hrsAgo: number, status: CaseStatus
  ): VetCase => ({
    id: "seed" + n,
    code: "VC-DEMO" + String(100 + n),
    farmerName, village, animalType, count, symptoms, duration, urgency,
    images: [],
    createdAt: now - hrsAgo * HOUR,
    status,
    responses: [],
    demo: true,
  });
  return [
    mk(1, "Ramesh Kumar", "Rampur", "cow", "2",
      "Both cows have high fever and are not eating since yesterday. Milk has dropped by almost half.",
      "2-3 days", "urgent", 3, "new"),
    mk(2, "Sunita Devi", "Bhagwanpur", "goat", "5",
      "Three goats have loose motion with a bad smell. One kid looks very weak and is not standing properly.",
      "Since yesterday", "emergency", 8, "new"),
    mk(3, "Imran Ali", "Kishanganj", "buffalo", "1",
      "Buffalo's udder is hot and swollen. Milk has small clots in it. She kicks when I try to milk her.",
      "2-3 days", "urgent", 26, "in_review"),
    mk(4, "Lakshmi Bai", "Naugaon", "hen", "25",
      "Four hens died suddenly in two days. Others are sitting quietly with ruffled feathers and drinking less.",
      "Since yesterday", "emergency", 30, "new"),
    mk(5, "Gopal Yadav", "Salempur", "sheep", "12",
      "Sheep are limping and there are wounds between the hooves. It started after the heavy rain last week.",
      "Many days", "normal", 52, "new"),
  ];
}

const KEY = "vetto.v1";

function load(): Persisted {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS, vetCases: seedCases() };
    const parsed = { ...DEFAULTS, ...(JSON.parse(raw) as Partial<Persisted>) };
    if (!parsed.vetCases || parsed.vetCases.length === 0) parsed.vetCases = seedCases();
    return parsed;
  } catch {
    return { ...DEFAULTS, vetCases: seedCases() };
  }
}

function uid(): string {
  return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
}

interface StoreCtx extends Persisted {
  browserOnline: boolean;
  online: boolean;
  hydrated: boolean;
  t: (k: TKey) => string;
  setLang: (l: Lang) => void;
  setTheme: (th: "light" | "dark") => void;
  setManualOffline: (v: boolean) => void;
  login: (s: Session) => void;
  logout: () => void;
  setRole: (r: Role | null) => void;
  setActiveView: (v: "farmer" | "vet") => void;
  addVetCase: (c: Omit<VetCase, "id" | "code" | "createdAt" | "status" | "responses">) => VetCase;
  addCaseResponse: (caseId: string, r: Omit<CaseResponse, "id" | "createdAt">) => void;
  setCaseStatus: (caseId: string, st: CaseStatus) => void;
  saveProfile: (p: Profile) => void;
  clearProfile: () => void;
  addAnimal: (type: AnimalType, qty: string) => void;
  removeAnimal: (id: string) => void;
  addVaccine: (v: Omit<Vaccine, "id" | "createdAt">) => void;
  removeVaccine: (id: string) => void;
  addNote: (n: Omit<Note, "id" | "createdAt">) => void;
  removeNote: (id: string) => void;
  addReport: (r: Omit<Report, "id" | "createdAt">) => Report;
  totalAnimals: number;
}

const Ctx = createContext<StoreCtx | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<Persisted>(DEFAULTS);
  const [hydrated, setHydrated] = useState(false);
  const [browserOnline, setBrowserOnline] = useState(true);

  useEffect(() => {
    const s = load();
    setState(s);
    setHydrated(true);
    setBrowserOnline(navigator.onLine);
    const on = () => setBrowserOnline(true);
    const off = () => setBrowserOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch { /* storage full — ignore */ }
    document.documentElement.setAttribute("data-theme", state.theme);
  }, [state, hydrated]);

  const patch = useCallback((p: Partial<Persisted>) => {
    setState((s) => ({ ...s, ...p }));
  }, []);

  const t = useCallback((k: TKey) => translate(state.lang, k), [state.lang]);

  const value = useMemo<StoreCtx>(() => {
    const online = browserOnline && !state.manualOffline;
    return {
      ...state,
      browserOnline,
      online,
      hydrated,
      t,
      setLang: (lang) => patch({ lang }),
      setTheme: (theme) => patch({ theme }),
      setManualOffline: (manualOffline) => patch({ manualOffline }),
      login: (session) => patch({ session }),
      logout: () => patch({ session: null, role: null, activeView: "farmer" }),
      setRole: (role) => patch({ role, activeView: role === "vet" ? "vet" : "farmer" }),
      setActiveView: (activeView) => patch({ activeView }),
      addVetCase: (c) => {
        const now = Date.now();
        const vc: VetCase = {
          ...c,
          id: uid(),
          code: "VC-" + String(now).slice(-6),
          createdAt: now,
          status: "new",
          responses: [],
        };
        setState((s2) => ({ ...s2, vetCases: [vc, ...s2.vetCases].slice(0, 80) }));
        return vc;
      },
      addCaseResponse: (caseId, r) =>
        setState((s2) => ({
          ...s2,
          vetCases: s2.vetCases.map((c) =>
            c.id === caseId
              ? {
                  ...c,
                  status: "answered" as CaseStatus,
                  responses: [...c.responses, { ...r, id: uid(), createdAt: Date.now() }],
                }
              : c
          ),
        })),
      setCaseStatus: (caseId, st) =>
        setState((s2) => ({
          ...s2,
          vetCases: s2.vetCases.map((c) => (c.id === caseId ? { ...c, status: st } : c)),
        })),
      saveProfile: (profile) => patch({ profile }),
      clearProfile: () =>
        setState((s) => ({
          ...s,
          profile: { name: "" },
          animals: [],
          vaccines: [],
          notes: [],
        })),
      addAnimal: (type, qty) =>
        setState((s) => ({ ...s, animals: [...s.animals, { id: uid(), type, qty, addedAt: Date.now() }] })),
      removeAnimal: (id) =>
        setState((s) => ({ ...s, animals: s.animals.filter((a) => a.id !== id) })),
      addVaccine: (v) =>
        setState((s) => ({ ...s, vaccines: [...s.vaccines, { ...v, id: uid(), createdAt: Date.now() }] })),
      removeVaccine: (id) =>
        setState((s) => ({ ...s, vaccines: s.vaccines.filter((v) => v.id !== id) })),
      addNote: (n) =>
        setState((s) => ({ ...s, notes: [{ ...n, id: uid(), createdAt: Date.now() }, ...s.notes] })),
      removeNote: (id) =>
        setState((s) => ({ ...s, notes: s.notes.filter((n) => n.id !== id) })),
      addReport: (r) => {
        const report: Report = { ...r, id: uid(), createdAt: Date.now() };
        setState((s) => ({ ...s, reports: [report, ...s.reports].slice(0, 60) }));
        return report;
      },
      totalAnimals: state.animals.reduce((n, a) => n + qtyToNumber(a.qty), 0),
    };
  }, [state, browserOnline, hydrated, t, patch]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore(): StoreCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
