export type SchemeCat =
  | "dairy" | "health" | "insurance" | "credit" | "poultry" | "goatsheep"
  | "feed" | "breed" | "infra" | "women" | "training" | "market" | "private";

export type SchemeType = "central" | "state" | "coop" | "private";

export interface Scheme {
  id: number;
  name: string;
  nameHi: string;
  cat: SchemeCat;
  type: SchemeType;
  org: string;
  benefit: string;
  benefitHi: string;
  docs: string;
  docsHi: string;
  base: number;
  animals?: string[];
}

export const SCHEME_CATS: SchemeCat[] = [
  "dairy", "health", "insurance", "credit", "poultry", "goatsheep",
  "feed", "breed", "infra", "women", "training", "market", "private",
];

const A = "Aadhaar card|Bank passbook|Passport photo";
const AL = "Aadhaar card|Bank passbook|Land/shed proof";
const AM = "Aadhaar card|Bank passbook|Milk society membership";
const AH = "आधार कार्ड|बैंक पासबुक|पासपोर्ट फोटो";
const ALH = "आधार कार्ड|बैंक पासबुक|भूमि/शेड प्रमाण";
const AMH = "आधार कार्ड|बैंक पासबुक|दुग्ध समिति सदस्यता";

// [name, nameHi, cat, type, org, benefit, benefitHi, docs, docsHi, base, animals?]
type Row = [string, string, SchemeCat, SchemeType, string, string, string, string, string, number, string?];

const ROWS: Row[] = [
  // ---------- DAIRY (14) ----------
  ["Rashtriya Gokul Mission", "राष्ट्रीय गोकुल मिशन", "dairy", "central", "DAHD, Govt. of India", "50% subsidy on breed improvement & dairy units", "नस्ल सुधार व डेयरी यूनिट पर 50% अनुदान", AL, ALH, 78, "cow,buffalo"],
  ["National Livestock Mission – Dairy", "राष्ट्रीय पशुधन मिशन – डेयरी", "dairy", "central", "DAHD, Govt. of India", "50% subsidy for dairy entrepreneurship", "डेयरी उद्यमिता पर 50% अनुदान", AL, ALH, 74, "cow,buffalo"],
  ["National Programme for Dairy Development", "राष्ट्रीय डेयरी विकास कार्यक्रम", "dairy", "central", "DAHD / NDDB", "Milk processing & chilling infrastructure support", "दूध प्रसंस्करण व शीतलीकरण ढाँचे में सहायता", AM, AMH, 68, "cow,buffalo"],
  ["Dairy Processing Infrastructure Fund", "डेयरी प्रसंस्करण बुनियादी ढाँचा कोष", "dairy", "central", "NDDB / NABARD", "Low-interest loans for dairy units", "डेयरी यूनिट के लिए कम ब्याज ऋण", AM, AMH, 66, "cow,buffalo"],
  ["Kamdhenu Yojana (Sudharit) — Goa", "कामधेनु योजना (संशोधित) — गोवा", "dairy", "state", "Goa Animal Husbandry Dept.", "Subsidy for purchase of milch animals", "दुधारू पशु खरीद पर अनुदान", AL, ALH, 70, "cow,buffalo"],
  ["Gokul Gram Yojana — Haryana", "गोकुल ग्राम योजना — हरियाणा", "dairy", "state", "Haryana Govt.", "Infrastructure subsidy for dairy farmers", "डेयरी किसानों के लिए ढाँचा अनुदान", AL, ALH, 64, "cow,buffalo"],
  ["Nandini Krishak Samriddhi Yojana — UP", "नंदिनी कृषक समृद्धि योजना — यूपी", "dairy", "state", "Uttar Pradesh Govt.", "25–50% subsidy for milch cattle units", "दुधारू पशु इकाइयों पर 25–50% अनुदान", AL, ALH, 72, "cow,buffalo"],
  ["Mukhyamantri Pragatisheel Pashupalak Protsahan — UP", "मुख्यमंत्री प्रगतिशील पशुपालक प्रोत्साहन — यूपी", "dairy", "state", "Uttar Pradesh Govt.", "Incentive for high-yield dairy units", "उच्च उत्पादन डेयरी इकाइयों को प्रोत्साहन", AL, ALH, 67, "cow,buffalo"],
  ["Ksheera Gramam — Kerala", "क्षीर ग्रामम — केरल", "dairy", "state", "Kerala Dairy Development", "Village-level dairy development support", "ग्राम स्तरीय डेयरी विकास सहायता", AM, AMH, 65, "cow"],
  ["Dairy Vikas Yojana — MP", "डेयरी विकास योजना — एमपी", "dairy", "state", "MPCDF (Sanchi)", "Bonus on milk poured + cheap cattle feed", "दूध पर बोनस और सस्ता पशु आहार", AM, AMH, 71, "cow,buffalo"],
  ["Mukhyamantri Pashudhan Vikas Yojana — HP", "मुख्यमंत्री पशुधन विकास योजना — हिमाचल", "dairy", "state", "HP Animal Husbandry", "50% subsidy for rearing units", "पशु पालन इकाइयों पर 50% अनुदान", AL, ALH, 69, "cow,goat"],
  ["Dugdh Samvardhan Yojana — HP", "दुग्ध संवर्धन योजना — हिमाचल", "dairy", "state", "HP Govt.", "Milk transport & incentive support", "दूध परिवहन व प्रोत्साहन सहायता", AM, AMH, 62, "cow"],
  ["Dairy Entrepreneurship Scheme — Bihar", "डेयरी उद्यमिता योजना — बिहार", "dairy", "state", "Bihar Dairy Dept.", "Subsidy for 2–10 cattle dairy units", "2–10 पशुओं की डेयरी इकाई पर अनुदान", AL, ALH, 73, "cow,buffalo"],
  ["Amul Pattern Dairy Societies — GCMMF", "अमूल मॉडल दुग्ध समितियाँ", "dairy", "coop", "GCMMF (Amul)", "Assured milk procurement + bonus", "दूध की सुनिश्चित खरीद + बोनस", AM, AMH, 85, "cow,buffalo"],

  // ---------- HEALTH (10) ----------
  ["National Animal Disease Control Programme", "राष्ट्रीय पशु रोग नियंत्रण कार्यक्रम", "health", "central", "DAHD, Govt. of India", "Free FMD & Brucellosis vaccination", "खुरपका-मुँहपका व गर्भपात रोग का नि:शुल्क टीका", A, AH, 92, "cow,buffalo,goat,sheep"],
  ["Livestock Health & Disease Control Programme", "पशुधन स्वास्थ्य व रोग नियंत्रण कार्यक्रम", "health", "central", "DAHD, Govt. of India", "Free vaccination & veterinary care drives", "नि:शुल्क टीकाकरण व पशु चिकित्सा शिविर", A, AH, 88, "cow,buffalo,goat,sheep,pig"],
  ["PPR Eradication Programme", "पीपीआर उन्मूलन कार्यक्रम", "health", "central", "DAHD, Govt. of India", "Free PPR vaccine for goats & sheep", "बकरी-भेड़ के लिए नि:शुल्क पीपीआर टीका", A, AH, 90, "goat,sheep"],
  ["Pashudhan Sanjivani — Nakul Swasthya Patra", "पशुधन संजीवनी — नकुल स्वास्थ्य पत्र", "health", "central", "DAHD", "Free animal health cards & tracking", "नि:शुल्क पशु स्वास्थ्य कार्ड व रिकॉर्ड", A, AH, 84, "cow,buffalo"],
  ["Mobile Veterinary Units", "मोबाइल पशु चिकित्सा इकाइयाँ", "health", "central", "State AHD (CSS)", "Doorstep veterinary service at call rate", "कॉल पर घर तक पशु चिकित्सा सेवा", A, AH, 86, "cow,buffalo,goat,sheep"],
  ["A-HELP Programme", "ए-हेल्प कार्यक्रम", "health", "central", "NDDB / DAHD", "Trained women animal-health workers in villages", "गाँव में प्रशिक्षित महिला पशु स्वास्थ्य कर्मी", A, AH, 63, ""],
  ["Foot & Mouth Disease-Free Zone Support", "खुरपका-मुँहपका रोग मुक्त क्षेत्र सहायता", "health", "central", "DAHD", "Certification & free surveillance", "प्रमाणन व नि:शुल्क निगरानी", A, AH, 58, "cow,buffalo"],
  ["Classical Swine Fever Control", "सुअर ज्वर नियंत्रण कार्यक्रम", "health", "central", "DAHD", "Free pig vaccination drives", "सूअरों के लिए नि:शुल्क टीकाकरण", A, AH, 61, "pig"],
  ["Avian Influenza Preparedness Support", "एवियन इन्फ्लूएंजा तैयारी सहायता", "health", "central", "DAHD", "Biosecurity guidance & compensation support", "बायोसिक्योरिटी मार्गदर्शन व मुआवजा सहायता", A, AH, 57, "hen,duck"],
  ["Govt. Veterinary Hospital Services", "सरकारी पशु चिकित्सालय सेवाएँ", "health", "state", "State Animal Husbandry Dept.", "Free/very cheap OPD & emergency care", "नि:शुल्क/सस्ती ओपीडी व आपात सेवा", A, AH, 89, "cow,buffalo,goat,sheep,hen"],

  // ---------- INSURANCE (9) ----------
  ["Livestock Insurance Scheme", "पशुधन बीमा योजना", "insurance", "central", "DAHD / insurers", "3% premium policy for cattle (50% subsidy)", "पशुओं के लिए 3% प्रीमियम बीमा (50% अनुदान)", A, AH, 81, "cow,buffalo"],
  ["Pashudhan Bima Yojana — Haryana", "पशुधन बीमा योजना — हरियाणा", "insurance", "state", "Haryana Govt.", "₹100 per animal insurance cover", "₹100 प्रति पशु बीमा कवर", A, AH, 82, "cow,buffalo,goat"],
  ["Mukhyamantri Pashu Bima Yojana — Rajasthan", "मुख्यमंत्री पशु बीमा योजना — राजस्थान", "insurance", "state", "Rajasthan Govt.", "Free/subsidized animal insurance", "नि:शुल्क/अनुदानित पशु बीमा", A, AH, 83, "cow,buffalo,goat,sheep"],
  ["Kamadhenu Cattle Insurance — Kerala", "कामधेनु पशु बीमा — केरल", "insurance", "state", "Kerala Livestock Dev. Board", "Low-premium cattle cover", "कम प्रीमियम पशु बीमा", A, AH, 68, "cow"],
  ["Sheep & Goat Insurance — Telangana", "भेड़-बकरी बीमा — तेलंगाना", "insurance", "state", "Telangana Govt.", "Group insurance for shepherds", "पशुपालकों के लिए समूह बीमा", A, AH, 74, "goat,sheep"],
  ["Poultry Bird Insurance", "मुर्गी बीमा योजना", "insurance", "central", "General insurers (CSS)", "Cover for broiler & layer birds", "ब्रॉयलर व लेयर पक्षियों का बीमा", A, AH, 72, "hen,duck"],
  ["Cattle Insurance — IFFCO Tokio", "पशु बीमा — इफको टोकियो", "insurance", "private", "IFFCO Tokio", "Quick claim cattle insurance plans", "त्वरित क्लेम पशु बीमा योजनाएँ", A, AH, 70, "cow,buffalo"],
  ["Livestock Floater Cover — New India Assurance", "पशुधन बीमा — न्यू इंडिया एश्योरेंस", "insurance", "private", "New India Assurance", "Herd-level insurance products", "झुंड स्तरीय बीमा उत्पाद", A, AH, 66, "cow,buffalo,goat"],
  ["Dairy Cattle Cover — KMF/Nandini", "दुधारू पशु बीमा — केएमएफ", "insurance", "coop", "Karnataka Milk Federation", "Subsidized insurance via milk societies", "दुग्ध समिति से अनुदानित बीमा", AM, AMH, 76, "cow,buffalo"],

  // ---------- CREDIT (9) ----------
  ["Kisan Credit Card – Animal Husbandry", "किसान क्रेडिट कार्ड – पशुपालन", "credit", "central", "Banks / DAHD", "Working-capital loan at 4% effective interest", "4% प्रभावी ब्याज पर कार्यशील पूंजी ऋण", AL, ALH, 83, "cow,buffalo,goat,sheep,hen"],
  ["Pashu Kisan Credit Card", "पशु किसान क्रेडिट कार्ड", "credit", "state", "State govts. (Haryana model)", "Collateral-free livestock loan", "बिना गारंटी पशुधन ऋण", A, AH, 80, "cow,buffalo,goat"],
  ["AHIDF Loan Scheme", "पशुधन बुनियादी ढाँचा विकास कोष ऋण", "credit", "central", "DAHD / banks", "90% loan + 3% interest subvention", "90% ऋण + 3% ब्याज छूट", AL, ALH, 71, "cow,buffalo,hen,pig"],
  ["Dairy Entrepreneurship Development Loan", "डेयरी उद्यमिता विकास ऋण", "credit", "central", "NABARD refinance", "Back-ended subsidy on dairy loans", "डेयरी ऋण पर पार्श्व अनुदान", AL, ALH, 69, "cow,buffalo"],
  ["PMEGP – Animal Husbandry Units", "प्रधानमंत्री रोज़गार सृजन कार्यक्रम – पशुपालन", "credit", "central", "KVIC / banks", "15–35% subsidy on poultry/goat units", "मुर्गी/बकरी इकाइयों पर 15–35% अनुदान", AL, ALH, 75, "hen,goat,sheep,pig"],
  ["Mudra Loan – Dairy & Livestock", "मुद्रा ऋण – डेयरी व पशुपालन", "credit", "central", "Banks under PMMY", "Up to ₹10 lakh micro loans", "₹10 लाख तक का लघु ऋण", A, AH, 79, "cow,buffalo,goat,hen"],
  ["SC-ST Livestock Unit Assistance", "अनु. जाति-जनजाति पशुधन इकाई सहायता", "credit", "central", "NSKFDC / states", "Special subsidy loans for SC/ST farmers", "अनुसूचित जाति/जनजाति किसानों को विशेष अनुदान ऋण", AL, ALH, 62, "cow,goat,sheep,pig"],
  ["Women Dairy Loan — Mahila Bank", "महिला डेयरी ऋण", "credit", "central", "Public sector banks", "Soft loans for women dairy owners", "महिला पशुपालकों के लिए सौफ्ट ऋण", A, AH, 72, "cow,buffalo"],
  ["Goat Rearing Bank Loan — NABARD", "बकरी पालन बैंक ऋण — नाबार्ड", "credit", "central", "NABARD", "Model projects with 25–33% subsidy", "25–33% अनुदान वाली नमूना परियोजनाएँ", AL, ALH, 74, "goat"],

  // ---------- POULTRY (10) ----------
  ["Rural Backyard Poultry Development", "ग्रामीण पिछवाड़ा मुर्गी पालन", "poultry", "central", "Central Poultry Dev. Org.", "Free/low-cost chicks to women farmers", "महिला किसानों को नि:शुल्क/सस्ते चूज़े", A, AH, 86, "hen,duck"],
  ["Poultry Venture Capital Fund", "पोल्ट्री वेंचर कैपिटल फंड", "poultry", "central", "NABARD / DAHD", "50% capital subsidy for poultry units", "मुर्गी इकाइयों पर 50% पूंजी अनुदान", AL, ALH, 70, "hen"],
  ["Central Poultry Development Organisation", "केंद्रीय पोल्ट्री विकास संगठन", "poultry", "central", "CPDO (DAHD)", "Chicks, training & technical support", "चूज़े, प्रशिक्षण व तकनीकी सहायता", A, AH, 72, "hen,duck"],
  ["Kadaknath Promotion Scheme — MP", "कड़कनाथ संवर्धन योजना — एमपी", "poultry", "state", "MP Govt.", "Subsidy for Kadaknath poultry units", "कड़कनाथ इकाइयों पर अनुदान", A, AH, 65, "hen"],
  ["Aseel Breed Conservation & Distribution", "असील नस्ल संरक्षण कार्यक्रम", "poultry", "central", "ICAR / state AHD", "Improved indigenous chicks on subsidy", "उन्नत देसी चूज़े अनुदान पर", A, AH, 58, "hen"],
  ["Broiler Estate Scheme — Kerala", "ब्रॉयलर एस्टेट योजना — केरल", "poultry", "state", "Kerala Govt.", "Cluster-based broiler farming support", "समूह आधारित ब्रॉयलर पालन सहायता", AL, ALH, 60, "hen"],
  ["Duck Egg Cluster Programme", "बत्तख अंडा क्लस्टर योजना", "poultry", "state", "Coastal state AHDs", "Subsidy for duck rearing groups", "बत्तख पालन समूहों को अनुदान", A, AH, 56, "duck"],
  ["Poultry Feed Subsidy Initiative", "पोल्ट्री चारा अनुदान पहल", "poultry", "state", "State AHD", "Discounted feed for small units", "छोटी इकाइयों के लिए छूट पर चारा", AM, AMH, 55, "hen"],
  ["Layer Bird Unit Assistance — TN", "अंडे देने वाली मुर्गी इकाई सहायता — तामिलनाडु", "poultry", "state", "Tamil Nadu AHD", "50% subsidy for 1000-bird layer units", "1000 मुर्गी इकाइयों पर 50% अनुदान", AL, ALH, 63, "hen"],
  ["Emus & Turkey Pilot Farms", "ईमू व टर्की पायलट फार्म", "poultry", "state", "State AHD pilots", "Pilot support for exotic poultry", "विदेशी मुर्गी पालन हेतु पायलट सहायता", A, AH, 48, "hen"],

  // ---------- GOAT & SHEEP (9) ----------
  ["Telangana Sheep Distribution Scheme", "तेलंगाना भेड़ वितरण योजना", "goatsheep", "state", "Telangana Govt.", "75% subsidy on sheep units for shepherd families", "चरवाहा परिवारों को भेड़ इकाइयों पर 75% अनुदान", AL, ALH, 77, "sheep,goat"],
  ["Mukhyamantri Bakra Palan Yojana — Odisha", "मुख्यमंत्री बकरा पालन योजना — ओडिशा", "goatsheep", "state", "Odisha Govt.", "50% subsidy for goat units", "बकरी इकाइयों पर 50% अनुदान", AL, ALH, 73, "goat"],
  ["Anandadhara Livestock Programme — WB", "आनंदधारा पशुधन कार्यक्रम — प. बंगाल", "goatsheep", "state", "WB Govt.", "SHG-based goat & poultry support", "महिला समूहों के माध्यम से बकरी व मुर्गी सहायता", A, AH, 69, "goat,hen"],
  ["Stall-fed Goat Unit — NABARD Model", "स्थल आधारित बकरी इकाई — नाबार्ड", "goatsheep", "central", "NABARD", "Bank loan + backend subsidy", "बैंक ऋण + पार्श्व अनुदान", AL, ALH, 71, "goat"],
  ["National Wool Mission", "राष्ट्रीय ऊन मिशन", "goatsheep", "central", "Ministry of Textiles", "Sheep health, wool & price support", "भेड़ स्वास्थ्य, ऊन व मूल्य सहायता", A, AH, 60, "sheep"],
  ["Sheep & Wool Improvement Board", "भेड़ व ऊन सुधार बोर्ड", "goatsheep", "central", "CWB", "Breed improvement & wool testing services", "नस्ल सुधार व ऊन परीक्षण सेवाएँ", A, AH, 55, "sheep"],
  ["Integrated Goat Development — BAIF", "एकीकृत बकरी विकास — बाईफ़", "goatsheep", "private", "BAIF Foundation", "Bucks, health & market linkage support", "नस्ली नर बकरे, स्वास्थ्य व बाज़ार सहायता", A, AH, 75, "goat"],
  ["Deccani Sheep Conservation", "दक्कनी भेड़ संरक्षण", "goatsheep", "central", "ICAR-NBAGR", "Conservation incentive for desi breeds", "देसी नस्ल संरक्षण पर प्रोत्साहन", A, AH, 50, "sheep"],
  ["Goat Mobile Veterinary Service — Jharkhand", "बकरी मोबाइल पशु सेवा — झारखंड", "goatsheep", "state", "Jharkhand AHD", "Doorstep treatment for goat herds", "बकरी झुंडों के लिए घर तक इलाज", A, AH, 57, "goat"],

  // ---------- FEED & FODDER (10) ----------
  ["Fodder & Feed Development Sub-Mission", "चारा व पशु आहार विकास उप-मिशन", "feed", "central", "DAHD (under NLM)", "50% subsidy on fodder & feed units", "चारा व पशु आहार इकाइयों पर 50% अनुदान", AL, ALH, 72, "cow,buffalo,goat,sheep"],
  ["Silage Making Subsidy", "साइलेज निर्माण अनुदान", "feed", "state", "State AHD", "Subsidy on silage pits & balers", "साइलेज गड्ढे व बेलर पर अनुदान", AL, ALH, 66, "cow,buffalo"],
  ["Azolla Demonstration Units", "अज़ोला प्रदर्शन इकाइयाँ", "feed", "state", "State AHD / KVK", "Free azolla kits for feed supplementation", "पशु आहार हेतु नि:शुल्क अज़ोला किट", A, AH, 63, "cow,buffalo,goat"],
  ["Mineral Mixture Plants", "खनिज मिश्रण संयंत्र", "feed", "coop", "Milk federations", "Subsidized mineral mixture for members", "सदस्यों को अनुदानित खनिज मिश्रण", AM, AMH, 74, "cow,buffalo"],
  ["Total Mixed Ration (TMR) Plants", "टोटल मिक्स्ड राशन संयंत्र", "feed", "coop", "KMF / GCMMF", "Ready balanced feed on subsidy", "तैयार संतुलित चारा अनुदान पर", AM, AMH, 70, "cow,buffalo"],
  ["Fodder Seed Procurement Programme", "चारा बीज अधिप्राप्ति कार्यक्रम", "feed", "central", "DAHD / SFAC", "Free/subsidized fodder seeds & slips", "नि:शुल्क/अनुदानित चारा बीज व तने", A, AH, 65, "cow,buffalo,goat"],
  ["Hydroponic Fodder Units", "हाइड्रोपोनिक चारा इकाइयाँ", "feed", "private", "Private suppliers + subsidy", "Low-cost green fodder units", "कम लागत हरा चारा इकाइयाँ", AL, ALH, 55, "cow,goat"],
  ["Chaff Cutter Subsidy", "कुट्टी मशीन अनुदान", "feed", "state", "State AHD", "50% subsidy on chaff cutters", "कुट्टी मशीन पर 50% अनुदान", AL, ALH, 68, "cow,buffalo"],
  ["Urea Molasses Block Distribution", "यूरिया मोलासिस ब्लॉक वितरण", "feed", "central", "DAHD pilots", "Free feed-blocks during fodder shortage", "चारे की कमी में नि:शुल्क पोषक ब्लॉक", A, AH, 52, "cow,buffalo,goat"],
  ["Cattle Feed Subsidy — Amul/Federations", "पशु आहार अनुदान — दुग्ध संघ", "feed", "coop", "Federation member unions", "Discount on branded cattle feed", "ब्रांडेड पशु आहार पर छूट", AM, AMH, 77, "cow,buffalo"],

  // ---------- BREEDING (9) ----------
  ["National Artificial Insemination Programme", "राष्ट्रीय कृत्रिम गर्भाधान कार्यक्रम", "breed", "central", "NDDB / DAHD", "Free doorstep AI services in 600+ districts", "600+ जिलों में नि:शुल्क कृत्रिम गर्भाधान", A, AH, 91, "cow,buffalo"],
  ["Sex-Sorted Semen Subsidy", "सेक्स-सॉर्टेड वीर्य अनुदान", "breed", "central", "Under RGM", "90% subsidy: female calf at low cost", "90% अनुदान: कम लागत में मादा बछिया", A, AH, 85, "cow,buffalo"],
  ["Progeny Testing Programme", "संतति परीक्षण कार्यक्रम", "breed", "central", "NDDB", "Elite bulls & pedigree recording support", "उन्नत साँड़ व वंशावली रिकॉर्ड सहायता", AM, AMH, 60, "cow,buffalo"],
  ["Pedigree Selection Programme", "वंशावली चयन कार्यक्रम", "breed", "central", "NDDB", "Bonuses for elite animals' owners", "उन्नत पशुओं के मालिकों को बोनस", AM, AMH, 58, "cow,buffalo"],
  ["Embryo Transfer Technology (ETT) Subsidy", "भ्रूण स्थानांतरण तकनीक अनुदान", "breed", "central", "Under RGM", "High-yield calves via subsidized IVF/ET", "अनुदानित आईवीएफ/ईटी से उच्च उपज बछिया", A, AH, 62, "cow,buffalo"],
  ["Bull Production Programme", "संवर्धित साँड़ उत्पादन कार्यक्रम", "breed", "central", "Semen stations", "Certified semen doses at nominal cost", "प्रमाणित वीर्य न्यूनतम मूल्य पर", A, AH, 64, "cow,buffalo"],
  ["Breed Multiplication Farm Support", "नस्ल गुणन फार्म सहायता", "breed", "central", "Under RGM", "50% subsidy for breed farms", "नस्ल फार्म पर 50% अनुदान", AL, ALH, 57, "cow,buffalo"],
  ["Gaushala Development Grants", "गौशाला विकास अनुदान", "breed", "state", "State Gaushala Aayog", "Support for cow shelters & desi breeds", "गौशाला व देसी नस्लों हेतु सहायता", AL, ALH, 66, "cow"],
  ["Genomic Selection Pilot", "जीनोमिक चयन पायलट", "breed", "central", "ICAR / NBAGR", "DNA-based early breed certificates", "डीएनए आधारित शीघ्र नस्ल प्रमाणपत्र", A, AH, 45, "cow,buffalo"],

  // ---------- INFRASTRUCTURE (10) ----------
  ["Milk Chilling / BMC Subsidy", "दूध शीतलीकरण / बीएमसी अनुदान", "infra", "central", "DIDF / NPDD", "Subsidy for village bulk-milk coolers", "ग्रामीण दूध कूलर के लिए अनुदान", AM, AMH, 68, "cow,buffalo"],
  ["Dairy Processing Plant Support (AHIDF)", "डेयरी प्रसंस्करण संयंत्र सहायता", "infra", "central", "AHIDF", "Loans up to 90% for processing units", "प्रसंस्करण इकाइयों हेतु 90% तक ऋण", AL, ALH, 60, "cow,buffalo"],
  ["Feed Manufacturing Plant (AHIDF)", "पशु आहार संयंत्र (एएचआईडीएफ)", "infra", "central", "AHIDF", "Interest subvention for feed plants", "आहार संयंत्रों पर ब्याज छूट", AL, ALH, 55, "cow,buffalo,hen"],
  ["Goat/Sheep Abattoir Modernization", "बकरा/भेड़ कसाईखाना आधुनिकीकरण", "infra", "state", "State AHD / NLM", "Subsidy for clean meat units", "स्वच्छ मीट यूनिट हेतु अनुदान", AL, ALH, 50, "goat,sheep,pig"],
  ["Semen Station Modernization", "वीर्य केंद्र आधुनिकीकरण", "infra", "central", "DAHD", "Support to govt. semen stations", "सरकारी वीर्य केंद्रों को सहायता", AL, ALH, 46, "cow,buffalo"],
  ["Animal Vaccine Production Grant", "पशु टीका उत्पादन अनुदान", "infra", "state", "State Biol. units", "Grant for local vaccine units", "स्थानीय टीका इकाइयों हेतु अनुदान", AL, ALH, 44, ""],
  ["Veterinary Dispensary Infrastructure", "पशु औषधालय बुनियादी ढाँचा", "infra", "state", "State AHD", "Upgradation of village vet centres", "ग्रामीण पशु केंद्रों का उन्नयन", A, AH, 59, ""],
  ["Bulk Milk Vending Booths", "दूध वेंडिंग बूथ योजना", "infra", "coop", "Milk federations", "Allotment of milk booths to members", "सदस्यों को दूध बूथ आवंटन", AM, AMH, 61, "cow,buffalo"],
  ["Cold-Chain & Milk Tanker Support", "कोल्ड चेन व दूध टैंकर सहायता", "infra", "central", "DIDF", "Loans for milk logistics", "दूध लॉजिस्टिक्स हेतु ऋण", AM, AMH, 53, "cow,buffalo"],
  ["Rusum/Community Cattle Shed", "सामुदायिक पशु शेड योजना", "infra", "state", "State AHD", "Subsidy for community cattle sheds", "सामुदायिक पशु शेड हेतु अनुदान", AL, ALH, 58, "cow,buffalo"],

  // ---------- WOMEN & YOUTH (8) ----------
  ["Mahila Kisan Sashaktikaran — Livestock", "महिला किसान सशक्तिकरण — पशुपालन", "women", "central", "Ministry of RD", "SHG women livestock micro-enterprises", "महिला समूहों के लिए पशुधन लघु उद्यम", A, AH, 74, "goat,hen,cow"],
  ["Women Poultry SHG Units", "महिला पोल्ट्री एसएचजी इकाइयाँ", "women", "state", "State rural missions", "Backyard units via self-help groups", "स्वयं सहायता समूहों से पिछवाड़ा इकाइयाँ", A, AH, 72, "hen"],
  ["A-HELP Women Cadre", "ए-हेल्प महिला कैडर", "training", "central", "NDDB / DAHD", "Paid training as animal-health workers", "पशु स्वास्थ्य कर्मी का भुगतान सहित प्रशिक्षण", A, AH, 68, ""],
  ["ACABC – Agri-Clinics & Agri-Business", "एग्री-क्लीनिक व एग्री-बिज़नेस", "training", "central", "MANAGE / NABARD", "45% subsidy for agri-graduates' vet ventures", "कृषि स्नातकों के पशु उद्यम पर 45% अनुदान", AL, ALH, 60, ""],
  ["Skill Training of Rural Youth (STRY)", "ग्रामीण युवा कौशल प्रशिक्षण", "training", "central", "MANAGE / KVK", "Free livestock-farming skill courses", "नि:शुल्क पशुपालन कौशल पाठ्यक्रम", A, AH, 70, ""],
  ["Dairy Farm Apprenticeship", "डेयरी फार्म अपरेंटिसशिप", "training", "coop", "Milk unions", "Stipend + hands-on dairy training", "वेतन सहित डेयरी व्यावहारिक प्रशिक्षण", A, AH, 62, "cow,buffalo"],
  ["SC Livestock Entrepreneurship", "अनु. जाति पशु उद्यमिता योजना", "women", "central", "NSKFDC", "Priority subsidy loans", "प्राथमिकता अनुदान ऋण", AL, ALH, 64, "goat,pig,hen"],
  ["Youth Goat Enterprise — North-East", "युवा बकरी उद्यम — पूर्वोत्तर", "women", "state", "NE state missions", "Start-up kits for young herders", "युवा पशुपालकों के लिए स्टार्ट-अप किट", A, AH, 59, "goat"],

  // ---------- TRAINING (6) ----------
  ["KVK Livestock Training", "केवीके पशुपालन प्रशिक्षण", "training", "central", "Krishi Vigyan Kendra", "Free on-farm livestock training", "नि:शुल्क फार्म स्तरीय पशुपालन प्रशिक्षण", A, AH, 82, ""],
  ["NDDB Vidya Courses", "एनडीडीबी विद्या पाठ्यक्रम", "training", "coop", "NDDB", "Dairy management certificate courses", "डेयरी प्रबंधन प्रमाणपत्र पाठ्यक्रम", A, AH, 57, ""],
  ["Farmer FIRST Programme", "किसान प्रथम कार्यक्रम", "training", "central", "ICAR", "Scientist-farmer livestock models", "वैज्ञानिक-किसान पशु मॉडल", A, AH, 54, ""],
  ["ATMA Exposure Visits", "आत्मा भ्रमण कार्यक्रम", "training", "central", "ATMA", "Free exposure trips to model farms", "नमूना फार्मों की नि:शुल्क भ्रमण यात्रा", A, AH, 66, ""],
  ["Pashu Sakhi Fellowship", "पशु सखी फैलोशिप", "training", "private", "NGO networks", "Trained paid village para-vets", "प्रशिक्षित वेतनभोगी ग्राम पशु सहायक", A, AH, 63, ""],
  ["Extension Officers' Camps", "प्रसार अधिकारी शिविर", "training", "state", "State AHD", "Regular village advisory camps", "नियमित ग्राम सलाह शिविर", A, AH, 71, ""],

  // ---------- MARKETING (7) ----------
  ["Dairy Marketing Assistance (NDS)", "डेयरी विपणन सहायता", "market", "coop", "NDDB Dairy Services", "Procurement price stabilization", "खरीद मूल्य स्थिरीकरण सहायता", AM, AMH, 62, "cow,buffalo"],
  ["Wool Marketing Support Price", "ऊन विपणन समर्थन मूल्य", "market", "central", "CWB", "Minimum price for raw wool", "कच्ची ऊन के लिए न्यूनतम मूल्य", A, AH, 56, "sheep"],
  ["NECC Egg Pricing Network", "एनईसीसी अंडा मूल्य नेटवर्क", "market", "private", "NECC", "Daily egg rate declaration for farmers", "किसानों हेतु दैनिक अंडा भाव", A, AH, 73, "hen"],
  ["Pashu Haat Digitization Pilots", "पशु हाट डिजिटलीकरण पायलट", "market", "state", "State AHD", "Verified animal trading platforms", "सत्यापित पशु खरीद-बिक्री प्लेटफ़ॉर्म", A, AH, 50, ""],
  ["Milk Price Incentive Schemes", "दूध मूल्य प्रोत्साहन योजनाएँ", "market", "state", "State federations", "Per-litre bonus for members", "सदस्यों को प्रति लीटर बोनस", AM, AMH, 75, "cow,buffalo"],
  ["Organic Milk Premium Programme", "ऑर्गेनिक दूध प्रीमियम कार्यक्रम", "market", "private", "Organic dairies", "Premium rates for organic milk", "ऑर्गेनिक दूध हेतु अधिक भाव", AM, AMH, 58, "cow"],
  ["Melghat/Cluster Branding Pilots", "क्लस्टर ब्रांडिंग पायलट", "market", "private", "CSR programmes", "Farmer-brand milk & ghee marketing", "किसान ब्रांड दूध-घी विपणन", A, AH, 47, "cow,buffalo"],

  // ---------- PRIVATE / CO-OP & CSR (17) ----------
  ["Verka Milkfed Schemes — Punjab", "वेरका मिल्कफेड योजनाएँ — पंजाब", "private", "coop", "Punjab State Co-op (Verka)", "Milk procurement, feed & vet support", "दूध खरीद, चारा व पशु चिकित्सा सहायता", AM, AMH, 79, "cow,buffalo"],
  ["Sudha Village Co-ops — COMPFED", "सुधा ग्राम समितियाँ — बिहार", "private", "coop", "COMPFED (Sudha)", "Assured milk collection & bonus", "दूध संग्रह की गारंटी व बोनस", AM, AMH, 78, "cow,buffalo"],
  ["Nandini Dairy Societies — KMF", "नंदिनी दुग्ध समितियाँ — कर्नाटक", "private", "coop", "Karnataka Milk Federation", "Dairy co-op membership benefits", "दुग्ध सहकारी सदस्यता लाभ", AM, AMH, 80, "cow,buffalo"],
  ["Aavin Co-ops — Tamil Nadu", "आविन समितियाँ — तमिलनाडु", "private", "coop", "Tamil Nadu Co-op Milk", "Village dairy societies & subsidy feed", "ग्राम दुग्ध समितियाँ व अनुदानित चारा", AM, AMH, 77, "cow,buffalo"],
  ["Milma Network — Kerala", "मिल्मा नेटवर्क — केरल", "private", "coop", "Kerala Co-op Milk Fed.", "Stable procurement + input subsidy", "स्थिर खरीद + आव्यय अनुदान", AM, AMH, 76, "cow,buffalo"],
  ["OMFED Network — Odisha", "ओमफेड नेटवर्क — ओडिशा", "private", "coop", "Odisha Milk Fed.", "Milk unions with farmer training", "किसान प्रशिक्षण सहित दुग्ध संघ", AM, AMH, 70, "cow,buffalo"],
  ["Purabi Dairy — Assam", "पुराबी डेयरी — असम", "private", "coop", "WAMUL (Purabi)", "Milk collection & training for members", "सदस्यों हेतु दूध संग्रह व प्रशिक्षण", AM, AMH, 72, "cow"],
  ["Saras — RCDF Network — Rajasthan", "सरस — आरसीडीएफ — राजस्थान", "private", "coop", "Rajasthan Co-op Dairy Fed.", "Procurement & input support", "खरीद व आव्यय सहायता", AM, AMH, 74, "cow,buffalo"],
  ["Goa Dairy Network", "गोवा डेयरी नेटवर्क", "private", "coop", "Goa Milk Producers' Union", "Village societies & vet services", "ग्राम समितियाँ व पशु सेवाएँ", AM, AMH, 69, "cow,buffalo"],
  ["Nestlé Moga Milk District", "नेस्ले मोगा दुग्ध क्षेत्र", "private", "private", "Nestlé India", "Vet & feed advisory with procurement", "खरीद के साथ पशु चिकित्सा व चारा सलाह", AM, AMH, 71, "cow,buffalo"],
  ["Hatsun Farmer Network", "हाटसन किसान नेटवर्क", "private", "private", "Hatsun Agro (Aavin pvt.)", "Direct procurement & input credit", "सीधी खरीद व आव्यय ऋण", AM, AMH, 68, "cow,buffalo"],
  ["Suguna Contract Poultry Farming", "सुगुना अनुबंध ब्रॉयलर पालन", "private", "private", "Suguna Foods", "Chicks, feed & buyback for broilers", "ब्रॉयलर हेतु चूज़े, चारा व खरीद गारंटी", AL, ALH, 73, "hen"],
  ["Venky's Farmer Support", "वेंकीज किसान सहायता", "private", "private", "VH Group (Venky's)", "Broiler/chick supply & technical help", "ब्रॉयलर/चूज़ा आपूर्ति व तकनीकी सहायता", AL, ALH, 70, "hen"],
  ["Godrej Agrovet Livestock Support", "गोदरेज एग्रोवेट पशुधन सहायता", "private", "private", "Godrej Agrovet", "Feed, vet advisory & oil-linked farms", "चारा, पशु सलाह व संबद्ध फार्म", A, AH, 63, "cow,pig,hen"],
  ["De Heus Nutrition Programmes", "डी ह्यूस पोषण कार्यक्रम", "private", "private", "De Heus India", "Balanced feed formulations & advisory", "संतुलित चारा फॉर्मूला व सलाह", AM, AMH, 60, "cow,hen"],
  ["Tata Trusts Livestock Programmes", "टाटा ट्रस्टस पशुधन कार्यक्रम", "private", "private", "Tata Trusts", "Dairy clusters & para-vet training", "डेयरी क्लस्टर व पशु सहायक प्रशिक्षण", A, AH, 61, "cow,goat"],
  ["Chitale Dairy Farmer Services", "चिताले डेयरी किसान सेवाएँ", "private", "private", "Chitale Dairy", "High-tech farm support & buyback", "उच्च तकनीक फार्म सहायता व खरीद", AM, AMH, 59, "cow,buffalo"],
];

export const SCHEMES: Scheme[] = ROWS.map((r, i) => ({
  id: i + 1,
  name: r[0],
  nameHi: r[1],
  cat: r[2],
  type: r[3],
  org: r[4],
  benefit: r[5],
  benefitHi: r[6],
  docs: r[7],
  docsHi: r[8],
  base: r[9],
  animals: r[10] ? r[10].split(",") : [],
}));

export interface SchemeWithMatch extends Scheme {
  match: number;
}

function hash(n: number): number {
  let x = n * 2654435761;
  x = (x ^ (x >>> 16)) >>> 0;
  return x;
}

export function withMatch(schemes: Scheme[], animalTypes: string[], profileComplete: boolean): SchemeWithMatch[] {
  return schemes.map((s) => {
    let m = s.base;
    if (s.animals && s.animals.length > 0 && s.animals.some((a) => animalTypes.includes(a))) m += 8;
    if (profileComplete) m += 4;
    m += (hash(s.id * 97 + animalTypes.length * 13) % 7); // deterministic variety 0-6
    return { ...s, match: Math.min(97, Math.max(30, m)) };
  });
}
