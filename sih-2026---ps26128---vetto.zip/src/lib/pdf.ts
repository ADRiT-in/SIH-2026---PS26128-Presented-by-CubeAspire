"use client";

import { jsPDF } from "jspdf";

export interface PdfNoteInput {
  title: string;
  body: string;
  animalLabel: string;
  dateStr: string;
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    const test = line ? line + " " + w : w;
    if (ctx.measureText(test).width > maxW && line) {
      lines.push(line);
      line = w;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}

/** Force a real download into the device's storage (works on Android/iOS/desktop). */
function saveBlob(blob: Blob, filename: string): void {
  const nav = navigator as Navigator & {
    msSaveOrOpenBlob?: (b: Blob, n: string) => boolean;
  };
  if (typeof nav.msSaveOrOpenBlob === "function") {
    nav.msSaveOrOpenBlob(blob, filename);
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 4000);
}

export async function downloadNotePdf(note: PdfNoteInput): Promise<void> {
  // Make sure webfonts (incl. Devanagari) are ready before painting the canvas.
  try {
    if (typeof document !== "undefined" && document.fonts?.ready) {
      await Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 1500))]);
    }
  } catch { /* fonts API unavailable — continue */ }

  const W = 1240;
  const H = 1754; // A4 ratio at ~150dpi
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");

  // Background — warm cream
  ctx.fillStyle = "#fffaf0";
  ctx.fillRect(0, 0, W, H);

  // Header band
  const grad = ctx.createLinearGradient(0, 0, W, 0);
  grad.addColorStop(0, "#f97316");
  grad.addColorStop(1, "#16a34a");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, 26);

  // Watermark — repeated "VETTO AI"
  ctx.save();
  ctx.translate(W / 2, H / 2);
  ctx.rotate(-Math.PI / 6);
  ctx.font = "900 120px 'Sora', 'Noto Sans Devanagari', sans-serif";
  ctx.fillStyle = "rgba(190, 130, 60, 0.07)";
  ctx.textAlign = "center";
  for (let y = -H; y <= H; y += 260) {
    ctx.fillText("VETTO AI", 0, y);
  }
  ctx.restore();

  // Brand
  ctx.textAlign = "left";
  ctx.font = "800 46px 'Sora', sans-serif";
  ctx.fillStyle = "#ea7a1c";
  ctx.fillText("VETTO", 70, 110);
  ctx.font = "600 24px 'Sora', 'Noto Sans Devanagari', sans-serif";
  ctx.fillStyle = "#8a7350";
  ctx.fillText("My Livestock Note", 70, 150);

  // Divider
  ctx.strokeStyle = "rgba(122, 84, 32, 0.25)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(70, 180);
  ctx.lineTo(W - 70, 180);
  ctx.stroke();

  // Meta
  ctx.font = "600 26px 'Sora', 'Noto Sans Devanagari', sans-serif";
  ctx.fillStyle = "#7c6a4d";
  ctx.fillText(note.animalLabel, 70, 225);
  ctx.textAlign = "right";
  ctx.fillText(note.dateStr, W - 70, 225);
  ctx.textAlign = "left";

  // Title
  ctx.font = "800 44px 'Sora', 'Noto Sans Devanagari', sans-serif";
  ctx.fillStyle = "#2b1d0e";
  let y = 290;
  for (const ln of wrapText(ctx, note.title || "Note", W - 140)) {
    ctx.fillText(ln, 70, y);
    y += 56;
  }
  y += 12;

  // Body
  ctx.font = "400 30px 'Noto Sans Devanagari', 'Sora', sans-serif";
  ctx.fillStyle = "#4a3c26";
  const paragraphs = note.body.split(/\n+/);
  for (const p of paragraphs) {
    if (!p.trim()) {
      y += 22;
      continue;
    }
    for (const ln of wrapText(ctx, p, W - 150)) {
      if (y > H - 140) break;
      ctx.fillText(ln, 70, y);
      y += 46;
    }
    y += 14;
    if (y > H - 140) break;
  }

  // Footer
  ctx.font = "600 22px 'Sora', 'Noto Sans Devanagari', sans-serif";
  ctx.fillStyle = "#a08c66";
  ctx.fillText("Made with VETTO — A One-Stop Solution for Pastoralists", 70, H - 60);
  ctx.fillStyle = grad;
  ctx.fillRect(0, H - 20, W, 20);

  const img = canvas.toDataURL("image/jpeg", 0.92);

  const safe =
    (note.title || "note").replace(/[^a-z0-9\u0900-\u097F]+/gi, "-").slice(0, 40).replace(/^-|-$/g, "") || "note";
  const filename = `vetto-note-${safe}.pdf`;

  const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
  pdf.addImage(img, "JPEG", 0, 0, 210, 297);

  // Primary path: explicit Blob → anchor download (most reliable on mobile browsers).
  try {
    const blob = pdf.output("blob") as Blob;
    saveBlob(blob, filename);
    return;
  } catch {
    // Fallback: jsPDF's own save()
    pdf.save(filename);
  }
}
