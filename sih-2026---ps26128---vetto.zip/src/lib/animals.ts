export type AnimalType =
  | "cow" | "buffalo" | "goat" | "sheep" | "hen"
  | "ox" | "horse" | "donkey" | "pig" | "duck";

export const ANIMAL_TYPES: AnimalType[] = [
  "cow", "buffalo", "goat", "sheep", "hen", "ox", "horse", "donkey", "pig", "duck",
];

export const ANIMAL_META: Record<
  AnimalType,
  { en: string; enP: string; hi: string; hiP: string; hue: string }
> = {
  cow:     { en: "Cow",     enP: "Cows",     hi: "गाय",      hiP: "गायें",      hue: "from-amber-400 to-orange-500" },
  buffalo: { en: "Buffalo", enP: "Buffaloes",hi: "भैंस",     hiP: "भैंसें",     hue: "from-slate-500 to-slate-700" },
  goat:    { en: "Goat",    enP: "Goats",    hi: "बकरी",     hiP: "बकरियाँ",    hue: "from-emerald-400 to-green-600" },
  sheep:   { en: "Sheep",   enP: "Sheep",    hi: "भेड़",     hiP: "भेड़ें",     hue: "from-stone-300 to-stone-500" },
  hen:     { en: "Hen",     enP: "Hens",     hi: "मुर्गी",   hiP: "मुर्गियाँ",  hue: "from-rose-400 to-red-500" },
  ox:      { en: "Ox",      enP: "Oxen",     hi: "बैल",      hiP: "बैल",        hue: "from-yellow-500 to-amber-600" },
  horse:   { en: "Horse",   enP: "Horses",   hi: "घोड़ा",    hiP: "घोड़े",      hue: "from-orange-500 to-red-600" },
  donkey:  { en: "Donkey",  enP: "Donkeys",  hi: "गधा",      hiP: "गधे",        hue: "from-zinc-400 to-zinc-600" },
  pig:     { en: "Pig",     enP: "Pigs",     hi: "सूअर",     hiP: "सूअर",       hue: "from-pink-400 to-rose-500" },
  duck:    { en: "Duck",    enP: "Ducks",    hi: "बत्तख",    hiP: "बत्तखें",    hue: "from-sky-400 to-blue-500" },
};

export function animalLabel(type: string, lang: "en" | "hi", plural = true): string {
  const meta = ANIMAL_META[type as AnimalType];
  if (!meta) return type;
  if (lang === "hi") return plural ? meta.hiP : meta.hi;
  return plural ? meta.enP : meta.en;
}

export const QUANTITY_OPTIONS = ["1", "2", "3", "4", "5", "6-10", "11-25", "25+"] as const;

export function qtyToNumber(q: string): number {
  if (q === "6-10") return 8;
  if (q === "11-25") return 18;
  if (q === "25+") return 30;
  return parseInt(q, 10) || 1;
}
