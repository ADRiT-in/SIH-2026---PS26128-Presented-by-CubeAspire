"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Home, PawPrint, ClipboardList, Landmark, Languages,
  Moon, Sun, Wifi, WifiOff, ChevronDown, CheckCircle2, Stethoscope, Sprout, Repeat2, UserRound,
} from "lucide-react";
import { StoreProvider, useStore } from "@/lib/store";
import { LANGS, Lang } from "@/lib/i18n";
import Login from "@/components/Login";
import HomePage from "@/components/screens/Home";
import AnimalsPage from "@/components/screens/Animals";
import ReportsPage from "@/components/screens/Reports";
import SchemesPage from "@/components/screens/Schemes";
import RoleSelect from "@/components/RoleSelect";
import VetConsole from "@/components/vet/VetConsole";
import ProfileSheet from "@/components/ProfileSheet";
import VettoAI from "@/components/VettoAI";
import { Modal } from "@/components/ui";

export type Tab = "home" | "animals" | "reports" | "schemes";
export type AiMode = "closed" | "panel" | "full";

interface Nav {
  tab: Tab;
  anchor?: "vaccines" | "weather" | "help";
}

function LanguageMenu() {
  const { lang, setLang, t } = useStore();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        aria-label={t("navHome") && "Language"}
        onClick={() => setOpen((o) => !o)}
        className="btn-press flex h-10 items-center gap-1.5 rounded-full border border-line bg-surface px-3 text-[13px] font-bold"
      >
        <Languages size={16} className="text-brand" />
        <span className="hidden min-[380px]:inline">{lang === "hi" ? "हिं" : "EN"}</span>
        <ChevronDown size={13} className="text-soft" />
      </button>
      {open && (
        <div className="glass-strong pop-in absolute right-0 top-12 z-[80] w-44 overflow-hidden rounded-2xl p-1.5">
          <p className="px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wider text-faint">
            Language
          </p>
          {LANGS.map((l: { id: Lang; label: string; native: string }) => (
            <button
              key={l.id}
              onClick={() => {
                setLang(l.id);
                setOpen(false);
              }}
              className={`btn-press flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-[14px] font-semibold ${
                lang === l.id ? "bg-gradient-to-r from-amber-500/15 to-emerald-500/15" : ""
              }`}
            >
              <span>{l.native}</span>
              {lang === l.id && <span className="h-2 w-2 rounded-full bg-gradient-to-r from-orange-500 to-green-600" />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function OnlineToggle() {
  const { online, manualOffline, setManualOffline, t } = useStore();
  return (
    <button
      aria-label={online ? t("online") : t("offline")}
      onClick={() => setManualOffline(!manualOffline)}
      className={`btn-press flex h-10 items-center gap-1.5 rounded-full border px-2.5 text-[12px] font-bold transition-colors ${
        online
          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-600 dark:text-emerald-300"
          : "border-red-400/40 bg-red-500/10 text-red-500"
      }`}
    >
      {online ? <Wifi size={15} /> : <WifiOff size={15} />}
      <span className="relative mr-0.5 h-4 w-7 rounded-full bg-black/15 dark:bg-white/15">
        <span
          className={`absolute top-0.5 h-3 w-3 rounded-full transition-all ${
            online ? "left-3.5 bg-emerald-500" : "left-0.5 bg-red-400"
          }`}
        />
      </span>
    </button>
  );
}

function ThemeToggle() {
  const { theme, setTheme, t } = useStore();
  return (
    <button
      aria-label={t("profile")}
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className="btn-press grid h-10 w-10 place-items-center rounded-full border border-line bg-surface"
    >
      {theme === "dark" ? <Sun size={17} className="text-amber-300" /> : <Moon size={17} className="text-amber-700" />}
    </button>
  );
}

function Shell() {
  const store = useStore();
  const { session, t, profile, online, theme } = store;
  const [nav, setNav] = useState<Nav>({ tab: "home" });
  const [aiMode, setAiMode] = useState<AiMode>("closed");
  const [aiIntent, setAiIntent] = useState<"chat" | "photo" | "voice">("chat");
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileSaved, setProfileSaved] = useState(false);
  const mainRef = useRef<HTMLDivElement>(null);

  const go = (tab: Tab, anchor?: Nav["anchor"]) => {
    setNav({ tab, anchor });
    requestAnimationFrame(() => {
      mainRef.current?.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    });
  };

  const openAi = (intent: "chat" | "photo" | "voice" = "chat") => {
    setAiIntent(intent);
    setAiMode("panel");
  };

  if (!store.hydrated) {
    return (
      <div className="grid min-h-screen place-items-center app-aura">
        <div className="text-center">
          <p className="font-display text-[40px] font-black tracking-tight">
            <span className="grad-brand text-[52px]">V</span>ETTO
          </p>
          <div className="mx-auto mt-4 h-1.5 w-24 overflow-hidden rounded-full bg-black/10 dark:bg-white/10">
            <div className="shimmer h-full w-full rounded-full bg-gradient-to-r from-orange-500 to-green-600" />
          </div>
        </div>
      </div>
    );
  }

  if (!session) return <Login />;
  if (!store.role) return <RoleSelect />;

  const firstName = (profile.name || "").trim().split(/\s+/)[0];
  const isVetView = store.activeView === "vet";
  const canSwitch = store.role === "guest";

  const tabs: { id: Tab; icon: React.ReactNode; label: string }[] = [
    { id: "home", icon: <Home size={21} />, label: t("navHome") },
    { id: "animals", icon: <PawPrint size={21} />, label: t("navAnimals") },
    { id: "reports", icon: <ClipboardList size={21} />, label: t("navReports") },
    { id: "schemes", icon: <Landmark size={21} />, label: t("navSchemes") },
  ];

  return (
    <div className={`relative min-h-screen app-aura`}>
      {/* Cinematic blurred backdrop */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          backgroundImage: "url(/img/login-hero.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: theme === "dark" ? 0.16 : 0.1,
          filter: "blur(26px) saturate(1.1)",
          transform: "scale(1.08)",
        }}
      />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-[560px] flex-col border-x border-line/60">
        {/* ---------- OPAQUE HEADER ---------- */}
          <header className="bar-solid sticky top-0 z-[60] flex h-[64px] items-center justify-between gap-2 px-3.5">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setProfileOpen(true)}
                aria-label={t("profile")}
                className="btn-press flex items-center gap-2.5 rounded-full py-1 pl-1 pr-2"
              >
                <span className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-orange-500 to-green-600 p-[2.5px] shadow-md">
                  <span className="grid h-full w-full place-items-center overflow-hidden rounded-full bg-[var(--bg-2)]">
                    {profile.photo ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={profile.photo} alt="profile" className="h-full w-full object-cover" />
                    ) : (
                      <span className="font-display text-[16px] font-black text-brand">
                        {(firstName || "F")[0].toUpperCase()}
                      </span>
                    )}
                  </span>
                </span>
                <span className="hidden min-[380px]:block text-left">
                  <span className="block text-[10px] font-semibold text-faint leading-none">{t("namaste")}</span>
                  <span className="block font-display text-[13.5px] font-bold leading-tight">{firstName || t("farmer")}</span>
                </span>
              </button>

              <div className="flex items-center gap-1 select-none" onClick={() => go("home")}>
                <span className="font-display cursor-pointer text-[21px] font-black tracking-tight">
                  <span className="grad-brand text-[25px]">V</span>ETTO
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <OnlineToggle />
              <LanguageMenu />
              <ThemeToggle />
            </div>
          </header>

          {/* ---------- OFFLINE BANNER ---------- */}
          {!online && (
            <div className="pop-in sticky top-[64px] z-[55] flex items-center gap-2 border-b border-red-400/30 bg-red-500/90 px-4 py-2 text-[12px] font-semibold text-white backdrop-blur">
              <WifiOff size={14} className="shrink-0" />
              <p className="leading-snug">{t("offlineBanner")}</p>
            </div>
          )}

          {/* ---------- MAIN CONTENT ---------- */}
          <main ref={mainRef} className="nice-scroll relative z-10 flex-1 overflow-y-auto px-4 pb-32 pt-4">
            
              {canSwitch && (
                <div className="fade-up mb-6 flex items-center gap-1.5 rounded-full border border-line bg-surface p-1 max-w-md">
                  <span className="ml-1.5 rounded-full bg-gradient-to-r from-orange-500 to-green-600 px-2 py-0.5 text-[9px] font-black text-white">
                    {t("guestBadge")}
                  </span>
                  {([["farmer", t("farmerView"), <Sprout key="a" size={14} />], ["vet", t("vetView"), <Stethoscope key="b" size={14} />]] as const).map(
                    ([id, label, icon]) => (
                      <button
                        key={id}
                        onClick={() => store.setActiveView(id as "farmer" | "vet")}
                        className={`btn-press flex h-9 flex-1 items-center justify-center gap-1.5 rounded-full text-[12.5px] font-bold transition-all ${
                          store.activeView === id
                            ? "bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow"
                            : "text-soft hover:bg-black/5"
                        }`}
                      >
                        {icon} {label}
                      </button>
                    )
                  )}
                  <Repeat2 size={14} className="mr-1.5 shrink-0 text-faint" />
                </div>
              )}

              {isVetView ? (
                <VetConsole />
              ) : (
                <>
                  {nav.tab === "home" && <HomePage go={go} openAi={openAi} />}
                  {nav.tab === "animals" && <AnimalsPage anchor={nav.anchor} />}
                  {nav.tab === "reports" && <ReportsPage />}
                  {nav.tab === "schemes" && <SchemesPage />}
                </>
              )}
        </main>
          

          {/* ---------- MOBILE TASKBAR ---------- */}
          <nav className="bar-solid-bottom sticky bottom-0 z-[60] mx-0 flex items-end justify-around rounded-t-[26px] px-1.5 pb-3 pt-2">
            {!isVetView &&
              tabs.slice(0, 2).map((tb) => (
                <TaskBtn key={tb.id} active={nav.tab === tb.id} onClick={() => go(tb.id)} icon={tb.icon} label={tb.label} wide />
              ))}

            {isVetView && (
              <TaskBtn
                active
                onClick={() => mainRef.current?.scrollTo({ top: 0, behavior: "smooth" })}
                icon={<Stethoscope size={21} />}
                label={t("caseQueue")}
                wide
              />
            )}

            {/* Vetto AI — centre of taskbar */}
            <div className="relative -top-4 flex shrink-0 flex-col items-center px-0.5">
              <button
                aria-label={t("aiMitr")}
                onClick={() => openAi("chat")}
                className="ai-orb btn-press relative grid h-[58px] w-[58px] place-items-center overflow-hidden rounded-full bg-gradient-to-br from-orange-500 via-amber-500 to-green-600 p-[3px] shadow-xl"
              >
                <span className="grid h-full w-full place-items-center overflow-hidden rounded-full bg-black/85">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src="/img/ai-logo.png" alt="Vetto AI" className="h-[86%] w-[86%] rounded-full object-cover" />
                </span>
              </button>
              <span className="mt-1 text-[9px] font-black tracking-wide text-brand">{t("aiMitr")}</span>
            </div>

            {!isVetView &&
              tabs.slice(2).map((tb) => (
                <TaskBtn key={tb.id} active={nav.tab === tb.id} onClick={() => go(tb.id)} icon={tb.icon} label={tb.label} wide />
              ))}

            {isVetView && (
              <TaskBtn
                active={false}
                onClick={() => setProfileOpen(true)}
                icon={<UserRound size={21} />}
                label={t("profile")}
                wide
              />
            )}
          </nav>
      </div>

      {/* ---------- OVERLAYS ---------- */}
      <ProfileSheet
        open={profileOpen}
        onClose={() => setProfileOpen(false)}
        onSaved={() => {
          setProfileOpen(false);
          go("home");
          setTimeout(() => setProfileSaved(true), 220);
        }}
      />
      <Modal open={profileSaved} onClose={() => setProfileSaved(false)} title="">
        <div className="text-center">
          <span className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-orange-500 to-green-600 text-white shadow-lg shadow-emerald-500/30">
            <CheckCircle2 size={30} />
          </span>
          <p className="font-display text-[17px] font-black leading-snug">{t("profileUpdated")}</p>
          <p className="mt-1 text-[12.5px] text-soft">{t("profileUpdatedSub")}</p>
          <button
            onClick={() => setProfileSaved(false)}
            className="btn-brand btn-press mt-5 h-12 w-full rounded-2xl font-display font-bold"
          >
            {t("ok")}
          </button>
        </div>
      </Modal>
      <VettoAI
        mode={aiMode}
        setMode={setAiMode}
        intent={aiIntent}
        setIntent={setAiIntent}
      />
    </div>
  );
}

function TaskBtn({
  active, onClick, icon, label, wide,
}: {
  active: boolean; onClick: () => void; icon: React.ReactNode; label: string; wide?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={`group flex flex-col items-center gap-0.5 rounded-2xl px-2 py-1 transition-all ${wide ? "min-w-[62px]" : "min-w-[54px]"}`}
    >
      <span
        className={`grid h-9 w-9 place-items-center rounded-xl transition-all duration-300 ${
          active
            ? "bg-gradient-to-br from-orange-500 to-green-600 text-white shadow-lg shadow-orange-500/30"
            : "text-soft group-hover:scale-110 group-hover:text-brand"
        }`}
      >
        {icon}
      </span>
      <span className={`max-w-[70px] truncate text-[10px] font-bold leading-tight ${active ? "text-brand" : "text-faint"}`}>
        {label}
      </span>
    </button>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
