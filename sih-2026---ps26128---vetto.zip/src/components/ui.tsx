"use client";

import React from "react";
import { X } from "lucide-react";

export function SectionTitle({
  icon, title, sub, right,
}: {
  icon?: React.ReactNode; title: string; sub?: string; right?: React.ReactNode;
}) {
  return (
    <div className="mb-3 flex items-start justify-between gap-3">
      <div className="flex items-start gap-2.5">
        {icon && (
          <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-amber-400/90 to-emerald-500/90 text-white shadow-md">
            {icon}
          </span>
        )}
        <div>
          <h2 className="font-display text-[17px] font-bold leading-tight">{title}</h2>
          {sub && <p className="text-[12.5px] text-soft">{sub}</p>}
        </div>
      </div>
      {right}
    </div>
  );
}

export function EmptyState({
  icon, title, sub,
}: {
  icon: React.ReactNode; title: string; sub?: string;
}) {
  return (
    <div className="glass fade-up mx-1 rounded-[32px] p-8 text-center border-dashed border-2">
      <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-orange-500/10 to-green-600/10 text-brand/60">
        {icon}
      </div>
      <p className="font-display font-black text-lg leading-tight">{title}</p>
      {sub && <p className="mt-2 text-sm text-soft leading-relaxed max-w-[240px] mx-auto">{sub}</p>}
    </div>
  );
}

export function Modal({
  open, onClose, children, title,
}: {
  open: boolean; onClose: () => void; children: React.ReactNode; title?: string;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[90] flex items-end justify-center bg-black/50 p-3 backdrop-blur-md sm:items-center animate-[fade-up_.25s_ease_both]"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="glass-strong pop-in w-full max-w-md rounded-[32px] p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          {title ? <h3 className="font-display text-xl font-black tracking-tight">{title}</h3> : <span />}
          <button
            onClick={onClose}
            aria-label="Close"
            className="btn-press focus-visible:ring-2 focus-visible:ring-saffron grid h-10 w-10 place-items-center rounded-full border border-line bg-surface text-soft shadow-sm"
          >
            <X size={20} />
          </button>
        </div>
        <div className="nice-scroll max-h-[75vh] overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
}

export function Tag({ children, tone = "normal" }: { children: React.ReactNode; tone?: "normal" | "ok" | "warn" | "bad" }) {
  const cls =
    tone === "ok"
      ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/20"
      : tone === "warn"
      ? "bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/20"
      : tone === "bad"
      ? "bg-red-500/10 text-red-700 dark:text-red-300 border-red-500/20"
      : "bg-black/5 dark:bg-white/5 border-line text-soft";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-bold tracking-wide uppercase ${cls}`}>
      {children}
    </span>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-4 text-soft text-sm font-bold">
      <span className="h-8 w-8 animate-spin rounded-full border-[3px] border-line border-t-brand" />
      {label && <span className="animate-pulse">{label}</span>}
    </div>
  );
}
