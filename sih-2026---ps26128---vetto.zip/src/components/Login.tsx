"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Smartphone, UserRound, Sprout, HeartPulse, TrendingUp,
  ShieldCheck, ChevronLeft, Sparkles,
} from "lucide-react";
import { useStore } from "@/lib/store";

/** Username = everything before "@", tidied into a readable name. */
export function usernameFromEmail(email: string): string {
  const raw = (email.split("@")[0] || "").trim();
  if (!raw) return "";
  return raw
    .replace(/[._\-+]+/g, " ")
    .replace(/\d+/g, "")
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ") || raw;
}

function GoogleMark() {
  return (
    <svg width="19" height="19" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.9 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.0 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.2-.1-2.3-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.0 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.2 26.7 36 24 36c-5.2 0-9.6-3.1-11.3-7.5l-6.5 5C9.6 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.1 5.6l6.2 5.2C39.8 35.9 44 30.6 44 24c0-1.2-.1-2.3-.4-3.5z" />
    </svg>
  );
}

function demoCodeFor(phone: string): string {
  let h = 0;
  for (let i = 0; i < phone.length; i++) h = (h * 31 + phone.charCodeAt(i)) >>> 0;
  return String(1000 + (h % 9000));
}

export default function Login() {
  const { login, saveProfile, profile } = useStore();
  const [mode, setMode] = useState<"phone" | "otp" | "google">("phone");
  const [gEmail, setGEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [err, setErr] = useState("");
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [sending, setSending] = useState(false);
  const [shake, setShake] = useState(false);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);
  const [t, setT] = useState(30);

  // reuse translations lazily
  const store = useStore();
  const tr = store.t;

  useEffect(() => {
    if (mode !== "otp") return;
    setT(30);
    const id = setInterval(() => setT((x) => (x > 0 ? x - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, [mode]);

  const valid = /^[6-9]\d{9}$/.test(phone);
  const code = demoCodeFor(phone || "0000000000");

  const sendOtp = () => {
    if (!valid) {
      setErr(tr("phoneInvalid"));
      return;
    }
    setErr("");
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setMode("otp");
      setOtp(["", "", "", ""]);
      setTimeout(() => inputs.current[0]?.focus(), 100);
    }, 900);
  };

  const verify = (digits: string[]) => {
    const val = digits.join("");
    if (val.length < 4) return;
    if (val === code) {
      login({ mode: "phone", phone: `+91 ${phone}`, at: Date.now() });
      if (!profile.phone) saveProfile({ ...profile, phone: `+91 ${phone}` });
    } else {
      setShake(true);
      setErr(tr("wrongOtp"));
      setTimeout(() => {
        setShake(false);
        setOtp(["", "", "", ""]);
        inputs.current[0]?.focus();
      }, 450);
    }
  };

  const continueGuest = () => login({ mode: "guest", at: Date.now() });

  const gmailValid = /^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(gEmail.trim());
  const derivedName = gmailValid ? usernameFromEmail(gEmail.trim()) : "";

  const continueWithEmail = () => {
    const email = gEmail.trim();
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) return;
    // The part before "@" always becomes the in-app username.
    login({ mode: "google", email, at: Date.now() });
    saveProfile({ ...profile, name: usernameFromEmail(email), email });
  };

  const features = [
    { icon: <Sprout size={19} />, title: tr("feat1T"), sub: tr("feat1S") },
    { icon: <HeartPulse size={19} />, title: tr("feat2T"), sub: tr("feat2S") },
    { icon: <TrendingUp size={19} />, title: tr("feat3T"), sub: tr("feat3S") },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: "url(/img/login-hero.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center 30%",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/25 via-black/35 to-[#071310]/95" />
      <div className="absolute inset-0 backdrop-blur-[2px]" />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-[560px] flex-col px-5 pb-8 pt-14">
        
          {/* Brand */}
          <div className="fade-up text-center">
            <h1 className="font-display text-[52px] font-black tracking-tight text-white drop-shadow-lg">
              <span className="bg-gradient-to-br from-amber-300 via-orange-400 to-green-400 bg-clip-text text-[64px] text-transparent">V</span>
              ETTO
            </h1>
            <p className="mt-1 flex items-center justify-center gap-1.5 text-[13px] font-semibold text-amber-100/90">
              <Sparkles size={14} /> {tr("loginTagline")}
            </p>
          </div>

          {/* Feature list */}
          <div className="fade-up mt-9 space-y-3" style={{ animationDelay: "0.08s" }}>
            {features.map((f) => (
              <div key={f.title} className="flex items-center gap-4 rounded-3xl border border-white/20 bg-white/10 p-4 backdrop-blur-xl">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-amber-400 to-emerald-500 text-white shadow-lg">
                  {f.icon}
                </span>
                <div>
                  <p className="font-display text-[15.5px] font-bold text-white">{f.title}</p>
                  <p className="text-[12.5px] text-white/75">{f.sub}</p>
                </div>
              </div>
            ))}
          </div>

        <div className="flex-1" />

        {/* Card */}
        <div className="pop-in mt-8 rounded-[28px] border border-white/25 bg-white/12 p-5 shadow-2xl backdrop-blur-2xl" style={{ animationDelay: "0.16s" }}>
          {mode === "phone" ? (
            <>
              {/* Phone login */}
              <label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-white/70">
                {tr("phoneLogin")}
              </label>
              <div
                className={`flex h-[54px] items-center gap-2 rounded-2xl border bg-black/25 px-4 transition-shadow ${
                  err ? "border-red-400" : "border-white/25 focus-within:border-amber-300 focus-within:shadow-[0_0_0_3px_rgba(251,191,36,0.25)]"
                }`}
              >
                <span className="font-display text-[15px] font-bold text-white/85">+91</span>
                <span className="h-5 w-px bg-white/25" />
                <input
                  inputMode="numeric"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value.replace(/\D/g, "").slice(0, 10));
                    setErr("");
                  }}
                  placeholder={tr("phonePlaceholder")}
                  className="w-full bg-transparent text-[17px] font-semibold tracking-wide text-white placeholder:text-white/40 focus:outline-none"
                  aria-label={tr("phoneLogin")}
                />
              </div>
              {err && <p className="mt-2 text-[12px] font-semibold text-red-300">{err}</p>}

              <button
                onClick={sendOtp}
                disabled={sending}
                className="btn-brand btn-press mt-4 flex h-[54px] w-full items-center justify-center gap-2 rounded-2xl font-display text-[16.5px] font-bold disabled:opacity-70"
              >
                <Smartphone size={18} />
                {sending ? tr("sending") : tr("sendOtp")}
              </button>

              <div className="my-4 flex items-center gap-3 text-[11px] font-bold uppercase tracking-widest text-white/50">
                <span className="h-px flex-1 bg-white/20" /> {tr("or")} <span className="h-px flex-1 bg-white/20" />
              </div>

              <button
                onClick={() => setMode("google")}
                className="btn-press flex h-[54px] w-full items-center justify-center gap-2.5 rounded-2xl border border-white/30 bg-white/95 font-display text-[16px] font-bold text-slate-800"
              >
                <GoogleMark />
                {tr("googleLogin")}
              </button>

              <button
                onClick={continueGuest}
                className="btn-press mt-2.5 flex h-[54px] w-full items-center justify-center gap-2 rounded-2xl border border-white/30 bg-white/10 font-display text-[16px] font-bold text-white"
              >
                <UserRound size={18} />
                {tr("guestLogin")}
              </button>
              <p className="mt-2.5 text-center text-[11.5px] text-white/55">{tr("guestNote")}</p>
            </>
          ) : mode === "google" ? (
            <>
              <button
                onClick={() => setMode("phone")}
                className="mb-3 flex items-center gap-1 text-[12.5px] font-bold text-white/70"
              >
                <ChevronLeft size={15} /> {tr("back")}
              </button>
              <div className="flex items-center gap-2.5">
                <GoogleMark />
                <p className="font-display text-[17px] font-bold text-white">{tr("chooseAccount")}</p>
              </div>

              <div className="mt-3 flex items-start gap-2 rounded-xl border border-amber-300/40 bg-amber-400/15 px-3 py-2 text-[11.5px] font-semibold text-amber-100">
                <ShieldCheck size={14} className="mt-0.5 shrink-0" />
                <span>{tr("googleDemoNote")}</span>
              </div>

              <input
                value={gEmail}
                onChange={(e) => setGEmail(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && gmailValid) continueWithEmail();
                }}
                type="email"
                inputMode="email"
                autoComplete="email"
                placeholder={tr("emailPh")}
                aria-label={tr("emailOpt")}
                className="mt-3 h-[52px] w-full rounded-2xl border border-white/25 bg-black/25 px-4 text-[15px] font-semibold text-white placeholder:text-white/40 focus:border-amber-300 focus:outline-none"
              />

              {derivedName && (
                <p className="pop-in mt-2 flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-3 py-2 text-[12px] font-semibold text-white/85">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-amber-400 to-emerald-500 font-display text-[12px] font-black text-white">
                    {derivedName.charAt(0).toUpperCase()}
                  </span>
                  <span className="min-w-0 truncate">
                    {tr("yourName")}: <span className="font-black text-white">{derivedName}</span>
                  </span>
                </p>
              )}

              <button
                disabled={!gmailValid}
                onClick={continueWithEmail}
                className="btn-brand btn-press mt-3 h-[52px] w-full rounded-2xl font-display text-[16px] font-bold disabled:opacity-40"
              >
                {tr("useThisEmail")}
              </button>
            </>
          ) : (
            <>
              {/* OTP */}
              <button
                onClick={() => setMode("phone")}
                className="mb-3 flex items-center gap-1 text-[12.5px] font-bold text-white/70"
              >
                <ChevronLeft size={15} /> {tr("changeNumber")}
              </button>
              <p className="font-display text-[17px] font-bold text-white">{tr("otpTitle")}</p>
              <p className="mt-0.5 text-[12.5px] text-white/70">
                {tr("otpSub")} <span className="font-bold text-white">+91 {phone}</span>
              </p>

              {/* DEMO adapter notice */}
              <div className="mt-3 flex items-center gap-2 rounded-xl border border-amber-300/40 bg-amber-400/15 px-3 py-2 text-[11.5px] font-semibold text-amber-100">
                <ShieldCheck size={14} className="shrink-0" />
                <span>
                  {tr("demoAdapter")} <span className="mx-1 rounded-md bg-white/20 px-1.5 py-0.5 font-mono text-[13px] tracking-[0.2em]">{code}</span>
                </span>
              </div>

              <div className={`mt-4 flex justify-center gap-3 ${shake ? "animate-[pop-in_.4s_ease]" : ""}`}>
                {otp.map((d, i) => (
                  <input
                    key={i}
                    ref={(el) => { inputs.current[i] = el; }}
                    inputMode="numeric"
                    maxLength={1}
                    value={d}
                    aria-label={`OTP digit ${i + 1}`}
                    onChange={(e) => {
                      const v = e.target.value.replace(/\D/g, "").slice(-1);
                      const next = [...otp];
                      next[i] = v;
                      setOtp(next);
                      if (v && i < 3) inputs.current[i + 1]?.focus();
                      if (v && i === 3) verify(next);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Backspace" && !otp[i] && i > 0) inputs.current[i - 1]?.focus();
                    }}
                    className="h-[58px] w-[58px] rounded-2xl border border-white/30 bg-black/25 text-center font-display text-[24px] font-black text-white focus:border-amber-300 focus:outline-none focus:shadow-[0_0_0_3px_rgba(251,191,36,0.3)]"
                  />
                ))}
              </div>
              {err && <p className="mt-2 text-center text-[12px] font-semibold text-red-300">{err}</p>}

              <button
                onClick={() => verify(otp)}
                className="btn-brand btn-press mt-4 flex h-[54px] w-full items-center justify-center gap-2 rounded-2xl font-display text-[16.5px] font-bold"
              >
                {tr("verifyOtp")}
              </button>
              <p className="mt-3 text-center text-[12px] font-semibold text-white/60">
                {t > 0 ? `${tr("resend")} · 0:${String(t).padStart(2, "0")}` : (
                  <button className="text-amber-200 underline" onClick={() => setMode("phone")}>{tr("resend")}</button>
                )}
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
