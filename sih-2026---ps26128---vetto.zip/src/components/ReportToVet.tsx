"use client";

import React, { useRef, useState } from "react";
import {
  Stethoscope, Send, Camera, X, CheckCircle2, AlertTriangle, Clock, ChevronRight, Lock, Download,
} from "lucide-react";
import { useStore, CaseUrgency } from "@/lib/store";
import { ANIMAL_TYPES, animalLabel, AnimalType, QUANTITY_OPTIONS } from "@/lib/animals";
import { Modal } from "@/components/ui";
import { Rich } from "@/components/VettoAI";

async function shrink(file: File, max = 900): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const c = document.createElement("canvas");
      const s = Math.min(1, max / Math.max(img.width, img.height));
      c.width = img.width * s;
      c.height = img.height * s;
      c.getContext("2d")?.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.7));
    };
    img.onerror = () => reject(new Error("img"));
    img.src = url;
  });
}

export default function ReportToVet() {
  const store = useStore();
  const { t, lang, profile, animals, addVetCase } = store;
  const isGuest = store.role === "guest";
  const [open, setOpen] = useState(false);
  const [sent, setSent] = useState(false);

  const own = Array.from(new Set(animals.map((a) => a.type)));
  const options = [...own, ...ANIMAL_TYPES.filter((a) => !own.includes(a))];

  const [animalType, setAnimalType] = useState<AnimalType>((options[0] as AnimalType) || "cow");
  const [count, setCount] = useState("1");
  const [symptoms, setSymptoms] = useState("");
  const [duration, setDuration] = useState("");
  const [urgency, setUrgency] = useState<CaseUrgency>("normal");
  const [images, setImages] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const durations: { id: string; label: string }[] = [
    { id: "today", label: t("dToday") },
    { id: "yesterday", label: t("dYesterday") },
    { id: "few", label: t("dFewDays") },
    { id: "many", label: t("dManyDays") },
    { id: "unknown", label: t("dUnknown") },
  ];

  const urgencies: { id: CaseUrgency; label: string; cls: string }[] = [
    { id: "normal", label: t("uNormal"), cls: "from-emerald-500 to-green-600" },
    { id: "urgent", label: t("uUrgent"), cls: "from-amber-500 to-orange-600" },
    { id: "emergency", label: t("uEmergency"), cls: "from-red-500 to-rose-600" },
  ];

  const reset = () => {
    setSymptoms("");
    setDuration("");
    setUrgency("normal");
    setImages([]);
    setCount("1");
  };

  const submit = () => {
    addVetCase({
      farmerName: profile.name?.trim() || t("farmer"),
      village: profile.location?.label,
      animalType,
      count,
      symptoms: symptoms.trim(),
      duration: durations.find((d) => d.id === duration)?.label || t("dUnknown"),
      urgency,
      images,
    });
    setOpen(false);
    reset();
    setSent(true);
    setTimeout(() => setSent(false), 4200);
  };

  return (
    <>
      {/* ---------- ENTRY CARD ---------- */}
      <section className="glass fade-up relative overflow-hidden rounded-[26px] p-4">
        <div className="pointer-events-none absolute -right-10 -top-12 h-36 w-36 rounded-full bg-gradient-to-br from-teal-400/25 to-emerald-500/15 blur-2xl" />
        <div className="flex items-start gap-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-md">
            <Stethoscope size={20} />
          </span>
          <div className="min-w-0 flex-1">
            <h2 className="font-display text-[15.5px] font-bold leading-tight">{t("reportVet")}</h2>
            <p className="mt-0.5 text-[12px] leading-snug text-soft">{t("reportVetSub")}</p>
          </div>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="btn-brand btn-press mt-3.5 flex h-12 w-full items-center justify-center gap-2 rounded-2xl font-display text-[15px] font-bold"
        >
          <Send size={17} /> {t("newReport")}
        </button>
      </section>

      {/* ---------- FORM ---------- */}
      <Modal open={open} onClose={() => setOpen(false)} title={t("reportVet")}>
        <div className="nice-scroll max-h-[68vh] space-y-4 overflow-y-auto pr-0.5">
          {/* animal */}
          <div>
            <p className="mb-1.5 text-[11.5px] font-black uppercase tracking-wider text-faint">{t("reportAnimal")}</p>
            <div className="flex flex-wrap gap-2">
              {options.map((a) => (
                <button
                  key={a}
                  onClick={() => setAnimalType(a as AnimalType)}
                  className={`btn-press rounded-full border px-3 py-1.5 text-[12.5px] font-bold ${
                    animalType === a
                      ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white"
                      : "border-line bg-surface text-soft"
                  }`}
                >
                  {animalLabel(a, lang, false)}
                </button>
              ))}
            </div>
          </div>

          {/* count */}
          <div>
            <p className="mb-1.5 text-[11.5px] font-black uppercase tracking-wider text-faint">{t("howMany")}</p>
            <div className="flex flex-wrap gap-2">
              {QUANTITY_OPTIONS.map((q) => (
                <button
                  key={q}
                  onClick={() => setCount(q)}
                  className={`btn-press h-10 min-w-[48px] rounded-xl border px-3 font-display text-[14px] font-black ${
                    count === q
                      ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white"
                      : "border-line bg-surface"
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* symptoms */}
          <div>
            <p className="mb-1.5 text-[11.5px] font-black uppercase tracking-wider text-faint">{t("whatHappened")}</p>
            <textarea
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              rows={4}
              placeholder={t("whatHappenedPh")}
              className="glass-input w-full resize-none rounded-2xl px-4 py-3 text-[14px] leading-relaxed"
            />
          </div>

          {/* duration */}
          <div>
            <p className="mb-1.5 text-[11.5px] font-black uppercase tracking-wider text-faint">{t("sinceWhen")}</p>
            <div className="flex flex-wrap gap-2">
              {durations.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setDuration(d.id)}
                  className={`btn-press rounded-full border px-3 py-1.5 text-[12.5px] font-bold ${
                    duration === d.id
                      ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white"
                      : "border-line bg-surface text-soft"
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          {/* urgency */}
          <div>
            <p className="mb-1.5 text-[11.5px] font-black uppercase tracking-wider text-faint">{t("howUrgent")}</p>
            <div className="grid grid-cols-3 gap-2">
              {urgencies.map((u) => (
                <button
                  key={u.id}
                  onClick={() => setUrgency(u.id)}
                  className={`btn-press h-11 rounded-2xl border text-[12px] font-bold ${
                    urgency === u.id
                      ? `border-transparent bg-gradient-to-r ${u.cls} text-white shadow`
                      : "border-line bg-surface text-soft"
                  }`}
                >
                  {u.label}
                </button>
              ))}
            </div>
          </div>

          {/* photos */}
          <div>
            <p className="mb-1.5 text-[11.5px] font-black uppercase tracking-wider text-faint">{t("addPhotos")}</p>
            <div className="flex flex-wrap items-center gap-2">
              {images.map((img, i) => (
                <span key={i} className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={img} alt="" className="h-16 w-16 rounded-xl border border-line object-cover" />
                  <button
                    onClick={() => setImages((s) => s.filter((_, j) => j !== i))}
                    aria-label={t("remove")}
                    className="btn-press absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-red-500 text-white"
                  >
                    <X size={11} />
                  </button>
                </span>
              ))}
              {images.length < 3 && (
                <button
                  onClick={() => fileRef.current?.click()}
                  className="btn-press grid h-16 w-16 place-items-center rounded-xl border-2 border-dashed border-[var(--line-strong)] text-brand"
                >
                  <Camera size={20} />
                </button>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                try {
                  const d = await shrink(f);
                  setImages((s) => [...s, d].slice(0, 3));
                } catch { /* ignore */ }
                e.target.value = "";
              }}
            />
          </div>

          {isGuest && (
            <div className="flex items-start gap-2 rounded-2xl border border-amber-500/40 bg-amber-500/12 px-3 py-2.5">
              <Lock size={14} className="mt-0.5 shrink-0 text-amber-600 dark:text-amber-300" />
              <p className="text-[11.5px] font-semibold leading-snug text-amber-700 dark:text-amber-200">
                {t("guestLockedSend")}
              </p>
            </div>
          )}

          <button
            disabled={isGuest || !symptoms.trim()}
            aria-disabled={isGuest || !symptoms.trim()}
            title={isGuest ? t("guestLocked") : undefined}
            onClick={submit}
            className="btn-brand btn-press h-12 w-full rounded-2xl font-display font-bold disabled:cursor-not-allowed disabled:opacity-40"
          >
            <span className="flex items-center justify-center gap-2">
              {isGuest ? <Lock size={16} /> : <Send size={17} />}
              {isGuest ? t("guestLocked") : t("sendToDoctor")}
            </span>
          </button>
        </div>
      </Modal>

      {/* ---------- SENT TOAST ---------- */}
      {sent && (
        <div className="pop-in fixed inset-x-4 bottom-28 z-[95] mx-auto max-w-[420px]">
          <div className="glass-strong flex items-start gap-3 rounded-2xl border-emerald-500/40 px-4 py-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-orange-500 to-green-600 text-white">
              <CheckCircle2 size={18} />
            </span>
            <div>
              <p className="text-[13px] font-black leading-snug">{t("reportSent")}</p>
              <p className="mt-0.5 text-[11.5px] leading-snug text-soft">{t("reportSentSub")}</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------- Farmer-side list of their doctor reports ---------- */
export function MyVetReports() {
  const { t, lang, vetCases } = useStore();
  const [openId, setOpenId] = useState<string | null>(null);
  const mine = vetCases.filter((c) => !c.demo);
  const locale = lang === "hi" ? "hi-IN" : "en-IN";

  if (mine.length === 0) {
    return (
      <div className="glass rounded-3xl p-6 text-center">
        <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-[var(--chip)] text-soft">
          <Stethoscope size={24} />
        </span>
        <p className="text-[14px] font-bold">{t("noVetReports")}</p>
        <p className="mt-1 text-[12.5px] leading-relaxed text-soft">{t("noVetReportsSub")}</p>
      </div>
    );
  }

  return (
    <div className="space-y-2.5">
      {mine.map((c, i) => {
        const resolved = c.status === "answered" && c.responses.length > 0;
        const reviewing = c.status === "in_review";
        const isOpen = openId === c.id;
        const step = resolved ? 2 : reviewing ? 1 : 0;
        const steps = [t("progressSent"), t("progressReview"), t("progressResolved")];

        return (
          <div
            key={c.id}
            className={`glass fade-up overflow-hidden rounded-3xl ${resolved ? "border-emerald-500/40" : ""}`}
            style={{ animationDelay: `${Math.min(i, 6) * 0.04}s` }}
          >
            {resolved && (
              <div className="flex items-center gap-2 bg-gradient-to-r from-emerald-500/20 to-green-600/10 px-4 py-2">
                <CheckCircle2 size={14} className="shrink-0 text-emerald-600 dark:text-emerald-300" />
                <p className="text-[11.5px] font-black uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
                  {t("caseResolved")}
                </p>
                <span className="ml-auto rounded-full bg-emerald-600 px-2 py-0.5 text-[9px] font-black text-white">
                  {t("newReplyBadge")}
                </span>
              </div>
            )}

            <button onClick={() => setOpenId(isOpen ? null : c.id)} className="flex w-full items-start gap-3 p-4 text-left">
              <span
                className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-md ${
                  resolved
                    ? "bg-gradient-to-br from-emerald-500 to-green-600"
                    : c.urgency === "emergency"
                      ? "bg-gradient-to-br from-red-500 to-rose-600"
                      : c.urgency === "urgent"
                        ? "bg-gradient-to-br from-amber-500 to-orange-600"
                        : "bg-gradient-to-br from-teal-500 to-emerald-600"
                }`}
              >
                {resolved ? <CheckCircle2 size={19} /> : c.urgency === "normal" ? <Stethoscope size={18} /> : <AlertTriangle size={18} />}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-center gap-1.5">
                  <span className="font-display text-[14px] font-bold">{animalLabel(c.animalType, lang)}</span>
                  <span className="text-[10.5px] font-bold text-faint">#{c.code}</span>
                </span>
                <span className="mt-0.5 line-clamp-2 block text-[12px] leading-snug text-soft">{c.symptoms}</span>

                {/* progress tracker */}
                <span className="mt-2 flex items-center gap-1">
                  {steps.map((label, si) => (
                    <span key={label} className="flex flex-1 items-center gap-1">
                      <span
                        className={`h-1.5 flex-1 rounded-full ${
                          si <= step ? "bg-gradient-to-r from-orange-500 to-green-600" : "bg-[var(--line)]"
                        }`}
                      />
                    </span>
                  ))}
                </span>
                <span className="mt-1 block text-[10.5px] font-bold text-brand">{steps[step]}</span>
              </span>
              <ChevronRight size={16} className={`mt-1 shrink-0 text-faint transition-transform ${isOpen ? "rotate-90" : ""}`} />
            </button>

            {isOpen && (
              <div className="pop-in space-y-3 border-t border-line px-4 pb-4 pt-3">
                <div>
                  <p className="mb-1 text-[10.5px] font-black uppercase tracking-wider text-faint">{t("yourReport")}</p>
                  <p className="text-[13px] leading-relaxed text-soft">{c.symptoms}</p>
                  <p className="mt-1 text-[11px] font-semibold text-faint">
                    {t("caseAffected")}: {c.count} · {t("caseSince")}: {c.duration}
                  </p>
                  {c.images.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {c.images.map((im, j) => (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img key={j} src={im} alt="" className="h-16 w-16 rounded-xl border border-line object-cover" />
                      ))}
                    </div>
                  )}
                </div>

                {c.responses.length === 0 ? (
                  <p className="flex items-center gap-1.5 rounded-2xl border border-line bg-[var(--chip)] px-3 py-2.5 text-[12.5px] font-semibold text-soft">
                    <Clock size={13} className="shrink-0" /> {t("awaitingDoctor")}
                  </p>
                ) : (
                  c.responses.map((r) => (
                    <div key={r.id} className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-3.5">
                      <p className="mb-1.5 flex flex-wrap items-center gap-1.5 text-[11px] font-black uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
                        <Stethoscope size={12} /> {t("doctorReply")} — {r.author}
                      </p>
                      <p className="mb-2 text-[10.5px] font-semibold text-faint">
                        {r.authorRole === "vet" ? t("asVet") : t("asOfficial")} · {t("repliedOn")}{" "}
                        {new Date(r.createdAt).toLocaleString(locale, {
                          day: "numeric",
                          month: "short",
                          hour: "numeric",
                          minute: "2-digit",
                        })}
                      </p>
                      <div className="text-[13px] leading-relaxed">
                        <Rich text={r.text} />
                      </div>
                      {r.attachments.length > 0 && (
                        <div className="mt-2.5">
                          <p className="mb-1 text-[10px] font-black uppercase tracking-wider text-faint">
                            {t("attachmentsFromDoctor")}
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {r.attachments.map((a, k) => (
                              <a
                                key={k}
                                href={a.dataUrl}
                                download={a.name}
                                className="chip flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-bold"
                              >
                                <Download size={11} />
                                <span className="max-w-[140px] truncate">{a.name}</span>
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                      <p className="mt-2.5 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300">
                        ✓ {t("caseResolvedSub")}
                      </p>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
