"use client";

import React, { useMemo, useState } from "react";
import { Landmark, Info, FileText } from "lucide-react";
import { useStore } from "@/lib/store";
import { SCHEMES, withMatch, SchemeCat, SchemeType, SchemeWithMatch } from "@/lib/schemes";
import { SectionTitle } from "@/components/ui";
import { TKey } from "@/lib/i18n";

const CAT_LABEL: Record<SchemeCat, TKey> = {
  dairy: "catDairy", health: "catHealth", insurance: "catInsurance", credit: "catCredit",
  poultry: "catPoultry", goatsheep: "catGoatSheep", feed: "catFeed", breed: "catBreed",
  infra: "catInfra", women: "catWomen", training: "catTraining", market: "catMarket", private: "catPrivate",
};

const TYPE_LABEL: Record<SchemeType, TKey> = {
  central: "central", state: "state", coop: "coop", private: "private",
};

const TYPE_CLS: Record<SchemeType, string> = {
  central: "bg-orange-500/12 text-orange-600 dark:text-orange-300 border-orange-500/30",
  state: "bg-sky-500/12 text-sky-600 dark:text-sky-300 border-sky-500/30",
  coop: "bg-emerald-500/12 text-emerald-600 dark:text-emerald-300 border-emerald-500/30",
  private: "bg-violet-500/12 text-violet-600 dark:text-violet-300 border-violet-500/30",
};

function MatchRing({ pct }: { pct: number }) {
  const r = 19;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative grid h-[54px] w-[54px] shrink-0 place-items-center">
      <svg width="54" height="54" className="-rotate-90">
        <circle cx="27" cy="27" r={r} fill="none" stroke="var(--line)" strokeWidth="5" />
        <circle
          cx="27" cy="27" r={r} fill="none"
          stroke={pct >= 75 ? "#16a34a" : pct >= 55 ? "#f97316" : "#a3a3a3"}
          strokeWidth="5" strokeLinecap="round"
          strokeDasharray={`${(pct / 100) * c} ${c}`}
        />
      </svg>
      <span className="absolute font-display text-[13px] font-black">{pct}%</span>
    </div>
  );
}

export default function SchemesPage() {
  const { t, lang, animals, profile } = useStore();
  const [cat, setCat] = useState<SchemeCat | "all">("all");

  const ownTypes = useMemo(() => Array.from(new Set(animals.map((a) => a.type as string))), [animals]);
  const scored = useMemo(
    () => withMatch(SCHEMES, ownTypes, !!(profile.name && (profile.phone || profile.email))),
    [ownTypes, profile]
  );

  const filtered = useMemo(
    () => (cat === "all" ? scored : scored.filter((s) => s.cat === cat)),
    [scored, cat]
  );

  const cats: (SchemeCat | "all")[] = ["all", ...Array.from(new Set(SCHEMES.map((s) => s.cat)))];

  return (
    <div>
      <SectionTitle icon={<Landmark size={17} />} title={t("schemesTitle")} sub={t("schemesSub")} />

      {/* Reference data notice */}
      <div className="glass fade-up mb-3 flex items-start gap-2.5 rounded-2xl p-3">
        <Info size={15} className="mt-0.5 shrink-0 text-brand" />
        <p className="text-[11.5px] font-semibold leading-relaxed text-soft">{t("demoRef")}</p>
      </div>

      {/* Category chips */}
      <div className="nice-scroll -mx-4 mb-1 flex gap-2 overflow-x-auto px-4 pb-2">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`btn-press shrink-0 whitespace-nowrap rounded-full border px-3.5 py-2 text-[12.5px] font-bold transition-all ${
              cat === c ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white shadow" : "border-line bg-surface text-soft"
            }`}
          >
            {c === "all" ? t("all") : t(CAT_LABEL[c])}
            <span className={`ml-1.5 rounded-full px-1.5 text-[10px] font-black ${cat === c ? "bg-white/25" : "bg-[var(--chip)]"}`}>
              {c === "all" ? scored.length : scored.filter((s) => s.cat === c).length}
            </span>
          </button>
        ))}
      </div>

      <p className="mb-2 px-1 text-[11.5px] font-bold text-faint">
        {filtered.length} {t("schemesFound")}
      </p>

      {/* Cards */}
      <div className="space-y-3">
        {filtered.map((s: SchemeWithMatch, i: number) => (
          <article key={s.id} className="glass fade-up rounded-3xl p-4" style={{ animationDelay: `${Math.min(i, 8) * 0.04}s` }}>
            <div className="flex items-start gap-3">
              <div className="min-w-0 flex-1">
                <div className="mb-1.5 flex flex-wrap items-center gap-1.5">
                  <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[9.5px] font-black uppercase tracking-wide ${TYPE_CLS[s.type]}`}>
                    {t(TYPE_LABEL[s.type])}
                  </span>
                  <span className="chip rounded-full px-2 py-0.5 text-[9.5px] font-bold">{t(CAT_LABEL[s.cat])}</span>
                </div>
                <h3 className="font-display text-[15px] font-bold leading-snug">
                  {lang === "hi" ? s.nameHi : s.name}
                </h3>
                <p className="mt-0.5 text-[11.5px] font-semibold text-faint">{s.org}</p>
              </div>
              <MatchRing pct={s.match} />
            </div>

            <p className="mt-2.5 text-[13px] leading-relaxed text-soft">
              <span className="font-bold text-brand">{t("benefits")}: </span>
              {lang === "hi" ? s.benefitHi : s.benefit}
            </p>

            <div className="mt-2.5">
              <p className="mb-1 flex items-center gap-1 text-[10.5px] font-black uppercase tracking-wider text-faint">
                <FileText size={11} /> {t("docs")}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {(lang === "hi" ? s.docsHi : s.docs).split("|").map((d) => (
                  <span key={d} className="chip rounded-full px-2.5 py-1 text-[10.5px] font-semibold">{d}</span>
                ))}
              </div>
            </div>

            <p className="mt-2 text-[10.5px] font-bold text-emerald-600 dark:text-emerald-300">
              {t("eligibility")}: {s.match}%
            </p>
          </article>
        ))}
      </div>
    </div>
  );
}
