"use client";

import React, { useState } from "react";
import {
  ClipboardList, NotebookPen, Plus, FileDown, Trash2, Camera, Mic, MessageSquareText,
  CloudCheck, Clock, CheckCircle2, AlertTriangle,
} from "lucide-react";
import { useStore, Note } from "@/lib/store";
import { animalLabel, ANIMAL_TYPES } from "@/lib/animals";
import { Modal, SectionTitle, EmptyState, Tag } from "@/components/ui";
import { downloadNotePdf } from "@/lib/pdf";
import { MyVetReports } from "@/components/ReportToVet";

export default function ReportsPage() {
  const { t, lang, reports, notes, addNote, removeNote } = useStore();
  const [view, setView] = useState<"reports" | "notes">("reports");
  const [noteOpen, setNoteOpen] = useState(false);
  const [pdfNote, setPdfNote] = useState<Note | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [pdfDone, setPdfDone] = useState<"ok" | "fail" | "">("");

  const locale = lang === "hi" ? "hi-IN" : "en-IN";

  return (
    <div className="space-y-4">
      {/* toggle */}
      <div className="glass fade-up mx-0 flex rounded-full p-1">
        {(["reports", "notes"] as const).map((v) => (
          <button
            key={v}
            onClick={() => setView(v)}
            className={`btn-press flex h-11 flex-1 items-center justify-center gap-2 rounded-full font-display text-[14px] font-bold transition-all ${
              view === v ? "bg-gradient-to-r from-orange-500 to-green-600 text-white shadow-md" : "text-soft"
            }`}
          >
            {v === "reports" ? <ClipboardList size={16} /> : <NotebookPen size={16} />}
            {v === "reports" ? t("reports") : t("myNotes")}
          </button>
        ))}
      </div>

      {view === "reports" && (
        <section>
          <p className="mb-2 px-1 text-[11px] font-black uppercase tracking-wider text-faint">{t("myVetReports")}</p>
          <MyVetReports />
          <p className="mb-2 mt-5 px-1 text-[11px] font-black uppercase tracking-wider text-faint">{t("chatReport")}</p>
          {reports.length === 0 ? (
            <EmptyState icon={<ClipboardList size={26} />} title={t("noReports")} sub={t("noReportsSub")} />
          ) : (
            <div className="space-y-2.5">
              {reports.map((r, i) => (
                <div key={r.id} className="glass fade-up flex items-start gap-3 rounded-3xl p-3.5" style={{ animationDelay: `${Math.min(i, 6) * 0.04}s` }}>
                  <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-md ${
                    r.kind === "photo" ? "bg-gradient-to-br from-amber-500 to-orange-600" : r.kind === "voice" ? "bg-gradient-to-br from-orange-500 to-rose-500" : "bg-gradient-to-br from-green-500 to-emerald-600"
                  }`}>
                    {r.kind === "photo" ? <Camera size={18} /> : r.kind === "voice" ? <Mic size={18} /> : <MessageSquareText size={18} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-[13.5px] font-bold">
                      {r.kind === "photo" ? t("photoReport") : r.kind === "voice" ? t("voiceReportN") : t("chatReport")}
                    </p>
                    <p className="mt-0.5 line-clamp-2 text-[12px] text-soft">{r.text}</p>
                    {r.image && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={r.image} alt={t("attachment")} className="mt-2 h-16 w-16 rounded-xl border border-line object-cover" />
                    )}
                    <p className="mt-1.5 flex items-center gap-1 text-[10.5px] font-semibold text-faint">
                      <Clock size={10} />
                      {new Date(r.createdAt).toLocaleString(locale, { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}
                    </p>
                  </div>
                  <Tag tone={r.status === "synced" ? "ok" : "warn"}>
                    <CloudCheck size={11} />
                    {r.status === "synced" ? t("statusSynced") : t("statusQueued")}
                  </Tag>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {view === "notes" && (
        <section>
          <SectionTitle
            icon={<NotebookPen size={17} />}
            title={t("myNotes")}
            right={
              <button onClick={() => setNoteOpen(true)} className="btn-brand btn-press flex h-10 items-center gap-1 rounded-full px-3.5 text-[13px] font-bold">
                <Plus size={16} /> {t("saveNote")}
              </button>
            }
          />
          {notes.length === 0 ? (
            <EmptyState icon={<NotebookPen size={26} />} title={t("noNotes")} />
          ) : (
            <div className="space-y-2.5">
              {notes.map((n, i) => (
                <div key={n.id} className="glass fade-up rounded-3xl p-4" style={{ animationDelay: `${Math.min(i, 6) * 0.04}s` }}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-display text-[15px] font-bold leading-snug">{n.title}</p>
                      <p className="mt-0.5 text-[11px] font-semibold text-faint">
                        {new Date(n.createdAt).toLocaleDateString(locale, { day: "numeric", month: "short", year: "numeric" })}
                      </p>
                    </div>
                    <Tag>{n.animalType === "general" ? t("general") : animalLabel(n.animalType, lang)}</Tag>
                  </div>
                  <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed text-soft">{n.body}</p>
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => setPdfNote(n)}
                      className="btn-press flex h-10 flex-1 items-center justify-center gap-1.5 rounded-2xl border border-line bg-surface text-[12.5px] font-bold text-brand"
                    >
                      <FileDown size={15} /> {t("downloadPdf")}
                    </button>
                    <button
                      onClick={() => removeNote(n.id)}
                      aria-label={t("remove")}
                      className="btn-press grid h-10 w-10 place-items-center rounded-2xl border border-red-400/30 bg-red-500/10 text-red-400"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* ---------- ADD NOTE MODAL ---------- */}
      <Modal open={noteOpen} onClose={() => setNoteOpen(false)} title={t("myNotes")}>
        <AddNoteForm
          onSave={(n) => {
            addNote(n);
            setNoteOpen(false);
          }}
        />
      </Modal>

      {/* ---------- PDF CONFIRM ---------- */}
      <Modal open={!!pdfNote} onClose={() => setPdfNote(null)} title="">
        <div className="text-center">
          <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-orange-500 to-green-600 text-white shadow-lg">
            <FileDown size={22} />
          </span>
          <p className="font-display text-[16px] font-bold leading-snug">{t("pdfTitle")}</p>
          <div className="mt-5 grid grid-cols-2 gap-3">
            <button
              onClick={() => setPdfNote(null)}
              className="btn-press h-12 rounded-2xl border border-line bg-surface font-bold text-soft"
            >
              {t("pdfNo")}
            </button>
            <button
              disabled={pdfBusy}
              onClick={async () => {
                if (!pdfNote) return;
                setPdfBusy(true);
                let ok = true;
                try {
                  await downloadNotePdf({
                    title: pdfNote.title,
                    body: pdfNote.body,
                    animalLabel: pdfNote.animalType === "general" ? t("general") : animalLabel(pdfNote.animalType, lang),
                    dateStr: new Date(pdfNote.createdAt).toLocaleDateString(locale, { day: "numeric", month: "long", year: "numeric" }),
                  });
                } catch {
                  ok = false;
                }
                setPdfBusy(false);
                setPdfNote(null);
                setPdfDone(ok ? "ok" : "fail");
                setTimeout(() => setPdfDone(""), 4000);
              }}
              className="btn-brand btn-press h-12 rounded-2xl font-display font-bold disabled:opacity-60"
            >
              {pdfBusy ? t("loading") : t("pdfYes")}
            </button>
          </div>
        </div>
      </Modal>

      {/* ---------- DOWNLOAD TOAST ---------- */}
      {pdfDone && (
        <div className="pop-in fixed inset-x-4 bottom-28 z-[95] mx-auto max-w-[420px]">
          <div className={`glass-strong flex items-center gap-3 rounded-2xl px-4 py-3 ${pdfDone === "ok" ? "border-emerald-500/40" : "border-red-400/40"}`}>
            <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-white ${pdfDone === "ok" ? "bg-gradient-to-br from-orange-500 to-green-600" : "bg-red-500"}`}>
              {pdfDone === "ok" ? <CheckCircle2 size={18} /> : <AlertTriangle size={18} />}
            </span>
            <p className="text-[13px] font-bold leading-snug">
              {pdfDone === "ok" ? t("pdfSaved") : t("pdfFailed")}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function AddNoteForm({ onSave }: { onSave: (n: { title: string; body: string; animalType: string }) => void }) {
  const { t, lang, animals } = useStore();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [animalType, setAnimalType] = useState("general");
  const own = Array.from(new Set(animals.map((a) => a.type)));
  const options = [...own, ...ANIMAL_TYPES.filter((a) => !own.includes(a))];

  return (
    <div className="space-y-3">
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder={t("noteTitlePh")}
        aria-label={t("noteTitle")}
        className="glass-input h-12 w-full rounded-2xl px-4 text-[14.5px] font-semibold"
      />
      <div>
        <p className="mb-1.5 text-[11px] font-black uppercase tracking-wider text-faint">{t("noteAnimal")}</p>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setAnimalType("general")}
            className={`btn-press rounded-full border px-3 py-1.5 text-[12.5px] font-bold ${animalType === "general" ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white" : "border-line bg-surface text-soft"}`}
          >
            {t("general")}
          </button>
          {options.map((o) => (
            <button
              key={o}
              onClick={() => setAnimalType(o)}
              className={`btn-press rounded-full border px-3 py-1.5 text-[12.5px] font-bold ${animalType === o ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white" : "border-line bg-surface text-soft"}`}
            >
              {animalLabel(o, lang, false)}
            </button>
          ))}
        </div>
      </div>
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={5}
        placeholder={t("noteBody")}
        aria-label={t("myNotes")}
        className="glass-input w-full resize-none rounded-2xl px-4 py-3 text-[14px] leading-relaxed"
      />
      <button
        disabled={!title.trim() || !body.trim()}
        onClick={() => onSave({ title: title.trim(), body: body.trim(), animalType })}
        className="btn-brand btn-press h-12 w-full rounded-2xl font-display font-bold disabled:opacity-40"
      >
        {t("saveNote")}
      </button>
    </div>
  );
}
