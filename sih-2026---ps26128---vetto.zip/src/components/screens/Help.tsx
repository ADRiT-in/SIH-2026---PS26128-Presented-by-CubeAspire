"use client";

import React, { useCallback, useMemo, useState } from "react";
import { LifeBuoy, Phone, MapPin, Navigation, Stethoscope, Building2, LocateFixed } from "lucide-react";
import { useStore } from "@/lib/store";
import { SectionTitle, Tag, Spinner } from "@/components/ui";

interface Vet {
  name: string; nameHi: string; role: string; roleHi: string;
  dist: number; phone: string; available: boolean; dLat: number; dLon: number;
}

const NAMES: [string, string][] = [
  ["Dr. Rakesh Sharma", "डॉ. राकेश शर्मा"],
  ["Dr. Sunita Verma", "डॉ. सुनीता वर्मा"],
  ["Dr. Imran Khan", "डॉ. इमरान खान"],
  ["Dr. Meena Patil", "डॉ. मीना पाटिल"],
  ["Dr. Arvind Yadav", "डॉ. अरविंद यादव"],
  ["Dr. Kavita Rao", "डॉ. कविता राव"],
];

function hashStr(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

function demoVets(lat: number, lon: number): Vet[] {
  const base = hashStr(lat.toFixed(2) + ":" + lon.toFixed(2));
  const out: Vet[] = [];
  for (let i = 0; i < 5; i++) {
    const h = hashStr(base + ":" + i);
    const [name, nameHi] = NAMES[h % NAMES.length];
    out.push({
      name, nameHi,
      role: i === 0 ? "Govt. Veterinary Officer" : i === 1 ? "Govt. Veterinary Hospital" : "Private Veterinary Doctor",
      roleHi: i === 0 ? "सरकारी पशु चिकित्सा अधिकारी" : i === 1 ? "सरकारी पशु चिकित्सालय" : "निजी पशु चिकित्सक",
      dist: Math.round(((h % 55) + 6) / 10 * 10) / 10,
      phone: `+91 ${7000000000 + (h % 999999999)}`,
      available: h % 4 !== 0,
      dLat: lat + ((h % 40) - 20) / 300,
      dLon: lon + (((h >> 4) % 40) - 20) / 300,
    });
  }
  return out.sort((a, b) => a.dist - b.dist);
}

export default function HelpSection() {
  const { t, lang, profile } = useStore();
  const [locating, setLocating] = useState(false);
  const [coords, setCoords] = useState<{ lat: number; lon: number } | null>(
    profile.location ? { lat: profile.location.lat, lon: profile.location.lon } : null
  );

  const locate = useCallback(() => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setCoords({ lat: p.coords.latitude, lon: p.coords.longitude });
        setLocating(false);
      },
      () => setLocating(false),
      { timeout: 10000 }
    );
  }, []);

  const vets = useMemo(
    () => (coords ? demoVets(coords.lat, coords.lon) : []),
    [coords]
  );

  const helplines: { num: string; label: string; labelHi: string }[] = [
    { num: "1962", label: "National Animal Helpline", labelHi: "राष्ट्रीय पशु हेल्पलाइन" },
    { num: "1800-180-1551", label: "Kisan Call Centre", labelHi: "किसान कॉल सेंटर" },
    { num: "112", label: "Emergency (All India)", labelHi: "आपातकाल (अखिल भारतीय)" },
  ];

  return (
    <div>
      <SectionTitle icon={<LifeBuoy size={17} />} title={t("helpTitle")} sub={t("helpSub")} />

      {/* ---------- NATIONAL HELPLINES ---------- */}
      <p className="mb-2 px-1 text-[11px] font-black uppercase tracking-wider text-faint">{t("nationalHelplines")}</p>
      <div className="space-y-2.5">
        {helplines.map((h, i) => (
          <div key={h.num} className="glass fade-up flex items-center gap-3 rounded-3xl p-3.5" style={{ animationDelay: `${i * 0.05}s` }}>
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-rose-500 to-red-600 text-white shadow-md">
              <Phone size={18} />
            </span>
            <div className="flex-1">
              <p className="font-display text-[19px] font-black tracking-wide">{h.num}</p>
              <p className="text-[11.5px] font-semibold text-soft">{lang === "hi" ? h.labelHi : h.label}</p>
            </div>
            <Tag tone="ok">{t("realTag")}</Tag>
            <a
              href={`tel:${h.num.replace(/-/g, "")}`}
              aria-label={`${t("callNow")} ${h.num}`}
              className="btn-brand btn-press grid h-11 w-11 place-items-center rounded-full"
            >
              <Phone size={17} />
            </a>
          </div>
        ))}
      </div>

      {/* ---------- NEARBY VETS ---------- */}
      <div className="mb-2 mt-6 flex items-center justify-between px-1">
        <p className="text-[11px] font-black uppercase tracking-wider text-faint">{t("vetsNearby")}</p>
        {!coords && (
          <button onClick={locate} disabled={locating} className="btn-brand btn-press flex h-9 items-center gap-1.5 rounded-full px-3 text-[12px] font-bold">
            <LocateFixed size={14} className={locating ? "animate-spin" : ""} />
            {locating ? t("locating2") : "GPS"}
          </button>
        )}
      </div>

      {!coords && (
        <div className="glass fade-up rounded-3xl p-5 text-center">
          <MapPin size={22} className="mx-auto text-brand" />
          <p className="mt-2 text-[13px] font-semibold text-soft">{t("enableLoc")}</p>
        </div>
      )}
      {locating && <Spinner label={t("locating2")} />}

      {coords && (
        <div className="space-y-2.5">
          {vets.map((v, i) => (
            <div key={i} className="glass fade-up rounded-3xl p-4" style={{ animationDelay: `${i * 0.05}s` }}>
              <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 font-display text-[15px] font-black text-white shadow-md">
                  {v.name.replace("Dr. ", "").charAt(0)}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <p className="font-display text-[14.5px] font-bold">{lang === "hi" ? v.nameHi : v.name}</p>
                    <Tag tone="warn">{t("demoTag")}</Tag>
                  </div>
                  <p className="mt-0.5 flex items-center gap-1 text-[11.5px] font-semibold text-soft">
                    {i === 1 ? <Building2 size={11} /> : <Stethoscope size={11} />}
                    {lang === "hi" ? v.roleHi : v.role} · {v.dist} {t("kmAway")}
                  </p>
                  <p className={`mt-1 text-[11px] font-bold ${v.available ? "text-emerald-600 dark:text-emerald-300" : "text-amber-600 dark:text-amber-300"}`}>
                    {v.available ? `● ${t("available")}` : `● ${t("onVisit")}`}
                  </p>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <a href={`tel:${v.phone.replace(/\s/g, "")}`} className="btn-brand btn-press flex h-11 items-center justify-center gap-1.5 rounded-2xl text-[13px] font-bold">
                  <Phone size={15} /> {t("callNow")}
                </a>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${v.dLat.toFixed(5)},${v.dLon.toFixed(5)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-press flex h-11 items-center justify-center gap-1.5 rounded-2xl border border-line bg-surface text-[13px] font-bold text-soft"
                >
                  <Navigation size={14} /> {t("directions")}
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
