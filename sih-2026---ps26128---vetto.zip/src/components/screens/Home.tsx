"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Camera, Mic, Syringe, CloudSun, LifeBuoy, Landmark, PawPrint, Sparkles, Plus,
  Quote,
} from "lucide-react";
import { useStore } from "@/lib/store";
import { animalLabel } from "@/lib/animals";
import WeatherCard from "@/components/Weather";
import { Rich } from "@/components/VettoAI";
import ReportToVet from "@/components/ReportToVet";
import { requestAI } from "@/lib/aiClient";
import type { Tab } from "@/components/App";

const LOCAL_TIPS: { en: string[]; hi: string[] } = {
  en: [
    "**Water beats feed.** A lactating cow needs <u>60-80 litres</u> of clean water daily in summer — keep two buckets always available.",
    "**Mineral mix is a silent profit lever.** <u>50-60g</u> daily can improve fertility and milk yield within a month.",
    "**Fixed milking times matter.** Milking at the same hour twice daily keeps hormones stable and yield higher.",
    "**Shade adds milk.** Simple shade can add <u>1-2 litres</u> per day during hot months.",
    "**Colostrum first.** A newborn calf must get the mother's first milk within <u>2 hours</u> of birth.",
    "**Turn surplus fodder into silage** — cheap insurance for months when green fodder disappears.",
    "**Dry bedding = healthy hooves.** Change straw every <u>2-3 days</u>; wet bedding breeds mastitis and foot-rot.",
    "**Feed the dana by the milk.** Roughly <u>1 kg concentrate per 2.5 litres</u> of milk keeps the economics right.",
    "**Deworm on a calendar,** not when the animal looks weak — every <u>6 months</u>, whole herd, same day.",
    "**A clean water trough** scrubbed every morning can prevent half of summer stomach upsets.",
    "**Keep the udder routine sacred:** wash, dry, dip — before and *after* every milking.",
    "**Sell culls on time.** An old unproductive animal eats <u>₹80-120</u> of feed daily — that is fodder for a good cow.",
    "**Record one line daily** — milk in the morning and evening. Patterns you write down become early warnings you can see.",
    "**Green fodder seasons the milk.** Even <u>5 kg</u> of fresh greens daily improves fat percentage visibly.",
    "**Never change feed suddenly.** Shift over *7 days* — rumen bacteria need time to adapt.",
    "**A salt lick in the shade** is the cheapest mineral insurance for goats and sheep.",
    "**Isolate the sick one first,** ask questions later. <u>21 days</u> of separation stops most outbreaks.",
    "**Morning is the best thermometer.** Check every animal's appetite *before* feeding — the first notice costs nothing.",
    "**Calves need warm milk,** fed at body temperature — cold milk causes scours within hours.",
    "**Ticks hide in the ears and tail folds.** A <u>60-second</u> daily check saves litres of milk.",
    "**Keep 15 days of emergency fodder** — droughts and market closures never announce themselves.",
    "**Buffaloes need wallows or baths** above <u>38°C</u> — heat silent-kills their morning milk.",
    "**Repeat-breeding is expensive.** Every missed heat costs roughly <u>21 days</u> of milk income — note every heat date.",
    "**Goats prefer browse over grass.** Offer neem and ber leaves before plain grazing for better health.",
    "**After calving,** the mother needs warm jaggery water and rest for *48 hours* before any travel.",
    "**Vaccinate before the season,** not during the outbreak — FMD camps are free; ask at <u>1962</u>.",
    "**Poultry drink first from what they touch.** Nipple or cup drinkers keep litter dry and lungs healthy.",
    "**A torch beats a guess.** In darkness, shine light at eye level — a hidden wound or swelling shows instantly.",
    "**Chaffed fodder is eaten fully.** A simple chaff cutter can save <u>15-20%</u> of your feed cost.",
    "**Smell the feed bag.** Any musty or sour smell means mould — never feed it, even mixed.",
    "**During rains,** spread lime powder on wet floors twice a week — it breaks the infection cycle.",
  ],
  hi: [
    "**पानी चारे से भी ज़रूरी है।** दूध देने वाली गाय को गर्मी में रोज़ <u>60-80 लीटर</u> साफ़ पानी चाहिए — दो बाल्टी हमेशा उपलब्ध रखें।",
    "**खनिज मिश्रण छुपा मुनाफ़ा है।** रोज़ <u>50-60 ग्राम</u> देने से एक महीने में गर्भधारण और दूध दोनों सुधरते हैं।",
    "**दुहाई का समय तय रखें।** हर रोज़ एक ही समय दो बार दुहाई करने से उपज बढ़ती है।",
    "**छाँव दूध बढ़ाती है।** गर्म महीनों में साधारण छाँव रोज़ <u>1-2 लीटर</u> दूध वापस दिला सकती है।",
    "**पहला दूध पहले।** नवजात बछड़े को जन्म के <u>2 घंटे</u> के भीतर माँ का पहला दूध (खीस) ज़रूर मिले।",
    "**अधिक चारे का साइलेज बनाएँ** — उन महीनों के लिए सस्ती बीमा जब हरा चारा मिलना बंद हो जाता है।",
    "**सूखी बिछावनी = स्वस्थ खुर।** हर <u>2-3 दिन</u> में पुआल बदलें; गीली बिछावनी थनैला और खुर-सड़न लाती है।",
    "**दाना दूध के हिसाब से दें।** लगभग <u>2.5 लीटर दूध पर 1 किलो</u> दाना हिसाब बराबर रखता है।",
    "**कृमिनाशक कैलेंडर से दें,** पशु के कमज़ोर दिखने पर नहीं — हर <u>6 माह</u>, पूरा झुंड, एक ही दिन।",
    "**साफ़ पानी का कटोरा** रोज़ सुबह रगड़ने से गर्मी की आधी पेट-खराबी रुकती है।",
    "**थन की दिनचर्या पवित्र रखें:** धोना, पौंछना, डिप — हर दुहाई के *पहले और बाद*।",
    "**बेकार पशु समय पर बेचें।** एक बूढ़ा निष्क्रिय पशु रोज़ <u>₹80-120</u> का चारा खाता है — वह चारा किसी अच्छी गाय का है।",
    "**रोज़ एक लाइन लिखें** — सुबह-शाम का दूध। लिखी हुई कमी-बढ़त ही सबसे पहली चेतावनी बनती है।",
    "**हरा चारा दूध में स्वाद घोलता है।** रोज़ <u>5 किलो</u> हरा चारा भी फैट साफ़ बढ़ाता है।",
    "**चारा अचानक न बदलें।** *7 दिन* में धीरे-धीरे बदलें — जठर के जीवाणु को समय चाहिए।",
    "**छाँव में नमक की चट्टा** बकरियों और भेड़ों के लिए सबसे सस्ती खनिज बीमा है।",
    "**बीमार को पहले अलग करें,** सवाल बाद में करें। <u>21 दिन</u> की अलगाव ज़्यादातर प्रकोप रोक देता है।",
    "**सुबह सबसे अच्छा थर्मामीटर है।** चारा देने से *पहले* हर पशु की भूख देखें — पहली खबर मुफ़्त मिलती है।",
    "**बछड़ों को गुनगुना दूध** शरीर के तापमान पर पिलाएँ — ठंडा दूध घंटों में दस्त ला देता है।",
    "**किलनी कान और पूँछ की सिलवट में छिपती है।** रोज़ <u>60 सेकंड</u> की जाँच लीटरों दूध बचाती है।",
    "<u>15 दिन</u> का आपात चारा रखें — सूखा और बाज़ार-बंदी कभी बताकर नहीं आते।",
    "**भैंस को <u>38°C</u> से ऊपर** पानी-स्नान चाहिए — गर्मी चुपके से सुबह का दूध मार देती है।",
    "**बार-बार गाभन न होना महँगा है।** हर छूटी गरमी लगभग <u>21 दिन</u> की दूध-आमदनी खा जाती है — हर तारीख लिखें।",
    "**बकरियाँ घास से ज़्यादा झाड़ी-चारा पसंद करती हैं।** मैदान से पहले नीम-बेर के पत्ते दें।",
    "**व्याने के बाद** माँ को गुड़ का गर्म पानी और *48 घंटे* आराम चाहिए — तुरंत सफ़र न कराएँ।",
    "**टीका मौसम से पहले लगाएँ,** प्रकोप के समय नहीं — खुरपका-मुँहपका शिविर नि:शुल्क हैं; <u>1962</u> पर पूछें।",
    "**मुर्गियाँ जहाँ छूती हैं वहीं से पीती हैं।** निपल या कटोरा पीने का बर्तन बिछावनी सूखी और फेफड़े स्वस्थ रखता है।",
    "**टॉर्च अंदाज़े से बेहतर है।** अँधेरे में आँख के स्तर पर रोशनी मारें — छिपा घाव या सूजन तुरंत दिखेगी।",
    "**कुट्टी करके दिया चारा पूरा खाया जाता है।** साधारण कुट्टी मशीन चारे की <u>15-20%</u> लागत बचा सकती है।",
    "**चारे की बोरी सूँघें।** ज़रा सी भी फफूंदी या खट्टी गंध मतलब मबेकार है — मिलाकर भी न खिलाएँ।",
    "**बारिश में** गीले फ़र्श पर हफ़्ते में दो बार चूना पाउडर डालें — संक्रमण का चक्र टूट जाता है।",
  ],
};

export default function HomePage({
  go,
  openAi,
}: {
  go: (tab: Tab, anchor?: "vaccines" | "weather" | "help") => void;
  openAi: (intent: "chat" | "photo" | "voice") => void;
}) {
  const store = useStore();
  const { t, lang, profile, animals, totalAnimals, online } = store;
  const weatherRef = useRef<HTMLDivElement>(null);
  const [tip, setTip] = useState("");
  const [tipBusy, setTipBusy] = useState(true);
  const tipCount = useRef(0);

  const firstName = (profile.name || "").trim().split(/\s+/)[0];

  const fetchTip = useCallback(async () => {
    setTipBusy(true);
    if (!online) {
      const arr = LOCAL_TIPS[lang];
      setTip(arr[Math.floor(Math.random() * arr.length)]);
      setTipBusy(false);
      return;
    }
    try {
      tipCount.current += 1;
      const result = await requestAI(
        {
          mode: "tip",
          lang,
          seed: `tip-${Date.now()}-${tipCount.current}`,
          messages: [
            {
              role: "user",
              content: `Create a fresh, practical livestock tip. Rotation number ${tipCount.current}.`,
            },
          ],
        },
        { attempts: 1, timeoutMs: 56000 }
      );
      setTip(result.reply || LOCAL_TIPS[lang][tipCount.current % LOCAL_TIPS[lang].length]);
    } catch {
      const arr = LOCAL_TIPS[lang];
      setTip(arr[Math.floor(Math.random() * arr.length)]);
    } finally {
      setTipBusy(false);
    }
  }, [lang, online]);

  useEffect(() => {
    fetchTip();
  }, [fetchTip]);

  const actions: {
    img: string; icon: React.ReactNode; label: string; sub: string; onClick: () => void; tint: string;
  }[] = [
    { img: "/img/btn-photo.jpg", icon: <Camera size={18} />, label: t("takePhoto"), sub: t("takePhotoSub"), onClick: () => openAi("photo"), tint: "from-amber-500/80" },
    { img: "/img/btn-voice.jpg", icon: <Mic size={18} />, label: t("voiceReport"), sub: t("voiceReportSub"), onClick: () => openAi("voice"), tint: "from-orange-500/80" },
    { img: "/img/btn-vaccine.jpg", icon: <Syringe size={18} />, label: t("vaccinations"), sub: t("vaccinationsSub"), onClick: () => go("animals", "vaccines"), tint: "from-emerald-500/80" },
    { img: "/img/btn-care.jpg", icon: <CloudSun size={18} />, label: t("todaysCare"), sub: t("todaysCareSub"), onClick: () => weatherRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), tint: "from-sky-500/80" },
    { img: "/img/btn-help.jpg", icon: <LifeBuoy size={18} />, label: t("needHelp"), sub: t("needHelpSub"), onClick: () => go("animals", "help"), tint: "from-rose-500/80" },
    { img: "/img/btn-schemes.jpg", icon: <Landmark size={18} />, label: t("govSchemes"), sub: t("govSchemesSub"), onClick: () => go("schemes"), tint: "from-green-600/80" },
  ];

  return (
    <div className="space-y-4">
      {/* ---------- GREETING ---------- */}
      <section className="glass fade-up relative overflow-hidden rounded-[26px] p-5">
        <div className="pointer-events-none absolute -right-10 -top-12 h-40 w-40 rounded-full bg-gradient-to-br from-orange-400/25 to-green-500/20 blur-2xl" />
        <p className="text-[13px] font-bold text-soft">
          {t("namaste")},{" "}
          <span className="font-display text-[17px] font-black text-brand">{firstName || t("farmer")}</span>
        </p>
        <h1 className="mt-1 font-display text-[24px] font-black leading-tight">
          {t("welcomeTo")}
        </h1>
        <p className="mt-1.5 flex items-center gap-1.5 text-[13px] font-semibold leading-snug text-soft">
          <Sparkles size={13} className="shrink-0 text-brand" />
          {t("tagline")}
        </p>
      </section>

      {/* ---------- REPORT TO A DOCTOR ---------- */}
      <ReportToVet />

      {/* ---------- YOUR ANIMALS STRIP ---------- */}
      <section className="glass fade-up rounded-[32px] p-5 shadow-sm" style={{ animationDelay: "0.05s" }}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="flex items-center gap-2.5 font-display text-lg font-black tracking-tight">
            <span className="grid h-10 w-10 place-items-center rounded-[14px] bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-md shadow-orange-500/20">
              <PawPrint size={18} />
            </span>
            {t("yourAnimals")}
          </h2>
          <button
            onClick={() => go("animals")}
            aria-label={t("addAnimal")}
            className="btn-brand btn-press flex items-center gap-1.5 px-4 h-10 rounded-full font-bold text-sm shadow-lg shadow-orange-500/25"
          >
            <Plus size={16} strokeWidth={3} />
            {t("addAnimal")}
          </button>
        </div>
        {animals.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <p className="text-sm font-semibold text-soft max-w-[200px] leading-relaxed">{t("noAnimalsYet")}</p>
          </div>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 nice-scroll">
            {animals.map((a) => (
              <button
                key={a.id}
                onClick={() => go("animals")}
                className="btn-press shrink-0 flex flex-col items-center gap-2 rounded-[24px] border border-line bg-surface p-3 min-w-[90px] shadow-sm hover:border-brand/40"
              >
                <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-orange-500/10 to-green-600/10 text-brand">
                  <PawPrint size={18} />
                </span>
                <div className="text-center">
                  <p className="text-[12px] font-black leading-none">{animalLabel(a.type, lang)}</p>
                  <p className="mt-1 text-[10px] font-bold text-faint uppercase tracking-wider">{a.qty} {t("total")}</p>
                </div>
              </button>
            ))}
            <div className="shrink-0 flex items-center justify-center p-4 rounded-[24px] border border-dashed border-line-strong text-faint bg-black/5 dark:bg-white/5">
              <div className="text-center">
                <p className="text-xl font-black leading-none text-soft">{totalAnimals}</p>
                <p className="mt-1 text-[10px] font-black uppercase">{t("total")}</p>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* ---------- QUICK ACTIONS ---------- */}
      <section className="fade-up" style={{ animationDelay: "0.1s" }}>
        <h2 className="mb-2.5 px-1 font-display text-[16px] font-bold">{t("quickActions")}</h2>
        <div className="grid grid-cols-2 gap-3">
          {actions.map((a, i) => (
            <button
              key={a.label}
              onClick={a.onClick}
              className="action-card fade-up h-[132px] rounded-[24px] border border-line text-left"
              style={{ animationDelay: `${0.1 + i * 0.05}s` }}
              aria-label={a.label}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={a.img} alt="" className="ac-img absolute inset-0 h-full w-full object-cover" />
              <span className={`absolute inset-0 bg-gradient-to-t ${a.tint} via-black/35 to-black/10`} />
              <span className="ac-sheen" />
              <span className="absolute left-3 top-3 grid h-9 w-9 place-items-center rounded-xl border border-white/30 bg-white/20 text-white backdrop-blur-md">
                {a.icon}
              </span>
              <span className="absolute inset-x-3 bottom-3">
                <span className="block font-display text-[15.5px] font-black leading-tight text-white drop-shadow">{a.label}</span>
                <span className="mt-0.5 block text-[10.5px] font-semibold leading-snug text-white/85">{a.sub}</span>
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* ---------- WEATHER ---------- */}
      <section className="fade-up" style={{ animationDelay: "0.15s" }}>
        <WeatherCard focusRef={weatherRef} />
      </section>

      {/* ---------- TIP OF THE DAY ---------- */}
      <section className="glass fade-up relative overflow-hidden rounded-[26px] p-4" style={{ animationDelay: "0.2s" }}>
        <div className="pointer-events-none absolute -left-8 -bottom-10 h-32 w-32 rounded-full bg-gradient-to-tr from-green-500/20 to-transparent blur-2xl" />
        <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-2 font-display text-[15.5px] font-bold">
            <span className="grid h-8 w-8 place-items-center rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 text-white">
              <Quote size={14} />
            </span>
            {t("tipOfDay")}
          </h2>
          <span className={`h-1.5 w-1.5 rounded-full bg-gradient-to-r from-orange-500 to-green-600 ${tipBusy ? "animate-ping" : ""}`} />
        </div>
        {tipBusy ? (
          <div className="mt-3 space-y-2">
            <div className="shimmer h-4 w-3/4 rounded-full" />
            <div className="shimmer h-4 w-full rounded-full" />
            <div className="shimmer h-4 w-2/3 rounded-full" />
          </div>
        ) : (
          <div className="mt-2.5 text-[13.5px] leading-relaxed text-soft">
            <Rich text={tip} />
          </div>
        )}
      </section>
    </div>
  );
}
