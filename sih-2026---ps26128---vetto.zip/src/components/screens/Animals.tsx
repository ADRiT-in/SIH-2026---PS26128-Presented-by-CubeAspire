"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Plus, PawPrint, Trash2, Syringe, CalendarDays, AlarmClock, CheckCircle2 } from "lucide-react";
import { useStore } from "@/lib/store";
import { ANIMAL_TYPES, ANIMAL_META, QUANTITY_OPTIONS, animalLabel, AnimalType } from "@/lib/animals";
import { Modal, SectionTitle, EmptyState, Tag } from "@/components/ui";
import HelpSection from "@/components/screens/Help";

function fmtDate(iso: string): string {
  const d = new Date(iso + "T00:00:00");
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${dd}/${mm}/${d.getFullYear()}`;
}

function daysUntil(iso: string): number {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const d = new Date(iso + "T00:00:00");
  return Math.round((d.getTime() - now.getTime()) / 86400000);
}

export default function AnimalsPage({ anchor }: { anchor?: "vaccines" | "weather" | "help" }) {
  const store = useStore();
  const { t, lang, animals, addAnimal, removeAnimal, vaccines, addVaccine, removeVaccine } = store;
  const [addOpen, setAddOpen] = useState(false);
  const [vxOpen, setVxOpen] = useState(false);
  const vacRef = useRef<HTMLDivElement>(null);
  const helpRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (anchor === "vaccines") {
      setTimeout(() => vacRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 250);
    }
    if (anchor === "help") {
      setTimeout(() => helpRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 250);
    }
  }, [anchor]);

  const sortedVax = useMemo(
    () => [...vaccines].sort((a, b) => daysUntil(a.date) - daysUntil(b.date)),
    [vaccines]
  );

  const monthCount = useMemo(() => {
    const n = new Date();
    return vaccines.filter((v) => {
      const d = new Date(v.date + "T00:00:00");
      return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear();
    }).length;
  }, [vaccines]);

  return (
    <div className="space-y-5">
      {/* ---------- YOUR ANIMALS ---------- */}
      <section>
        <SectionTitle
          icon={<PawPrint size={17} />}
          title={t("yourAnimals")}
          sub={`${store.totalAnimals} ${t("total")}`}
          right={
            <button onClick={() => setAddOpen(true)} aria-label={t("addAnimal")} className="btn-brand btn-press flex h-10 items-center gap-1 rounded-full px-3.5 text-[13px] font-bold">
              <Plus size={16} /> <span className="hidden min-[380px]:inline">{t("addAnimal")}</span>
            </button>
          }
        />
        {animals.length === 0 ? (
          <EmptyState icon={<PawPrint size={26} />} title={t("emptyAnimals")} sub={t("emptyAnimalsSub")} />
        ) : (
          <div className="space-y-2.5">
            {animals.map((a, i) => {
              const meta = ANIMAL_META[a.type];
              return (
                <div key={a.id} className="glass fade-up flex items-center gap-3 rounded-3xl p-3.5" style={{ animationDelay: `${i * 0.04}s` }}>
                  <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br ${meta.hue} text-white shadow-md`}>
                    <PawPrint size={20} />
                  </span>
                  <div className="flex-1">
                    <p className="font-display text-[15px] font-bold">{animalLabel(a.type, lang)}</p>
                    <p className="text-[11px] font-semibold text-faint">
                      {t("added")}: {new Date(a.addedAt).toLocaleDateString(lang === "hi" ? "hi-IN" : "en-IN")}
                    </p>
                  </div>
                  <span className="rounded-full bg-gradient-to-r from-orange-500 to-green-600 px-3 py-1 font-display text-[15px] font-black text-white shadow">
                    {a.qty}
                  </span>
                  <button onClick={() => removeAnimal(a.id)} aria-label={t("remove")} className="btn-press grid h-9 w-9 place-items-center rounded-full text-red-400 hover:bg-red-500/10">
                    <Trash2 size={16} />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* ---------- VACCINATIONS ---------- */}
      <section ref={vacRef} className="scroll-mt-24">
        <SectionTitle
          icon={<Syringe size={17} />}
          title={t("vaccinesTitle")}
          sub={monthCount > 0 ? `${t("thisMonth")}: ${monthCount}` : t("nothingDue")}
          right={
            <button onClick={() => setVxOpen(true)} className="btn-brand btn-press flex h-10 items-center gap-1 rounded-full px-3.5 text-[13px] font-bold">
              <Plus size={16} /> <span className="hidden min-[380px]:inline">{t("addVaccine")}</span>
            </button>
          }
        />
        {vaccines.length === 0 ? (
          <EmptyState icon={<Syringe size={26} />} title={t("noVaccines")} sub={t("noVaccinesSub")} />
        ) : (
          <div className="space-y-2.5">
            {sortedVax.map((v, i) => {
              const dleft = daysUntil(v.date);
              const tone = dleft < 0 ? "bad" : dleft === 0 ? "warn" : dleft <= 7 ? "warn" : "ok";
              return (
                <div key={v.id} className="glass fade-up flex items-center gap-3 rounded-3xl p-3.5" style={{ animationDelay: `${i * 0.04}s` }}>
                  <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-md ${dleft < 0 ? "bg-gradient-to-br from-red-500 to-rose-600" : dleft <= 7 ? "bg-gradient-to-br from-amber-500 to-orange-600" : "bg-gradient-to-br from-emerald-500 to-green-600"}`}>
                    {dleft < 0 ? <AlarmClock size={18} /> : dleft <= 7 ? <CalendarDays size={18} /> : <CheckCircle2 size={18} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-display text-[14.5px] font-bold">{v.name}</p>
                    <p className="text-[11.5px] font-semibold text-soft">
                      {animalLabel(v.animalType, lang)} · {fmtDate(v.date)}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <Tag tone={tone}>
                      {dleft < 0 ? t("overdue") : dleft === 0 ? t("dueToday") : `${t("dueInDays").replace("(in days)", "")} ${dleft} ${t("days")}`}
                    </Tag>
                  </div>
                  <button onClick={() => removeVaccine(v.id)} aria-label={t("remove")} className="btn-press grid h-9 w-9 shrink-0 place-items-center rounded-full text-red-400 hover:bg-red-500/10">
                    <Trash2 size={15} />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* ---------- EMERGENCY CONTACTS (merged from Need Help) ---------- */}
      <section ref={helpRef} className="scroll-mt-24 border-t border-line pt-5">
        <HelpSection />
      </section>

      {/* ---------- ADD ANIMAL MODAL ---------- */}
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title={t("addAnimal")}>
        <AddAnimalForm
          onSave={(type, qty) => {
            addAnimal(type, qty);
            setAddOpen(false);
          }}
        />
      </Modal>

      {/* ---------- ADD VACCINE MODAL ---------- */}
      <Modal open={vxOpen} onClose={() => setVxOpen(false)} title={t("addVaccine")}>
        <AddVaccineForm onSave={(v) => { addVaccine(v); setVxOpen(false); }} />
      </Modal>
    </div>
  );
}

export function AddAnimalForm({ onSave }: { onSave: (type: AnimalType, qty: string) => void }) {
  const { t, lang } = useStore();
  const [type, setType] = useState<AnimalType | null>(null);
  const [qty, setQty] = useState<string | null>(null);
  return (
    <div>
      <p className="mb-2 text-[12px] font-black uppercase tracking-wider text-faint">{t("selectType")}</p>
      <div className="grid grid-cols-5 gap-2">
        {ANIMAL_TYPES.map((at) => {
          const meta = ANIMAL_META[at];
          const sel = type === at;
          return (
            <button
              key={at}
              onClick={() => setType(at)}
              className={`btn-press flex flex-col items-center gap-1 rounded-2xl border p-2 ${
                sel ? "border-transparent bg-gradient-to-b from-orange-500 to-green-600 text-white shadow-lg" : "border-line bg-surface"
              }`}
            >
              <span className={`grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br ${meta.hue} text-white`}>
                <PawPrint size={15} />
              </span>
              <span className="w-full truncate text-center text-[9.5px] font-bold">{animalLabel(at, lang, false)}</span>
            </button>
          );
        })}
      </div>
      <p className="mb-2 mt-4 text-[12px] font-black uppercase tracking-wider text-faint">{t("selectQty")}</p>
      <div className="flex flex-wrap gap-2">
        {QUANTITY_OPTIONS.map((q) => (
          <button
            key={q}
            onClick={() => setQty(q)}
            className={`btn-press h-11 min-w-[52px] rounded-2xl border px-3 font-display text-[15px] font-black ${
              qty === q ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white shadow" : "border-line bg-surface"
            }`}
          >
            {q}
          </button>
        ))}
      </div>
      <button
        disabled={!type || !qty}
        onClick={() => type && qty && onSave(type, qty)}
        className="btn-brand btn-press mt-5 h-12 w-full rounded-2xl font-display font-bold disabled:opacity-40"
      >
        {t("save")}
      </button>
    </div>
  );
}

function AddVaccineForm({ onSave }: { onSave: (v: { animalType: AnimalType; name: string; date: string }) => void }) {
  const { t, lang, animals } = useStore();
  const own = Array.from(new Set(animals.map((a) => a.type)));
  const options = [...own, ...ANIMAL_TYPES.filter((a) => !own.includes(a))];
  const [type, setType] = useState<AnimalType>(options[0] as AnimalType);
  const [name, setName] = useState("");
  const [date, setDate] = useState("");

  const common = lang === "hi"
    ? ["खुरपका-मुँहपका (FMD)", "HS टीका", "BQ टीका", "PPR टीका", "एंथ्रेक्स", "ब्रुसेलोसिस", "रानीखेत (मुर्गी)"]
    : ["FMD vaccine", "HS vaccine", "BQ vaccine", "PPR vaccine", "Anthrax", "Brucellosis", "Ranikhet (poultry)"];

  return (
    <div className="space-y-3.5">
      <div>
        <label className="mb-1.5 block text-[12px] font-black uppercase tracking-wider text-faint">{t("selectAnimal")}</label>
        <div className="flex flex-wrap gap-2">
          {options.map((at) => (
            <button
              key={at}
              onClick={() => setType(at as AnimalType)}
              className={`btn-press rounded-full border px-3 py-1.5 text-[12.5px] font-bold ${
                type === at ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white" : "border-line bg-surface text-soft"
              }`}
            >
              {animalLabel(at, lang)}
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="mb-1.5 block text-[12px] font-black uppercase tracking-wider text-faint">{t("vaccineName")}</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={t("vaccineNamePh")}
          className="glass-input h-12 w-full rounded-2xl px-4 text-[14.5px]"
          list="vax-names"
        />
        <datalist id="vax-names">{common.map((c) => <option key={c} value={c} />)}</datalist>
      </div>
      <div>
        <label className="mb-1.5 block text-[12px] font-black uppercase tracking-wider text-faint">{t("dueDate")}</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          aria-label={t("pickDate")}
          className="glass-input h-12 w-full rounded-2xl px-4 text-[14.5px]"
        />
        {date && <p className="mt-1 text-[11.5px] font-semibold text-brand">{fmtDate(date)}</p>}
      </div>
      <button
        disabled={!name.trim() || !date}
        onClick={() => onSave({ animalType: type, name: name.trim(), date })}
        className="btn-brand btn-press h-12 w-full rounded-2xl font-display font-bold disabled:opacity-40"
      >
        {t("save")}
      </button>
    </div>
  );
}
