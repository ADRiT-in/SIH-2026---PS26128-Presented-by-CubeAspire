"use client";

import React, { useMemo, useRef, useState } from "react";
import {
  Stethoscope, AlertTriangle, Clock, CheckCircle2, ChevronLeft, Paperclip, X,
  Send, Sparkles, FileText, ImageIcon, Inbox, Eye, Search, Lock, RefreshCw,
} from "lucide-react";
import { useStore, VetCase, CaseAttachment, CaseStatus } from "@/lib/store";
import { animalLabel } from "@/lib/animals";
import { Rich } from "@/components/VettoAI";
import { requestAI } from "@/lib/aiClient";

const MAX_FILE = 1.5 * 1024 * 1024;

function fileToDataUrl(f: File): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = () => rej(new Error("read"));
    r.readAsDataURL(f);
  });
}

function timeAgo(ts: number, lang: string): string {
  const mins = Math.round((Date.now() - ts) / 60000);
  if (mins < 60) return lang === "hi" ? `${mins} मिनट पहले` : `${mins} min ago`;
  const h = Math.round(mins / 60);
  if (h < 24) return lang === "hi" ? `${h} घंटे पहले` : `${h} h ago`;
  const d = Math.round(h / 24);
  return lang === "hi" ? `${d} दिन पहले` : `${d} d ago`;
}

export default function VetConsole() {
  const store = useStore();
  const { t, lang, vetCases, setCaseStatus } = store;
  const [openCase, setOpenCase] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | CaseStatus>("all");
  const [q, setQ] = useState("");

  const cases = useMemo(() => {
    let list = [...vetCases].sort((a, b) => {
      // Real farmer submissions that still need a reply always surface first.
      const live = (c: VetCase) => (!c.demo && c.status !== "answered" ? 0 : 1);
      const rank = (c: VetCase) => (c.urgency === "emergency" ? 0 : c.urgency === "urgent" ? 1 : 2);
      return live(a) - live(b) || rank(a) - rank(b) || b.createdAt - a.createdAt;
    });
    if (filter !== "all") list = list.filter((c) => c.status === filter);
    if (q.trim()) {
      const s = q.toLowerCase();
      list = list.filter(
        (c) =>
          c.farmerName.toLowerCase().includes(s) ||
          c.symptoms.toLowerCase().includes(s) ||
          c.code.toLowerCase().includes(s) ||
          c.animalType.toLowerCase().includes(s)
      );
    }
    return list;
  }, [vetCases, filter, q]);

  const stats = useMemo(
    () => ({
      total: vetCases.length,
      pending: vetCases.filter((c) => c.status !== "answered").length,
      urgent: vetCases.filter((c) => c.urgency !== "normal" && c.status !== "answered").length,
      done: vetCases.filter((c) => c.status === "answered").length,
    }),
    [vetCases]
  );

  const active = vetCases.find((c) => c.id === openCase) || null;

  if (active) {
    return (
      <CaseDetail
        c={active}
        onBack={() => setOpenCase(null)}
        onReview={() => setCaseStatus(active.id, "in_review")}
      />
    );
  }

  const filters: { id: "all" | CaseStatus; label: string }[] = [
    { id: "all", label: t("allCases") },
    { id: "new", label: t("newCases") },
    { id: "in_review", label: t("reviewing") },
    { id: "answered", label: t("answered") },
  ];

  return (
    <div className="space-y-4">
      {/* ---------- DASHBOARD ---------- */}
      <section className="glass fade-up relative overflow-hidden rounded-[26px] p-4">
        <div className="pointer-events-none absolute -right-10 -top-12 h-36 w-36 rounded-full bg-gradient-to-br from-teal-400/25 to-emerald-500/15 blur-2xl" />
        <div className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-md">
            <Stethoscope size={19} />
          </span>
          <div>
            <h1 className="font-display text-[17px] font-black leading-tight">{t("vetConsole")}</h1>
            <p className="text-[11.5px] text-soft">{t("vetConsoleSub")}</p>
          </div>
        </div>
        <div className="mt-3.5 grid grid-cols-4 gap-2">
          {[
            { n: stats.total, l: t("totalCases"), c: "text-brand" },
            { n: stats.pending, l: t("pendingCases"), c: "text-sky-500" },
            { n: stats.urgent, l: t("urgentCases"), c: "text-red-500" },
            { n: stats.done, l: t("doneCases"), c: "text-emerald-500" },
          ].map((x) => (
            <div key={x.l} className="rounded-2xl border border-line bg-surface px-1.5 py-2.5 text-center">
              <p className={`font-display text-[19px] font-black leading-none ${x.c}`}>{x.n}</p>
              <p className="mt-1 text-[9.5px] font-bold leading-tight text-faint">{x.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------- SEARCH + FILTERS ---------- */}
      <div className="fade-up space-y-2.5" style={{ animationDelay: "0.05s" }}>
        <div className="glass-input flex h-11 items-center rounded-2xl px-3.5">
          <Search size={15} className="mr-2 shrink-0 text-faint" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={`${t("caseQueue")}…`}
            aria-label={t("caseQueue")}
            className="w-full bg-transparent text-[14px] font-semibold focus:outline-none"
          />
        </div>
        <div className="nice-scroll -mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`btn-press shrink-0 rounded-full border px-3.5 py-2 text-[12.5px] font-bold ${
                filter === f.id
                  ? "border-transparent bg-gradient-to-r from-teal-500 to-emerald-600 text-white shadow"
                  : "border-line bg-surface text-soft"
              }`}
            >
              {f.label}
              <span className={`ml-1.5 rounded-full px-1.5 text-[10px] font-black ${filter === f.id ? "bg-white/25" : "bg-[var(--chip)]"}`}>
                {f.id === "all" ? vetCases.length : vetCases.filter((c) => c.status === f.id).length}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ---------- QUEUE ---------- */}
      {cases.length === 0 ? (
        <div className="glass rounded-3xl p-7 text-center">
          <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-2xl bg-[var(--chip)] text-soft">
            <Inbox size={26} />
          </span>
          <p className="text-[15px] font-bold">{t("noCases")}</p>
          <p className="mt-1 text-[13px] text-soft">{t("noCasesSub")}</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {cases.map((c, i) => (
            <button
              key={c.id}
              onClick={() => setOpenCase(c.id)}
              className="glass fade-up action-card block w-full rounded-3xl p-4 text-left"
              style={{ animationDelay: `${Math.min(i, 8) * 0.04}s` }}
            >
              <div className="flex items-start gap-3">
                <span
                  className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl text-white shadow-md ${
                    c.urgency === "emergency"
                      ? "bg-gradient-to-br from-red-500 to-rose-600"
                      : c.urgency === "urgent"
                      ? "bg-gradient-to-br from-amber-500 to-orange-600"
                      : "bg-gradient-to-br from-teal-500 to-emerald-600"
                  }`}
                >
                  {c.urgency === "normal" ? <Stethoscope size={18} /> : <AlertTriangle size={18} />}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <p className="font-display text-[14.5px] font-bold">{c.farmerName}</p>
                    {c.demo ? (
                      <span className="rounded-full border border-amber-500/40 bg-amber-500/15 px-1.5 py-px text-[9px] font-black text-amber-600 dark:text-amber-300">
                        DEMO
                      </span>
                    ) : (
                      <span className="rounded-full border border-emerald-500/40 bg-emerald-500/15 px-1.5 py-px text-[9px] font-black text-emerald-600 dark:text-emerald-300">
                        {t("fromFarmer")}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] font-semibold text-faint">
                    #{c.code} · {animalLabel(c.animalType, lang)} × {c.count} · {timeAgo(c.createdAt, lang)}
                  </p>
                  <p className="mt-1 line-clamp-2 text-[12.5px] leading-snug text-soft">{c.symptoms}</p>
                  <StatusPill status={c.status} t={t} />
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function StatusPill({ status, t }: { status: CaseStatus; t: (k: never) => string }) {
  const map = {
    new: { l: "statusNew", cls: "bg-sky-500/15 text-sky-600 dark:text-sky-300 border-sky-500/30", I: Clock },
    in_review: { l: "statusInReview", cls: "bg-amber-500/15 text-amber-600 dark:text-amber-300 border-amber-500/30", I: Eye },
    answered: { l: "statusAnswered", cls: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300 border-emerald-500/30", I: CheckCircle2 },
  } as const;
  const m = map[status];
  return (
    <span className={`mt-1.5 inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold ${m.cls}`}>
      <m.I size={10} /> {t(m.l as never)}
    </span>
  );
}

/* ================= CASE DETAIL ================= */
function CaseDetail({ c, onBack, onReview }: { c: VetCase; onBack: () => void; onReview: () => void }) {
  const store = useStore();
  const { t, lang, addCaseResponse, profile } = store;
  const isGuest = store.role === "guest";
  const [text, setText] = useState("");
  const [files, setFiles] = useState<CaseAttachment[]>([]);
  const [signRole, setSignRole] = useState<"vet" | "official">("vet");
  const [name, setName] = useState(profile.name?.trim() || "");
  const [drafting, setDrafting] = useState(false);
  const [err, setErr] = useState("");
  const [sent, setSent] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const [draftCount, setDraftCount] = useState(0);

  const askAi = async () => {
    setDrafting(true);
    setErr("");
    const seed = `${c.code}-${draftCount + 1}-${Date.now().toString(36)}`;
    const caseCtx = JSON.stringify({
      animal: animalLabel(c.animalType, "en"),
      affected: c.count,
      durationOfSigns: c.duration,
      urgency: c.urgency,
      farmerDescription: c.symptoms,
      village: c.village || "unknown",
      hasPhoto: c.images.length > 0,
    });
    const prompt =
      lang === "hi"
        ? `इस केस के लिए पशु चिकित्सक हेतु गहराई से विश्लेषित नया ड्राफ्ट तैयार करें। पशु: ${animalLabel(c.animalType, "en")}, प्रभावित: ${c.count}, अवधि: ${c.duration}, अत्यावश्यकता: ${c.urgency}. किसान का विवरण: "${c.symptoms}"`
        : `Analyze every clinical clue and draft a new veterinary response. Animal: ${animalLabel(c.animalType, "en")}, affected: ${c.count}, duration: ${c.duration}, urgency: ${c.urgency}. Farmer's description: "${c.symptoms}"`;

    try {
      const result = await requestAI(
        {
          lang,
          mode: "vetdraft",
          seed,
          context: caseCtx,
          image: c.images[0],
          messages: [{ role: "user", content: prompt }],
        },
        { attempts: 1, timeoutMs: 57000 }
      );
      setText(result.reply);
      setDraftCount((n) => n + 1);
    } catch {
      // This is reached only if the app route itself is unreachable; keep the existing draft editable.
      setErr(t("aiSendError"));
    } finally {
      setDrafting(false);
    }
  };

  const onFiles = async (list: FileList | null) => {
    const f = list?.[0];
    if (!f) return;
    if (f.size > MAX_FILE) {
      setErr(t("fileTooBig"));
      setTimeout(() => setErr(""), 4000);
      return;
    }
    try {
      const d = await fileToDataUrl(f);
      setFiles((s) => [...s, { name: f.name, type: f.type, size: f.size, dataUrl: d }].slice(0, 4));
    } catch { /* ignore */ }
  };

  const send = () => {
    if (!text.trim()) return;
    addCaseResponse(c.id, {
      author: name.trim() || (signRole === "vet" ? t("asVet") : t("asOfficial")),
      authorRole: signRole,
      text: text.trim(),
      attachments: files,
    });
    setSent(true);
    setTimeout(() => {
      setSent(false);
      onBack();
    }, 1400);
  };

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="btn-press flex items-center gap-1 text-[13px] font-bold text-soft">
        <ChevronLeft size={16} /> {t("back")}
      </button>

      {/* case card */}
      <section className="glass fade-up rounded-[26px] p-4">
        <div className="flex items-start gap-3">
          <span
            className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-md ${
              c.urgency === "emergency"
                ? "bg-gradient-to-br from-red-500 to-rose-600"
                : c.urgency === "urgent"
                ? "bg-gradient-to-br from-amber-500 to-orange-600"
                : "bg-gradient-to-br from-teal-500 to-emerald-600"
            }`}
          >
            {c.urgency === "normal" ? <Stethoscope size={21} /> : <AlertTriangle size={21} />}
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5">
              <h1 className="font-display text-[16px] font-black">{c.farmerName}</h1>
              {c.demo ? (
                <span className="rounded-full border border-amber-500/40 bg-amber-500/15 px-1.5 py-px text-[9px] font-black text-amber-600 dark:text-amber-300">
                  DEMO
                </span>
              ) : (
                <span className="rounded-full border border-emerald-500/40 bg-emerald-500/15 px-1.5 py-px text-[9px] font-black text-emerald-600 dark:text-emerald-300">
                  {t("fromFarmer")}
                </span>
              )}
            </div>
            <p className="text-[11.5px] font-semibold text-faint">
              #{c.code} · {timeAgo(c.createdAt, lang)}
              {c.village ? ` · ${c.village}` : ""}
            </p>
          </div>
        </div>

        <div className="mt-3 grid grid-cols-3 gap-2">
          {[
            { l: t("caseAnimal"), v: animalLabel(c.animalType, lang) },
            { l: t("caseAffected"), v: c.count },
            { l: t("caseSince"), v: c.duration },
          ].map((x) => (
            <div key={x.l} className="rounded-2xl border border-line bg-surface px-2 py-2 text-center">
              <p className="text-[9.5px] font-bold text-faint">{x.l}</p>
              <p className="mt-0.5 text-[12.5px] font-black">{x.v}</p>
            </div>
          ))}
        </div>

        <p className="mt-3 rounded-2xl border border-line bg-surface p-3 text-[13.5px] leading-relaxed">
          {c.symptoms}
        </p>

        {c.images.length > 0 && (
          <div className="mt-2.5 flex flex-wrap gap-2">
            {c.images.map((im, i) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img key={i} src={im} alt="" className="h-24 w-24 rounded-2xl border border-line object-cover" />
            ))}
          </div>
        )}

        {c.status === "new" && (
          <button
            onClick={onReview}
            className="btn-press mt-3 h-11 w-full rounded-2xl border border-line bg-surface text-[13px] font-bold text-soft"
          >
            <span className="flex items-center justify-center gap-1.5">
              <Eye size={15} /> {t("markReviewing")}
            </span>
          </button>
        )}
      </section>

      {/* previous responses */}
      {c.responses.map((r) => (
        <div key={r.id} className="glass rounded-3xl border-emerald-500/30 p-4">
          <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wide text-emerald-600 dark:text-emerald-300">
            <CheckCircle2 size={12} /> {r.author}
          </p>
          <div className="text-[13px] leading-relaxed">
            <Rich text={r.text} />
          </div>
          {r.attachments.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {r.attachments.map((a, k) => (
                <a key={k} href={a.dataUrl} download={a.name} className="chip flex items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-bold">
                  {a.type.startsWith("image") ? <ImageIcon size={11} /> : <FileText size={11} />} {a.name}
                </a>
              ))}
            </div>
          )}
        </div>
      ))}

      {/* ---------- SOLUTION COMPOSER ---------- */}
      <section className="glass fade-up rounded-[26px] p-4">
        <h2 className="mb-2.5 font-display text-[15px] font-bold">{t("writeSolution")}</h2>

        {/* sign as */}
        <p className="mb-1.5 text-[11px] font-black uppercase tracking-wider text-faint">{t("signAs")}</p>
        <div className="mb-2.5 grid grid-cols-2 gap-2">
          {([["vet", t("asVet")], ["official", t("asOfficial")]] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setSignRole(id)}
              className={`btn-press h-10 rounded-xl border text-[11.5px] font-bold ${
                signRole === id
                  ? "border-transparent bg-gradient-to-r from-teal-500 to-emerald-600 text-white"
                  : "border-line bg-surface text-soft"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={t("yourName2")}
          className="glass-input mb-2.5 h-11 w-full rounded-xl px-3.5 text-[13.5px] font-semibold"
        />

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={6}
          placeholder={t("solutionPh")}
          className="glass-input w-full resize-none rounded-2xl px-4 py-3 text-[14px] leading-relaxed"
        />

        {/* AI draft */}
        <button
          onClick={askAi}
          disabled={drafting}
          className="btn-press mt-2.5 flex h-11 w-full items-center justify-center gap-2 rounded-2xl border border-line bg-[var(--chip)] text-[13px] font-bold text-brand disabled:opacity-50"
        >
          {drafting ? (
            <RefreshCw size={15} className="animate-spin" />
          ) : (
            <Sparkles size={15} />
          )}
          {drafting ? t("aiDrafting") : draftCount > 0 ? `${t("aiDraft")} · ${draftCount + 1}` : t("aiDraft")}
        </button>

        {text.trim() && !drafting && (
          <div className="pop-in mt-2.5 rounded-2xl border border-line bg-surface p-3.5 text-[13px] leading-relaxed">
            <Rich text={text} />
          </div>
        )}

        {/* attachments */}
        <button
          onClick={() => fileRef.current?.click()}
          className="btn-press mt-2 flex h-11 w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-[var(--line-strong)] text-[13px] font-bold text-soft"
        >
          <Paperclip size={15} /> {t("attachFiles")}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*,application/pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
          className="hidden"
          onChange={(e) => {
            onFiles(e.target.files);
            e.target.value = "";
          }}
        />
        {files.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-2">
            {files.map((f, i) => (
              <span key={i} className="chip flex items-center gap-1.5 rounded-full py-1 pl-2.5 pr-1.5 text-[11px] font-bold">
                {f.type.startsWith("image") ? <ImageIcon size={11} /> : <FileText size={11} />}
                <span className="max-w-[120px] truncate">{f.name}</span>
                <button
                  onClick={() => setFiles((s) => s.filter((_, j) => j !== i))}
                  aria-label={t("remove")}
                  className="grid h-4 w-4 place-items-center rounded-full bg-red-500/20 text-red-500"
                >
                  <X size={9} />
                </button>
              </span>
            ))}
          </div>
        )}

        {err && <p className="mt-2 text-[12px] font-bold text-red-500">{err}</p>}

        {isGuest && (
          <div className="mt-3 flex items-start gap-2 rounded-2xl border border-amber-500/40 bg-amber-500/12 px-3 py-2.5">
            <Lock size={14} className="mt-0.5 shrink-0 text-amber-600 dark:text-amber-300" />
            <p className="text-[11.5px] font-semibold leading-snug text-amber-700 dark:text-amber-200">
              {t("guestLockedSolution")}
            </p>
          </div>
        )}

        <button
          disabled={isGuest || !text.trim()}
          aria-disabled={isGuest || !text.trim()}
          title={isGuest ? t("guestLocked") : undefined}
          onClick={send}
          className="btn-brand btn-press mt-3 flex h-12 w-full items-center justify-center gap-2 rounded-2xl font-display font-bold disabled:cursor-not-allowed disabled:opacity-40"
        >
          {isGuest ? <Lock size={16} /> : <Send size={17} />}
          {isGuest ? t("guestLocked") : t("sendSolution")}
        </button>

        {sent && (
          <p className="pop-in mt-2.5 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-2.5 text-center text-[13px] font-bold text-emerald-600 dark:text-emerald-300">
            ✓ {t("solutionSent")}
          </p>
        )}
      </section>
    </div>
  );
}
