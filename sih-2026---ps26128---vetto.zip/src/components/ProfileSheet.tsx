"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  X, Camera, MapPin, RefreshCw, Save, Trash2, LogOut, PawPrint, Plus,
  Phone, Mail, UserRound, LocateFixed, WifiOff,
} from "lucide-react";
import { useStore, LocationInfo } from "@/lib/store";
import { ANIMAL_TYPES, QUANTITY_OPTIONS, animalLabel, AnimalType } from "@/lib/animals";
import { reverseGeoLabel } from "@/components/Weather";
import { Modal } from "@/components/ui";

export default function ProfileSheet({ open, onClose, onSaved }: { open: boolean; onClose: () => void; onSaved?: () => void }) {
  const store = useStore();
  const { t, lang, profile, saveProfile, clearProfile, animals, addAnimal, removeAnimal, online } = store;
  // Doctors / officials do not own livestock — hide that whole block (incl. in Guest doctor view).
  const isDoctorView = store.role === "vet" || store.activeView === "vet";
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [photo, setPhoto] = useState<string | undefined>();
  const [loc, setLoc] = useState<LocationInfo | undefined>();
  const [flash, setFlash] = useState<"saved" | "removed" | "">("");
  const [confirmDel, setConfirmDel] = useState(false);
  const [locBusy, setLocBusy] = useState(false);
  const [type, setType] = useState<AnimalType>("cow");
  const [qty, setQty] = useState<string>("2");
  const [err, setErr] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setName(profile.name || "");
      setPhone(profile.phone || "");
      setEmail(profile.email || "");
      setPhoto(profile.photo);
      setLoc(profile.location);
      setFlash("");
      setErr("");
    }
  }, [open, profile]);

  const locate = () => {
    if (!online || !navigator.geolocation) return;
    setLocBusy(true);
    navigator.geolocation.getCurrentPosition(
      async (p) => {
        try {
          const g = await reverseGeoLabel(p.coords.latitude, p.coords.longitude);
          setLoc({ lat: p.coords.latitude, lon: p.coords.longitude, label: g.location, landmark: g.landmark, updatedAt: Date.now() });
        } catch { /* keep */ }
        setLocBusy(false);
      },
      () => setLocBusy(false),
      { timeout: 10000 }
    );
  };

  const save = () => {
    if (!name.trim()) {
      setErr(t("nameRequired"));
      return;
    }
    saveProfile({
      name: name.trim(),
      photo,
      phone: phone.trim() || undefined,
      email: email.trim() || undefined,
      location: loc,
    });
    setFlash("saved");
    setErr("");
    if (onSaved) {
      setTimeout(onSaved, 250);
    } else {
      setTimeout(() => setFlash(""), 2200);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[85]" role="dialog" aria-modal="true" aria-label={t("profile")}>
      <div className="absolute inset-0 bg-black/45 backdrop-blur-sm" onClick={onClose} />
      <div
        className="glass-strong absolute inset-y-0 left-0 flex w-full max-w-[440px] flex-col overflow-hidden rounded-r-[28px] sm:ml-3 sm:my-3 sm:h-[calc(100%-1.5rem)] sm:rounded-[28px]"
        style={{ animation: "fade-up .3s ease both" }}
      >
        {/* header */}
        <div className="flex items-center justify-between border-b border-line bg-gradient-to-r from-orange-500/10 to-green-600/10 px-4 py-3">
          <h2 className="font-display text-[17px] font-black">{t("editProfile")}</h2>
          <button onClick={onClose} aria-label={t("close")} className="btn-press grid h-9 w-9 place-items-center rounded-full border border-line bg-surface text-soft">
            <X size={17} />
          </button>
        </div>

        <div className="nice-scroll flex-1 space-y-4 overflow-y-auto p-4">
          {/* avatar */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => fileRef.current?.click()}
              className="btn-press relative grid h-[76px] w-[76px] shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-orange-500 to-green-600 p-[3px] shadow-lg"
              aria-label={photo ? t("changePhoto") : t("addPhoto")}
            >
              <span className="grid h-full w-full place-items-center overflow-hidden rounded-full bg-[var(--bg-2)]">
                {photo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={photo} alt="profile" className="h-full w-full object-cover" />
                ) : (
                  <UserRound size={30} className="text-faint" />
                )}
              </span>
              <span className="absolute bottom-0 right-0 grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br from-orange-500 to-green-600 text-white shadow">
                <Camera size={11} />
              </span>
            </button>
            <div>
              <button onClick={() => fileRef.current?.click()} className="text-[13px] font-bold text-brand underline-offset-2 hover:underline">
                {photo ? t("changePhoto") : t("addPhoto")}
              </button>
              <p className="mt-0.5 text-[11px] text-faint">{t("profile")}</p>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const r = new FileReader();
                r.onload = () => {
                  const img = new Image();
                  img.onload = () => {
                    const c = document.createElement("canvas");
                    const s = Math.min(1, 256 / Math.max(img.width, img.height));
                    c.width = img.width * s;
                    c.height = img.height * s;
                    c.getContext("2d")?.drawImage(img, 0, 0, c.width, c.height);
                    setPhoto(c.toDataURL("image/jpeg", 0.8));
                  };
                  img.src = String(r.result);
                };
                r.readAsDataURL(f);
              }}
            />
          </div>

          {/* fields */}
          <div className="space-y-3">
            <div>
              <label className="mb-1 block text-[11.5px] font-black uppercase tracking-wider text-faint">{t("yourName")}</label>
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("namePh")} className="glass-input h-12 w-full rounded-2xl px-4 text-[14.5px] font-semibold" />
              {err && <p className="mt-1 text-[11.5px] font-bold text-red-500">{err}</p>}
            </div>
            <div>
              <label className="mb-1 block text-[11.5px] font-black uppercase tracking-wider text-faint">{t("phoneOpt")}</label>
              <div className="glass-input flex h-12 items-center rounded-2xl px-3.5">
                <Phone size={15} className="mr-2 text-faint" />
                <input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" className="w-full bg-transparent text-[14.5px] font-semibold focus:outline-none" />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-[11.5px] font-black uppercase tracking-wider text-faint">{t("emailOpt")}</label>
              <div className="glass-input flex h-12 items-center rounded-2xl px-3.5">
                <Mail size={15} className="mr-2 text-faint" />
                <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" className="w-full bg-transparent text-[14.5px] font-semibold focus:outline-none" />
              </div>
            </div>
          </div>

          {/* location + mini weather */}
          <div className="glass rounded-3xl p-4">
            <p className="mb-2 flex items-center gap-1.5 text-[13px] font-black">
              <MapPin size={14} className="text-brand" /> {t("myLocation")}
            </p>
            {loc ? (
              <div>
                <p className="text-[13px] font-semibold leading-snug">
                  {loc.label}
                  {loc.landmark && <span className="text-faint"> · {loc.landmark}</span>}
                </p>
                <WeatherPeek lat={loc.lat} lon={loc.lon} />
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={locate}
                    disabled={locBusy || !online}
                    className="btn-press flex h-10 flex-1 items-center justify-center gap-1.5 rounded-2xl border border-line bg-surface text-[12.5px] font-bold text-soft disabled:opacity-50"
                  >
                    <RefreshCw size={14} className={locBusy ? "animate-spin" : ""} /> {t("weatherRefresh")}
                  </button>
                </div>
              </div>
            ) : online ? (
              <button onClick={locate} disabled={locBusy} className="btn-brand btn-press flex h-11 w-full items-center justify-center gap-2 rounded-2xl text-[13px] font-bold">
                <LocateFixed size={15} className={locBusy ? "animate-pulse" : ""} /> {t("useMyLocation")}
              </button>
            ) : (
              <p className="flex items-center gap-1.5 text-[12.5px] font-semibold text-soft">
                <WifiOff size={14} /> {t("weatherOffline")}
              </p>
            )}
          </div>

          {/* livestock manager — farmer side only */}
          {!isDoctorView && (
          <div className="glass rounded-3xl p-4">
            <p className="mb-2.5 flex items-center gap-1.5 text-[13px] font-black">
              <PawPrint size={14} className="text-brand" /> {t("myLivestock")}
            </p>
            <div className="flex flex-wrap gap-2">
              <select
                value={type}
                onChange={(e) => setType(e.target.value as AnimalType)}
                className="glass-input h-11 flex-1 rounded-2xl px-3 text-[13.5px] font-semibold"
                aria-label={t("selectType")}
              >
                {ANIMAL_TYPES.map((a) => (
                  <option key={a} value={a}>{animalLabel(a, lang)}</option>
                ))}
              </select>
              <select
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                className="glass-input h-11 w-[92px] rounded-2xl px-3 text-[13.5px] font-semibold"
                aria-label={t("selectQty")}
              >
                {QUANTITY_OPTIONS.map((q) => (
                  <option key={q} value={q}>{q}</option>
                ))}
              </select>
              <button
                onClick={() => addAnimal(type, qty)}
                aria-label={t("addAnimal")}
                className="btn-brand btn-press grid h-11 w-11 place-items-center rounded-2xl"
              >
                <Plus size={18} />
              </button>
            </div>
            {animals.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {animals.map((a) => (
                  <span key={a.id} className="chip flex items-center gap-2 rounded-full py-1 pl-3 pr-1.5 text-[12px] font-bold">
                    {animalLabel(a.type, lang)} × {a.qty}
                    <button onClick={() => removeAnimal(a.id)} aria-label={t("remove")} className="btn-press grid h-5 w-5 place-items-center rounded-full bg-red-500/15 text-red-500">
                      <X size={11} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
          )}

          {/* actions */}
          <div className="space-y-2.5 pb-2">
            {flash === "saved" && (
              <p className="pop-in rounded-2xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-2.5 text-center text-[13px] font-bold text-emerald-600 dark:text-emerald-300">
                ✓ {t("saved")}
              </p>
            )}
            {flash === "removed" && (
              <p className="pop-in rounded-2xl border border-red-400/30 bg-red-500/10 px-4 py-2.5 text-center text-[13px] font-bold text-red-500">
                {t("detailsRemoved")}
              </p>
            )}
            <button onClick={save} className="btn-brand btn-press flex h-12 w-full items-center justify-center gap-2 rounded-2xl font-display font-bold">
              <Save size={17} /> {t("saveProfile")}
            </button>
            <div className="grid grid-cols-2 gap-2.5">
              <button onClick={() => setConfirmDel(true)} className="btn-press flex h-12 items-center justify-center gap-2 rounded-2xl border border-red-400/40 bg-red-500/10 text-[13px] font-bold text-red-500">
                <Trash2 size={15} /> {t("removeAll")}
              </button>
              <button
                onClick={() => { store.logout(); onClose(); }}
                className="btn-press flex h-12 items-center justify-center gap-2 rounded-2xl border border-line bg-surface text-[13px] font-bold text-soft"
              >
                <LogOut size={15} /> {t("logout")}
              </button>
            </div>
          </div>
        </div>
      </div>

      <Modal open={confirmDel} onClose={() => setConfirmDel(false)} title="">
        <p className="text-center font-display text-[16px] font-bold leading-snug">{t("removeAllConfirm")}</p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <button onClick={() => setConfirmDel(false)} className="btn-press h-12 rounded-2xl border border-line bg-surface font-bold text-soft">{t("no")}</button>
          <button
            onClick={() => {
              clearProfile();
              setName(""); setPhone(""); setEmail(""); setPhoto(undefined); setLoc(undefined);
              setConfirmDel(false);
              setFlash("removed");
              setTimeout(() => setFlash(""), 2200);
            }}
            className="btn-press h-12 rounded-2xl bg-red-500 font-bold text-white shadow-lg shadow-red-500/30"
          >
            {t("yes")}
          </button>
        </div>
      </Modal>
    </div>
  );
}

function WeatherPeek({ lat, lon }: { lat: number; lon: number }) {
  const { t, online } = useStore();
  const [temp, setTemp] = useState<number | null>(null);
  useEffect(() => {
    if (!online) return;
    let alive = true;
    fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m&timezone=auto`)
      .then((r) => r.json())
      .then((j: { current?: { temperature_2m?: number } }) => {
        if (alive && j.current?.temperature_2m != null) setTemp(Math.round(j.current.temperature_2m));
      })
      .catch(() => undefined);
    return () => { alive = false; };
  }, [lat, lon, online]);
  if (temp == null) return null;
  return (
    <p className="mt-1 text-[12px] font-bold text-brand">
      {temp}°C · {Math.round((temp * 9) / 5 + 32)}°F — {t("today")}
    </p>
  );
}
