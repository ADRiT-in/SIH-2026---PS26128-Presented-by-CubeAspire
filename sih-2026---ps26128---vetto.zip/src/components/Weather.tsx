"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  MapPin, RefreshCw, Droplets, Wind, Umbrella, Thermometer, Sun, CloudSun, Cloud,
  CloudFog, CloudDrizzle, CloudRain, CloudSnow, CloudLightning, WifiOff, LocateFixed, HeartPulse,
} from "lucide-react";
import { useStore } from "@/lib/store";
import { animalLabel, ANIMAL_TYPES } from "@/lib/animals";
import { Spinner } from "@/components/ui";
import { Rich } from "@/components/VettoAI";
import { requestAI } from "@/lib/aiClient";

export interface WxDay { date: string; code: number; tmax: number; tmin: number; precip: number }
export interface WxData {
  tempC: number; humidity: number; wind: number; precip: number; code: number;
  days: WxDay[]; location: string; landmark?: string;
}

export function codeInfo(code: number): { Icon: React.ElementType; en: string; hi: string } {
  if (code === 0) return { Icon: Sun, en: "Clear sky", hi: "साफ़ आसमान" };
  if (code <= 2) return { Icon: CloudSun, en: "Partly cloudy", hi: "हल्के बादल" };
  if (code === 3) return { Icon: Cloud, en: "Cloudy", hi: "बादल छाए हैं" };
  if (code === 45 || code === 48) return { Icon: CloudFog, en: "Foggy", hi: "कोहरा" };
  if (code >= 51 && code <= 57) return { Icon: CloudDrizzle, en: "Drizzle", hi: "बूंदाबांदी" };
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return { Icon: CloudRain, en: "Rain", hi: "वर्षा" };
  if (code >= 71 && code <= 77) return { Icon: CloudSnow, en: "Snow", hi: "बर्फ़" };
  if (code >= 95) return { Icon: CloudLightning, en: "Thunderstorm", hi: "आँधी-तूफ़ान" };
  return { Icon: Cloud, en: "Cloudy", hi: "बादल" };
}

export async function reverseGeoLabel(lat: number, lon: number): Promise<{ location: string; landmark?: string }> {
  try {
    const r = await fetch(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`
    );
    const j = (await r.json()) as {
      locality?: string; city?: string; principalSubdivision?: string;
      localityInfo?: { informative?: { name?: string; description?: string }[] };
    };
    const parts = [j.locality || j.city, j.principalSubdivision].filter(Boolean);
    let landmark: string | undefined;
    const inf = j.localityInfo?.informative || [];
    for (const x of inf) {
      const n = x?.name?.trim();
      if (n && !parts.includes(n) && !/^\d/.test(n) && n.length <= 42) {
        landmark = n;
        break;
      }
    }
    return { location: parts.join(", ") || `${lat.toFixed(3)}, ${lon.toFixed(3)}`, landmark };
  } catch {
    return { location: `${lat.toFixed(3)}, ${lon.toFixed(3)}` };
  }
}

export async function fetchWeatherAt(lat: number, lon: number): Promise<WxData> {
  const url =
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum` +
    `&past_days=3&forecast_days=4&timezone=auto`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("meteo");
  const j = (await r.json()) as {
    current: { temperature_2m: number; relative_humidity_2m: number; precipitation: number; weather_code: number; wind_speed_10m: number };
    daily: { time: string[]; weather_code: number[]; temperature_2m_max: number[]; temperature_2m_min: number[]; precipitation_sum: number[] };
  };
  const days: WxDay[] = j.daily.time.map((d, i) => ({
    date: d,
    code: j.daily.weather_code[i],
    tmax: j.daily.temperature_2m_max[i],
    tmin: j.daily.temperature_2m_min[i],
    precip: j.daily.precipitation_sum[i] || 0,
  }));
  const geo = await reverseGeoLabel(lat, lon);
  return {
    tempC: j.current.temperature_2m,
    humidity: j.current.relative_humidity_2m,
    wind: j.current.wind_speed_10m,
    precip: j.current.precipitation ?? 0,
    code: j.current.weather_code,
    days,
    location: geo.location,
    landmark: geo.landmark,
  };
}

const fmtDay = (iso: string, lang: string) =>
  new Date(iso + "T00:00:00").toLocaleDateString(lang === "hi" ? "hi-IN" : "en-IN", { weekday: "short", day: "numeric" });

export default function WeatherCard({ focusRef }: { focusRef?: React.RefObject<HTMLDivElement | null> }) {
  const { t, lang, online, animals } = useStore();
  const [phase, setPhase] = useState<"idle" | "permit" | "locating" | "loading" | "ready" | "error" | "manual">("idle");
  const [wx, setWx] = useState<WxData | null>(null);
  const [village, setVillage] = useState("");
  type CareEntry = { status: "loading" | "done" | "error"; text: string };
  const [care, setCare] = useState<Record<string, CareEntry>>({});
  const [careAnimal, setCareAnimal] = useState<string | null>(null);
  const lastCoords = useRef<{ lat: number; lon: number } | null>(null);

  const load = useCallback(async (lat: number, lon: number) => {
    setPhase("loading");
    lastCoords.current = { lat, lon };
    try {
      const data = await fetchWeatherAt(lat, lon);
      setWx(data);
      setPhase("ready");
      setCare({});
      setCareAnimal(null);
    } catch {
      setPhase("error");
    }
  }, []);

  const locate = useCallback(() => {
    setPhase("locating");
    if (!navigator.geolocation) {
      setPhase("manual");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => load(pos.coords.latitude, pos.coords.longitude),
      () => setPhase("manual"),
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 600000 }
    );
  }, [load]);

  const findVillage = useCallback(async () => {
    const q = village.trim();
    if (!q) return;
    setPhase("loading");
    try {
      const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1&language=${lang}`);
      const j = (await r.json()) as { results?: { latitude: number; longitude: number }[] };
      const g = j.results?.[0];
      if (!g) throw new Error("nf");
      await load(g.latitude, g.longitude);
    } catch {
      setPhase("manual");
    }
  }, [village, load, lang]);

  const todayIdx = wx ? Math.min(3, wx.days.length - 1) : 3;

  const careButtons = useAnimalList(animals);

  const localCare = useCallback((type: string, w: WxData): string => {
    const label = animalLabel(type, lang);
    const hot = w.tempC >= 33;
    const warm = w.tempC >= 26 && w.tempC < 33;
    const cold = w.tempC <= 12;
    const wet = w.precip > 1 || (w.code >= 51 && w.code <= 82);
    const humid = w.humidity >= 70;
    const windy = w.wind >= 25;
    const T = Math.round(w.tempC);
    const H = w.humidity;
    const W = Math.round(w.wind);
    const hi = lang === "hi";

    const heading = hi
      ? `**${label} — आज का मौसम और देखभाल**\nअभी <u>${T}°C</u>, नमी <u>${H}%</u>, हवा <u>${W} किमी/घंटा</u>।`
      : `**${label} — weather-based care today**\nCurrent: <u>${T}°C</u>, humidity <u>${H}%</u>, wind <u>${W} km/h</u>.`;

    const tips: string[] = [heading, ""];

    // Species-specific advice matrix
    const isCattle = ["cow", "buffalo", "ox"].includes(type);
    const isSmallRum = ["goat", "sheep"].includes(type);
    const isPoultry = ["hen", "duck"].includes(type);
    const isEquine = ["horse", "donkey"].includes(type);
    const isPig = type === "pig";

    if (hot) {
      if (isCattle) {
        if (type === "buffalo") {
          tips.push(hi ? "- भैंस गर्मी सबसे ज़्यादा महसूस करती है; <u>38°C</u> से ऊपर पानी में खड़ा करें या नहलाएँ दिन में <u>2 बार</u>" : "- Buffaloes are most heat-sensitive; above <u>38°C</u> let them wallow or spray them <u>twice daily</u>");
          tips.push(hi ? "- साफ़ ठंडा पानी <u>हर 3 घंटे</u> बदलें, दूध <u>20-30%</u> तक गिर सकता है" : "- Refresh clean cool water <u>every 3 hours</u>; milk can drop <u>20-30%</u> in extreme heat");
        } else {
          tips.push(hi ? "- गाय/बैल को छाँव में रखें; <u>11am-4pm</u> बाहर न निकालें" : "- Keep cattle in shade; avoid sun exposure <u>11am-4pm</u>");
          tips.push(hi ? "- पीने का पानी दिन में <u>4-5 बार</u> ताज़ा रखें; गर्मी में <u>60-80 लीटर/दिन</u> चाहिए" : "- Refresh drinking water <u>4-5 times</u> daily; a lactating cow needs <u>60-80 litres/day</u> in heat");
        }
        tips.push(hi ? "- चारा सुबह जल्दी (<u>6am</u>) और शाम (<u>6pm</u>) दें; दोपहर में भूख कम रहती है" : "- Feed early morning (<u>6am</u>) and evening (<u>6pm</u>); appetite drops at midday");
        tips.push(hi ? "- <u>50g</u> खनिज मिश्रण + नमक की चट्टा हमेशा उपलब्ध रखें" : "- Keep <u>50g</u> mineral mix + a salt lick always available");
      } else if (isSmallRum) {
        tips.push(hi ? "- बकरी/भेड़ को दोपहर की धूप से बचाएँ; छाँव में बाँधें या बाड़े में रखें" : `- Keep ${label.toLowerCase()} shaded during midday; tie under trees or keep in the shed`);
        tips.push(hi ? "- साफ़ पानी <u>3-4 बार</u> दें; बकरियाँ कम पीती हैं लेकिन गर्मी में ज़्यादा ज़रूरत होती है" : `- Offer clean water <u>3-4 times</u>; ${label.toLowerCase()} drink less but need more in heat`);
        tips.push(hi ? "- हरा चारा (नीम, बेर के पत्ते) सुबह-शाम दें" : "- Provide green browse (neem, ber leaves) morning and evening");
      } else if (isPoultry) {
        tips.push(hi ? "- बाड़े में पंखा/हवा का इंतज़ाम करें; <u>40°C</u> से ऊपर मुर्गियाँ हाँफ़ने लगती हैं" : `- Ventilate the shed with fans; ${label.toLowerCase()} start panting above <u>40°C</u>`);
        tips.push(hi ? "- पीने के पानी में *इलेक्ट्रोलाइट* मिलाएँ; <u>हर 2 घंटे</u> ताज़ा पानी" : "- Add *electrolytes* to drinking water; refresh <u>every 2 hours</u>");
        tips.push(hi ? "- अंडा उत्पादन गर्मी में <u>10-20%</u> गिर सकता है — चारे में <u>कैल्शियम</u> बढ़ाएँ" : "- Egg production can drop <u>10-20%</u> in heat — increase <u>calcium</u> in feed");
      } else if (isEquine) {
        tips.push(hi ? "- काम का बोझ <u>आधा</u> करें; सुबह जल्दी और शाम को ही काम कराएँ" : "- Halve the workload; work only in early morning and evening");
        tips.push(hi ? "- नहलाने के बाद छाँव में सुखाएँ; पानी <u>हर 2 घंटे</u>" : "- After washing, dry in shade; offer water <u>every 2 hours</u>");
      } else if (isPig) {
        tips.push(hi ? "- सूअरों को कीचड़-स्नान दें या पानी छिड़कें; ये पसीना नहीं बहा सकते" : "- Pigs cannot sweat — provide a mud wallow or spray water regularly");
        tips.push(hi ? "- बाड़ा हवादार रखें; गीला बिछावनी बदलें" : "- Keep the pen well-ventilated; change wet bedding daily");
      } else {
        tips.push(hi ? "- छाँव और ठंडा पानी ज़रूर दें" : "- Provide shade and cool water");
      }
    } else if (cold) {
      if (isCattle) {
        tips.push(hi ? "- रात में बाड़ा बंद करें, हवा न लगे; सूखी मोटी बिछावनी दें" : "- Close the shed at night, block drafts; provide thick dry bedding");
        tips.push(hi ? "- पीने का पानी <u>गुनगुना</u> करें; ठंडा पानी दूध <u>10-15%</u> घटा सकता है" : "- Offer <u>lukewarm</u> drinking water; cold water can reduce milk by <u>10-15%</u>");
        tips.push(hi ? "- दुबले पशुओं को <u>200g</u> अतिरिक्त दाना शाम को दें (जठर गर्मी पैदा करता है)" : "- Give thin animals <u>200g</u> extra concentrate in the evening (rumen heat generation)");
        if (type === "buffalo") tips.push(hi ? "- भैंस की चमड़ी मोटी होती है लेकिन नवजात बछड़ों को कम्बल चाहिए <u>10°C</u> से नीचे" : "- Buffalo hide is thick but calves need blankets below <u>10°C</u>");
      } else if (isSmallRum) {
        tips.push(hi ? "- भेड़ की ऊन सर्दी से बचाती है लेकिन बकरी को अतिरिक्त आश्रय चाहिए" : "- Sheep wool protects from cold but goats need extra shelter");
        tips.push(hi ? "- मेमनों/बकरी के बच्चों को गर्म, सूखी जगह दें; <u>बल्ब/हीटर</u> से गर्मी" : "- Keep kids/lambs warm and dry; use a <u>heat lamp</u> if available");
      } else if (isPoultry) {
        tips.push(hi ? "- बाड़े में गर्मी बनाए रखें; <u>18°C</u> से नीचे अंडा उत्पादन गिरता है" : "- Maintain shed warmth; egg production drops below <u>18°C</u>");
        tips.push(hi ? "- रोशनी <u>16 घंटे</u> बनाए रखें (बल्ब से)" : "- Maintain <u>16 hours</u> of light (use a bulb)");
      } else if (isPig) {
        tips.push(hi ? "- सूअरों को सूखी बिछावनी और हवारोधी बाड़ा चाहिए" : "- Pigs need dry bedding and a draft-free pen in cold");
        tips.push(hi ? "- छोटे सूअरों के लिए <u>हीट लैंप</u> रखें" : "- Use a <u>heat lamp</u> for piglets");
      } else {
        tips.push(hi ? "- सूखी बिछावनी, हवा-रोधी आश्रय और गुनगुना पानी दें" : "- Provide dry bedding, wind-proof shelter and lukewarm water");
      }
    } else {
      // Moderate weather
      tips.push(hi ? "- मौसम अनुकूल है — सामान्य दिनचर्या रखें" : "- Weather is comfortable — maintain the normal routine");
      if (isCattle) tips.push(hi ? "- <u>50g</u> खनिज मिश्रण और साफ़ पानी रोज़ दें" : "- Give <u>50g</u> mineral mix and clean water daily");
      else if (isPoultry) tips.push(hi ? "- पानी साफ़ रखें, बाड़ा हवादार" : "- Keep water clean, shed ventilated");
      else tips.push(hi ? "- साफ़ पानी और संतुलित चारा रोज़ दें" : "- Ensure clean water and balanced feed daily");
    }

    // Cross-cutting weather modifiers
    if (wet) {
      if (isCattle || isSmallRum) tips.push(hi ? "- बारिश: खुर सूखे रखें, गीले फ़र्श पर *चूना* डालें; फफूंदी वाला चारा तुरंत हटाएँ" : "- Rain: keep hooves dry, spread *lime* on wet floors; discard any mouldy feed immediately");
      if (isPoultry) tips.push(hi ? "- बारिश: बिछावनी सूखी रखें, गीली लकड़ी वाली बिछावनी से *श्वास रोग* बढ़ता है" : "- Rain: keep litter dry — wet litter increases *respiratory disease* risk");
      if (isPig) tips.push(hi ? "- बारिश: बाड़ा पानी भरा न हो; गीली जगह से *त्वचा संक्रमण* होता है" : "- Rain: ensure the pen doesn't flood; wet conditions cause *skin infections*");
    }
    if (humid && !wet) {
      tips.push(hi ? "- नमी ज़्यादा: हवा का बहाव बढ़ाएँ, किलनी-मक्खी की रोज़ जाँच करें" : "- High humidity: increase air circulation, check for ticks and flies daily");
    }
    if (windy) {
      tips.push(hi ? "- तेज़ हवा: बाड़े/शेड की उत्तरी/पश्चिमी तरफ़ आड़ लगाएँ" : "- Strong wind: put wind-breaks on the north/west side of the shed");
      if (isPoultry) tips.push(hi ? "- मुर्गियों का बाड़ा पूरी तरह बंद रखें, हवा से तनाव बढ़ता है" : "- Keep the poultry shed fully enclosed; wind-stress reduces production");
    }

    tips.push("");
    tips.push(hi ? `कोई और सवाल हो ${label} के बारे में — बताइए!` : `Any other question about your ${label.toLowerCase()}? Just ask!`);
    return tips.join("\n");
  }, [lang]);

  const askCare = useCallback(async (type: string) => {
    if (!wx) return;
    setCareAnimal(type);
    const existing = care[type];
    if (existing && existing.status === "done") return;

    setCare((s) => ({ ...s, [type]: { status: "loading", text: "" } }));

    if (!online) {
      setCare((s) => ({ ...s, [type]: { status: "done", text: localCare(type, wx) } }));
      return;
    }

    const label = animalLabel(type, lang);
    const labelEn = animalLabel(type, "en");
    try {
      const ctx = JSON.stringify({
        animalSpecies: labelEn.toLowerCase(),
        temperatureC: wx.tempC,
        humidityPct: wx.humidity,
        windKmh: wx.wind,
        precipitationMm: wx.precip,
        weatherCode: wx.code,
        location: wx.location,
      });
      const result = await requestAI(
        {
          mode: "care",
          lang,
          appMode: "online",
          context: ctx,
          seed: `${type}-${Date.now().toString(36)}`,
          messages: [
            {
              role: "user",
              content:
                lang === "hi"
                  ? `मेरे ${label} के लिए अभी के मौसम (${Math.round(wx.tempC)}°C, नमी ${wx.humidity}%, हवा ${Math.round(wx.wind)} किमी/घंटा) में बिल्कुल सटीक देखभाल बताएं — यह सलाह सिर्फ़ ${label} के लिए हो, किसी और जानवर के लिए नहीं।`
                  : `My animal is a ${labelEn.toLowerCase()}. The weather right now is ${Math.round(wx.tempC)}°C, ${wx.humidity}% humidity, ${Math.round(wx.wind)} km/h wind, ${wx.precip}mm rain. Give care advice that is specific to ${labelEn.toLowerCase()} only — not generic advice that would apply to any animal.`,
            },
          ],
        },
        { attempts: 1, timeoutMs: 56000 }
      );
      setCare((s) => ({
        ...s,
        [type]: {
          status: "done",
          text: result.reply.trim().length > 10 ? result.reply : localCare(type, wx),
        },
      }));
    } catch {
      // The card always resolves, even if the API route itself cannot be reached.
      setCare((s) => ({ ...s, [type]: { status: "done", text: localCare(type, wx) } }));
    }
  }, [wx, online, lang, care, localCare]);

  const C = wx?.code ?? 0;
  const Info = codeInfo(C);
  const f = (c: number) => (c * 9) / 5 + 32;

  return (
    <div ref={focusRef} className="scroll-mt-24">
      {!online && (
        <div className="glass fade-up rounded-3xl p-5">
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-red-500/15 text-red-500">
              <WifiOff size={20} />
            </span>
            <div>
              <p className="font-display text-[15px] font-bold">{t("weatherTitle")}</p>
              <p className="mt-1 text-[13px] leading-relaxed text-soft">{t("weatherOffline")}</p>
            </div>
          </div>
          <button disabled className="btn-press mt-4 h-12 w-full cursor-not-allowed rounded-2xl border border-line bg-[var(--chip)] font-bold text-faint opacity-60">
            {t("getWeather")}
          </button>
        </div>
      )}

      {online && (phase === "idle" || phase === "permit") && (
        <div className="glass fade-up relative overflow-hidden rounded-3xl p-5">
          <div className="pointer-events-none absolute -right-8 -top-10 h-32 w-32 rounded-full bg-gradient-to-br from-amber-400/25 to-transparent blur-2xl" />
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-sky-400 to-blue-600 text-white shadow-md">
              <CloudSun size={20} />
            </span>
            <div className="flex-1">
              <p className="font-display text-[15px] font-bold">{phase === "permit" ? t("permitTitle") : t("weatherSub")}</p>
              <p className="mt-1 text-[12.5px] leading-relaxed text-soft">{t("getWeatherHint")}</p>
            </div>
          </div>
          {phase === "idle" ? (
            <button onClick={() => setPhase("permit")} className="btn-brand btn-press mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl font-display font-bold">
              <LocateFixed size={18} /> {t("getWeather")}
            </button>
          ) : (
            <div className="mt-4 grid grid-cols-2 gap-3">
              <button onClick={() => setPhase("idle")} className="btn-press h-12 rounded-2xl border border-line bg-surface font-bold text-soft">{t("permitNo")}</button>
              <button onClick={locate} className="btn-brand btn-press h-12 rounded-2xl font-display font-bold">{t("permitYes")}</button>
            </div>
          )}
        </div>
      )}

      {online && (phase === "locating" || phase === "loading") && (
        <div className="glass fade-up rounded-3xl p-5">
          <Spinner label={phase === "locating" ? t("locating") : t("loading")} />
          <div className="mt-2 space-y-2">
            <div className="shimmer h-14 rounded-2xl" />
            <div className="shimmer h-20 rounded-2xl" />
          </div>
        </div>
      )}

      {online && (phase === "error" || phase === "manual") && (
        <div className="glass fade-up rounded-3xl p-5">
          <p className="font-display text-[15px] font-bold">{t("gpsFail")}</p>
          <p className="mt-1 text-[13px] text-soft">{t("chooseManually")}</p>
          <div className="mt-3 flex gap-2">
            <input
              value={village}
              onChange={(e) => setVillage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && findVillage()}
              placeholder={t("villagePh")}
              className="glass-input h-12 flex-1 rounded-2xl px-4 text-[14.5px]"
            />
            <button onClick={findVillage} className="btn-brand btn-press h-12 rounded-2xl px-5 font-bold">{t("ok")}</button>
          </div>
        </div>
      )}

      {online && phase === "ready" && wx && (
        <div className="glass fade-up overflow-hidden rounded-3xl">
          <div className="bg-gradient-to-r from-orange-500/12 via-transparent to-green-600/12 px-4 pb-3 pt-4">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2.5">
                <span className="grid h-12 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-sky-400 to-blue-600 text-white shadow">
                  <Info.Icon size={24} />
                </span>
                <div>
                  <p className="font-display text-[15px] font-bold leading-tight">{t("weatherTitle")}</p>
                  <p className="mt-0.5 flex items-start gap-1 text-[11.5px] font-semibold leading-snug text-soft">
                    <MapPin size={11} className="mt-0.5 shrink-0 text-brand" />
                    <span>
                      {wx.location}
                      {wx.landmark && <span className="text-faint"> · {wx.landmark}</span>}
                    </span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => lastCoords.current && load(lastCoords.current.lat, lastCoords.current.lon)}
                aria-label={t("weatherRefresh")}
                className="btn-press grid h-9 w-9 shrink-0 place-items-center rounded-full border border-line bg-surface text-soft"
              >
                <RefreshCw size={15} />
              </button>
            </div>

            <div className="mt-3 flex items-end justify-between">
              <div>
                <p className="font-display text-[38px] font-black leading-none">
                  {Math.round(wx.tempC)}°C
                  <span className="ml-2 text-[17px] font-bold text-soft">{Math.round(f(wx.tempC))}°F</span>
                </p>
                <p className="mt-1 text-[12.5px] font-semibold text-soft">{lang === "hi" ? Info.hi : Info.en}</p>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-3 gap-2">
              {[
                { Icon: Droplets, label: t("humidity"), val: `${wx.humidity}%` },
                { Icon: Wind, label: t("wind"), val: `${Math.round(wx.wind)} ${t("kmh")}` },
                { Icon: Umbrella, label: t("precip"), val: `${wx.precip.toFixed(1)} ${t("mm")}` },
              ].map((x) => (
                <div key={x.label} className="rounded-2xl border border-line bg-surface px-2 py-2.5 text-center">
                  <x.Icon size={15} className="mx-auto text-brand" />
                  <p className="mt-1 text-[13px] font-black">{x.val}</p>
                  <p className="text-[10px] font-semibold text-faint">{x.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Past 3 + next 3 */}
          <div className="border-t border-line px-4 py-3">
            <p className="mb-2 text-[10.5px] font-black uppercase tracking-wider text-faint">{t("pastDays")}</p>
            <div className="grid grid-cols-3 gap-2">
              {wx.days.slice(0, 3).map((d) => (
                <DayChip key={d.date} d={d} lang={lang} t={t} />
              ))}
            </div>
            <p className="mb-2 mt-3 text-[10.5px] font-black uppercase tracking-wider text-faint">{t("nextDays")}</p>
            <div className="grid grid-cols-4 gap-2">
              {wx.days.slice(todayIdx, todayIdx + 4).map((d, i) => (
                <DayChip key={d.date} d={d} lang={lang} t={t} highlight={i === 0} todayLabel={t("today")} />
              ))}
            </div>
          </div>

          {/* Livestock-wise AI care */}
          <div className="border-t border-line px-4 pb-4 pt-3">
            <p className="flex items-center gap-1.5 text-[12.5px] font-black">
              <HeartPulse size={14} className="text-brand" /> {t("livestockCare")}
            </p>
            <p className="mb-2 mt-0.5 text-[11px] text-faint">{t("tapAnimalAdvice")}</p>
            <div className="flex flex-wrap gap-2">
              {careButtons.map((b) => (
                <button
                  key={b}
                  onClick={() => askCare(b)}
                  className={`btn-press rounded-full border px-3.5 py-2 text-[12.5px] font-bold transition-all ${
                    careAnimal === b
                      ? "border-transparent bg-gradient-to-r from-orange-500 to-green-600 text-white shadow"
                      : "border-line bg-surface text-soft"
                  }`}
                >
                  {animalLabel(b, lang)}
                  {care[b]?.status === "done" && careAnimal !== b && (
                    <span className="ml-1.5 text-[10px] text-emerald-500">✓</span>
                  )}
                </button>
              ))}
            </div>
            {careAnimal && (
              <div className="pop-in mt-3 rounded-2xl border border-line bg-surface p-3.5">
                {care[careAnimal]?.status === "loading" ? (
                  <div>
                    <Spinner label={t("careLoading")} />
                    <div className="mt-2 space-y-1.5">
                      <div className="shimmer h-3 w-3/4 rounded-full" />
                      <div className="shimmer h-3 w-full rounded-full" />
                      <div className="shimmer h-3 w-2/3 rounded-full" />
                    </div>
                  </div>
                ) : care[careAnimal]?.text ? (
                  <div className="text-[13px] leading-relaxed">
                    <Rich text={care[careAnimal].text} />
                  </div>
                ) : (
                  <button
                    onClick={() => askCare(careAnimal)}
                    className="btn-press flex h-10 w-full items-center justify-center gap-1.5 rounded-xl border border-line text-[13px] font-bold text-brand"
                  >
                    <RefreshCw size={14} /> {t("retry")}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function DayChip({ d, lang, highlight, todayLabel }: { d: WxDay; lang: string; t: (k: never) => string; highlight?: boolean; todayLabel?: string }) {
  const I = codeInfo(d.code);
  return (
    <div className={`rounded-2xl border px-1.5 py-2 text-center ${highlight ? "border-transparent bg-gradient-to-b from-orange-500/20 to-green-600/20" : "border-line bg-surface"}`}>
      <p className="text-[10px] font-bold text-soft">{iFmt(d.date, lang, todayLabel)}</p>
      <I.Icon size={15} className="mx-auto mt-1 text-brand" />
      <p className="mt-1 text-[11px] font-black">{Math.round(d.tmax)}° / {Math.round(d.tmin)}°</p>
      <p className="text-[9.5px] font-semibold text-faint">{d.precip > 0 ? `${d.precip.toFixed(1)}mm` : "—"}</p>
    </div>
  );
}

function iFmt(iso: string, lang: string, todayLabel?: string) {
  if (todayLabel) return `${fmtDay(iso, lang)}`;
  return fmtDay(iso, lang);
}

/** Every livestock type is always offered; the farmer's own animals come first. */
function useAnimalList(animals: { type: string }[]): string[] {
  const own = Array.from(new Set(animals.map((a) => a.type)));
  const rest = ANIMAL_TYPES.filter((a) => !own.includes(a));
  return [...own, ...rest];
}
