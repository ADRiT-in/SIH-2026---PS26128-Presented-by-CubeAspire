"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  X, SendHorizontal, Mic, MicOff, ImagePlus, Camera, Images, Maximize2, Minimize2,
  Sparkles, Wifi, WifiOff, Trash2, StopCircle, ChevronRight,
} from "lucide-react";
import { useStore } from "@/lib/store";
import { localAnswer, detectLang, isLivestockQuestion, offlineOffTopicReply } from "@/lib/localAI";
import { requestAI } from "@/lib/aiClient";
import type { AiMode } from "@/components/App";

export interface ChatMsg {
  id: string;
  role: "user" | "ai";
  text: string;
  image?: string;
  at: number;
  source?: "live" | "local";
  grounded?: boolean;
}

interface Props {
  mode: AiMode;
  setMode: (m: AiMode) => void;
  intent: "chat" | "photo" | "voice";
  setIntent: (i: "chat" | "photo" | "voice") => void;
}

type Sheet = "none" | "attach" | "photoPrompt" | "voicePermit" | "listening" | "offlineLock";

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

/* ---------- rich markdown-lite renderer (bold / italic / underline / headings) ---------- */
export function parseInline(text: string): React.ReactNode[] {
  const tokens = text.split(
    /(\*\*[^*]+\*\*|\*[^*\n]+\*|<u>[\s\S]*?<\/u>|\[[^\]]+\]\(https?:\/\/[^\s)]+\))/g
  );
  return tokens.map((p, j) => {
    if (p.startsWith("**") && p.endsWith("**") && p.length > 4) {
      return <strong key={j} className="font-black">{p.slice(2, -2)}</strong>;
    }
    if (p.startsWith("*") && p.endsWith("*") && p.length > 2 && !p.startsWith("**")) {
      return <em key={j} className="italic">{p.slice(1, -1)}</em>;
    }
    if (p.startsWith("<u>") && p.endsWith("</u>")) {
      return (
        <span key={j} className="font-bold underline decoration-orange-500 decoration-2 underline-offset-[3px] dark:decoration-green-400">
          {p.slice(3, -4)}
        </span>
      );
    }
    const link = p.match(/^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/);
    if (link) {
      return (
        <a
          key={j}
          href={link[2]}
          target="_blank"
          rel="noopener noreferrer"
          className="font-bold text-brand underline decoration-current/50 underline-offset-2"
        >
          {link[1]}
        </a>
      );
    }
    return <span key={j}>{p}</span>;
  });
}

export function Rich({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <div className="space-y-1">
      {lines.map((ln, i) => {
        if (!ln.trim()) return <div key={i} className="h-1" />;
        const headingMatch = ln.trim().match(/^\*\*(.+)\*\*$|^#{1,3}\s+(.+)$/);
        if (headingMatch) {
          return (
            <p key={i} className="grad-brand font-display text-[15px] font-black leading-snug">
              {headingMatch[1] || headingMatch[2]}
            </p>
          );
        }
        const isBullet = /^\s*[-•]\s+/.test(ln);
        const clean = ln.replace(/^\s*[-•]\s+/, "");
        if (isBullet) {
          return (
            <div key={i} className="flex gap-1.5 pl-1">
              <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-gradient-to-br from-orange-500 to-green-600" />
              <span>{parseInline(clean)}</span>
            </div>
          );
        }
        return <p key={i}>{parseInline(clean)}</p>;
      })}
    </div>
  );
}

async function fileToDataUrl(file: File, maxSize = 768): Promise<string> {
  if (file.type.startsWith("video")) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const v = document.createElement("video");
      v.muted = true;
      v.src = url;
      v.onloadeddata = () => {
        v.currentTime = Math.min(0.5, (v.duration || 1) / 4);
      };
      v.onseeked = () => {
        const c = document.createElement("canvas");
        const scale = Math.min(1, maxSize / Math.max(v.videoWidth, v.videoHeight));
        c.width = v.videoWidth * scale;
        c.height = v.videoHeight * scale;
        c.getContext("2d")?.drawImage(v, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL("image/jpeg", 0.72));
      };
      v.onerror = () => reject(new Error("video"));
    });
  }
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const c = document.createElement("canvas");
      const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
      c.width = img.width * scale;
      c.height = img.height * scale;
      c.getContext("2d")?.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.72));
    };
    img.onerror = () => reject(new Error("image"));
    img.src = url;
  });
}

const CHAT_KEY = "vetto.chat";

export default function VettoAI({ mode, setMode, intent, setIntent }: Props) {
  const store = useStore();
  const { t, online, lang: appLang, addReport } = store;
  const [msgs, setMsgs] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [inputKind, setInputKind] = useState<"chat" | "voice">("chat");
  const [busy, setBusy] = useState(false);
  const [limitedMode, setLimitedMode] = useState(false);
  const [sheet, setSheet] = useState<Sheet>("none");
  const [photo, setPhoto] = useState<string | null>(null);
  const [photoPrompt, setPhotoPrompt] = useState("");
  const [listening, setListening] = useState(false);
  const [interim, setInterim] = useState("");
  const [aiLang, setAiLang] = useState<"en" | "hi">(appLang);
  const [lockKind, setLockKind] = useState<"photo" | "voice">("photo");
  const listRef = useRef<HTMLDivElement>(null);
  const camRef = useRef<HTMLInputElement>(null);
  const galRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<SpeechRecognitionType | null>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => setAiLang(appLang), [appLang]);

  /* load chat */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(CHAT_KEY);
      if (raw) setMsgs(JSON.parse(raw) as ChatMsg[]);
    } catch { /* noop */ }
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem(CHAT_KEY, JSON.stringify(msgs.slice(-40)));
    } catch { /* noop */ }
  }, [msgs]);

  /* welcome message */
  useEffect(() => {
    if (msgs.length === 0) {
      setMsgs([{ id: uid(), role: "ai", text: t("aiWelcome"), at: Date.now(), source: "local" }]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [t]);

  /* intent handling */
  useEffect(() => {
    if (mode === "closed") return;
    if (intent === "photo") {
      if (online) setSheet("attach");
      else { setLockKind("photo"); setSheet("offlineLock"); }
    }
    if (intent === "voice") {
      if (online) setSheet("voicePermit");
      else { setLockKind("voice"); setSheet("offlineLock"); }
    }
  }, [mode, intent, online]);

  const scrollDown = useCallback(() => {
    requestAnimationFrame(() => {
      listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
    });
  }, []);
  useEffect(scrollDown, [msgs, busy, scrollDown]);

  /* autosize textarea */
  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "0px";
    ta.style.height = Math.min(120, ta.scrollHeight) + "px";
  }, [input]);

  /* ---------- SEND ---------- */
  const push = useCallback((m: Omit<ChatMsg, "id" | "at">) => {
    setMsgs((s) => [...s, { ...m, id: uid(), at: Date.now() }]);
  }, []);

  const send = useCallback(async (text: string, image?: string, kind: "chat" | "photo" | "voice" = "chat") => {
    const trimmed = text.trim();
    if (!trimmed && !image) return;
    push({ role: "user", text: trimmed || (image ? "(photo)" : ""), image });
    setInput("");
    setInputKind("chat");
    setPhoto(null);
    setPhotoPrompt("");
    setSheet("none");

    addReport({
      kind: image ? "photo" : kind === "voice" ? "voice" : "chat",
      text: trimmed || "(photo)",
      image,
      status: online ? "synced" : "queued",
    });

    setBusy(true);

    if (!online) {
      // Offline tier: on-device knowledge answers livestock questions only.
      const usedTexts = msgs.filter((m) => m.role === "ai").map((m) => m.text);
      const useLang = detectLang(trimmed, aiLang);
      const reply = isLivestockQuestion(trimmed)
        ? localAnswer(trimmed, useLang, usedTexts)
        : offlineOffTopicReply(trimmed, useLang);
      setTimeout(() => {
        push({ role: "ai", text: reply, source: "local" });
        setLimitedMode(false);
        setBusy(false);
      }, 600);
      return;
    }

    try {
      const history = [...msgs, { role: "user" as const, text: trimmed, image }]
        .slice(-12)
        .map((m) => ({
          role: (m.role === "ai" ? "assistant" : "user") as "user" | "assistant",
          content: m.text,
        }));
      const data = await requestAI(
        {
          messages: history,
          image,
          lang: aiLang,
          mode: "chat",
          appMode: "online",
          seed: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
        },
        { attempts: 1, timeoutMs: 57000 }
      );
      push({
        role: "ai",
        text: data.reply,
        source: data.source,
        grounded: data.grounded,
      });
      setLimitedMode(Boolean(data.limitedMode));
    } catch {
      // If the app route itself is unreachable, fall back to the offline livestock-only contract.
      const usedTexts = msgs.filter((m) => m.role === "ai").map((m) => m.text);
      const useLang = detectLang(trimmed, aiLang);
      const reply = isLivestockQuestion(trimmed)
        ? (image
            ? `${localAnswer(trimmed || (useLang === "hi" ? "मेरे पशु की फोटो" : "my animal photo"), useLang, usedTexts)}\n\n${t("aiImageFallback")}`
            : localAnswer(trimmed, useLang, usedTexts))
        : offlineOffTopicReply(trimmed || (useLang === "hi" ? "यह सवाल" : "this question"), useLang);
      push({ role: "ai", text: reply, source: "local" });
      setLimitedMode(true);
    } finally {
      setBusy(false);
    }
  }, [msgs, online, aiLang, push, t, addReport]);

  /* ---------- PHOTO FLOW ---------- */
  const onPickFile = async (files: FileList | null) => {
    const f = files?.[0];
    if (!f) return;
    try {
      const url = await fileToDataUrl(f);
      setPhoto(url);
      setSheet("photoPrompt");
    } catch {
      setSheet("none");
    }
  };

  /* ---------- VOICE FLOW ---------- */
  type SpeechRecognitionType = {
    lang: string;
    continuous: boolean;
    interimResults: boolean;
    start: () => void;
    stop: () => void;
    abort: () => void;
    onresult: ((e: { resultIndex: number; results: { isFinal: boolean; [k: number]: { transcript: string } }[] }) => void) | null;
    onend: (() => void) | null;
    onerror: ((e: { error?: string }) => void) | null;
  };

  const SR: (new () => SpeechRecognitionType) | null =
    typeof window !== "undefined"
      ? ((window as unknown as { SpeechRecognition?: new () => SpeechRecognitionType; webkitSpeechRecognition?: new () => SpeechRecognitionType }).SpeechRecognition ||
        (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionType }).webkitSpeechRecognition ||
        null)
      : null;

  const startListening = () => {
    if (!SR) {
      setSheet("none");
      push({ role: "ai", text: t("voiceUnsupported"), source: "local" });
      return;
    }
    try {
      const rec = new SR();
      recRef.current = rec;
      rec.lang = aiLang === "hi" ? "hi-IN" : "en-IN";
      rec.continuous = true;
      rec.interimResults = true;
      let finalText = "";
      rec.onresult = (e) => {
        let inter = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          if (e.results[i].isFinal) finalText += e.results[i][0].transcript + " ";
          else inter += e.results[i][0].transcript;
        }
        setInterim(inter);
        setInputKind("voice");
        setInput((finalText + inter).trim());
      };
      rec.onend = () => {
        setListening(false);
        setSheet("none");
        setInterim("");
      };
      rec.onerror = () => {
        setListening(false);
        setSheet("none");
        setInterim("");
        push({ role: "ai", text: t("micNotAllowed"), source: "local" });
      };
      setInterim("");
      setListening(true);
      setSheet("listening");
      rec.start();
    } catch {
      setListening(false);
    }
  };

  const stopListening = () => {
    recRef.current?.stop();
    setListening(false);
    setSheet("none");
  };

  // Mention a real mode switch once, briefly, so the conversation still feels continuous.
  const prevOnlineRef = useRef<boolean | null>(null);
  useEffect(() => {
    if (prevOnlineRef.current === null) {
      prevOnlineRef.current = online;
      return;
    }
    if (prevOnlineRef.current !== online) {
      push({
        role: "ai",
        text: online ? t("aiModeSwitchedOnline") : t("aiModeSwitchedOffline"),
        source: "local",
      });
      if (online) setLimitedMode(false);
      prevOnlineRef.current = online;
    }
  }, [online, push, t]);

  /* quick suggestions */
  const suggestions = useMemo(
    () =>
      aiLang === "hi"
        ? ["मेरी गाय खाना नहीं खा रही", "सरकारी फॉर्म समझने में मदद करें", "मासिक खर्च की योजना बनाएँ", "इस फोटो में क्या दिख रहा है?"]
        : ["My cow is not eating", "Help me understand a government form", "Plan my monthly expenses", "What is visible in this photo?"],
    [aiLang]
  );

  if (mode === "closed") return null;
  const full = mode === "full";

  // The status chip always reflects the user's actual connection mode,
  // never which engine produced the last answer.
  const statusChip = online
    ? { label: t("online"), Icon: Wifi, cls: "border-emerald-500/40 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300" }
    : { label: t("offline"), Icon: WifiOff, cls: "border-red-400/40 bg-red-500/15 text-red-600 dark:text-red-300" };

  return (
    <div
      className={`fixed z-[75] ${
        full
          ? "inset-0"
          : "inset-x-2 bottom-[92px] sm:inset-x-auto sm:right-6 sm:w-[400px]"
      }`}
      role="dialog"
      aria-label={t("aiTitle")}
    >
      <div
        className={`glass-strong pop-in flex flex-col overflow-hidden ${
          full ? "h-full rounded-none sm:m-4 sm:h-[calc(100%-2rem)] sm:rounded-[28px] sm:mx-auto sm:max-w-2xl" : "h-[62dvh] max-h-[640px] rounded-[26px]"
        }`}
      >
        {/* ---------- HEADER ---------- */}
        <div className="flex items-center gap-2 border-b border-line bg-gradient-to-r from-orange-500/10 via-transparent to-green-600/10 px-3 py-2.5">
          <span className="relative grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-to-br from-orange-500 to-green-600 p-[2px]">
            <span className="grid h-full w-full place-items-center overflow-hidden rounded-full bg-black">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/img/ai-logo.png" alt="AI" className="h-[88%] w-[88%] rounded-full object-cover" />
            </span>
            <span
              aria-hidden="true"
              className={`absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-[var(--bg)] ${
                online ? "bg-emerald-400" : "bg-red-500"
              }`}
            />
          </span>
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 font-display text-[15px] font-black leading-tight">
              {t("aiTitle")} <Sparkles size={13} className="text-brand" />
            </p>
            <span className={`mt-0.5 inline-flex items-center gap-1 rounded-full border px-1.5 py-px text-[9.5px] font-bold ${statusChip.cls}`}>
              <statusChip.Icon size={10} /> {statusChip.label}
            </span>
          </div>

          {/* Language segmented control */}
          <div className="flex items-center rounded-full border border-line bg-surface p-0.5">
            {(["en", "hi"] as const).map((l) => (
              <button
                key={l}
                onClick={() => setAiLang(l)}
                className={`btn-press rounded-full px-2.5 py-1 text-[11px] font-black ${
                  aiLang === l ? "bg-gradient-to-r from-orange-500 to-green-600 text-white shadow" : "text-soft"
                }`}
              >
                {l === "en" ? "EN" : "हिं"}
              </button>
            ))}
          </div>

          <button
            aria-label={full ? t("collapse") : t("expand")}
            onClick={() => setMode(full ? "panel" : "full")}
            className="btn-press grid h-9 w-9 place-items-center rounded-full border border-line bg-surface text-soft"
          >
            {full ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </button>
          <button
            aria-label={t("close")}
            onClick={() => {
              stopListening();
              setMode("closed");
              setSheet("none");
              setIntent("chat");
            }}
            className="btn-press grid h-9 w-9 place-items-center rounded-full border border-line bg-surface text-soft"
          >
            <X size={17} />
          </button>
        </div>

        {/* ---------- CAPABILITY STRIP ---------- */}
        <div
          className={`flex items-center gap-1.5 px-3.5 py-1.5 text-[10.5px] font-bold ${
            online
              ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
              : "bg-red-500/10 text-red-600 dark:text-red-300"
          }`}
        >
          {online ? <Wifi size={11} className="shrink-0" /> : <WifiOff size={11} className="shrink-0" />}
          <span className="leading-snug">{online ? t("aiOnlineFull") : t("aiOfflineBadge")}</span>
        </div>

        {limitedMode && online && (
          <div className="flex items-start gap-2 border-b border-amber-500/20 bg-amber-500/10 px-3.5 py-2 text-[11px] text-amber-700 dark:text-amber-200">
            <WifiOff size={12} className="mt-0.5 shrink-0" />
            <div>
              <p className="font-black uppercase tracking-wide">{t("aiLimitedMode")}</p>
              <p className="mt-0.5 leading-snug">{t("aiLimitedModeSub")}</p>
            </div>
          </div>
        )}

        {/* ---------- MESSAGES ---------- */}
        <div ref={listRef} className="nice-scroll flex-1 space-y-4 overflow-y-auto px-4 py-6">
          {msgs.map((m) => (
            <div key={m.id} className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}>
              <div
                className={`max-w-[90%] sm:max-w-[85%] rounded-[24px] px-4 py-3 text-[14.5px] leading-relaxed shadow-sm animate-[pop-in_0.3s_ease] ${
                  m.role === "user"
                    ? "rounded-tr-none bg-gradient-to-br from-orange-600 to-orange-500 text-white shadow-orange-500/10"
                    : "rounded-tl-none border border-line bg-surface-strong"
                }`}
              >
                {m.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={m.image} alt="upload" className="mb-3 max-h-60 w-full rounded-2xl object-cover shadow-sm" />
                )}
                {m.role === "ai" ? <Rich text={m.text} /> : <p className="whitespace-pre-wrap">{m.text}</p>}
              </div>
              {m.role === "ai" && (m.source || m.grounded) && (
                <div className="mt-2 flex items-center gap-2 px-1">
                  <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-black uppercase tracking-wider ${
                    m.grounded || m.source === "live" ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-600" : "border-line bg-black/5 text-faint"
                  }`}>
                    {m.source === "live" ? <Wifi size={9} /> : <WifiOff size={9} />}
                    {m.grounded ? t("aiGrounded") : m.source === "live" ? t("aiLive") : t("aiLocal")}
                  </span>
                </div>
              )}
            </div>
          ))}
          {busy && (
            <div className="flex justify-start">
              <div className="flex items-center gap-2 rounded-full rounded-tl-none border border-line bg-surface-strong px-5 py-3.5 shadow-sm">
                <span className="typing-dot h-2 w-2 rounded-full bg-orange-500" />
                <span className="typing-dot h-2 w-2 rounded-full bg-amber-500" />
                <span className="typing-dot h-2 w-2 rounded-full bg-green-500" />
              </div>
            </div>
          )}
          {msgs.length <= 1 && (
            <div className="pt-1">
              <div className="flex flex-wrap gap-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="btn-press flex items-center gap-1 rounded-full border border-line bg-surface px-3 py-1.5 text-[12px] font-semibold text-soft"
                  >
                    {s} <ChevronRight size={12} />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* ---------- SHEETS ---------- */}
        {sheet === "attach" && (
          <div className="pop-in border-t border-line bg-surface px-4 pb-4 pt-3">
            <p className="mb-2.5 text-center text-[13px] font-bold text-soft">{t("addPhotoAi")}</p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => camRef.current?.click()}
                className="btn-brand btn-press flex h-[104px] flex-col items-center justify-center gap-2 rounded-2xl font-bold"
              >
                <Camera size={26} /> {t("camera")}
              </button>
              <button
                onClick={() => galRef.current?.click()}
                className="btn-press flex h-[104px] flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-[var(--line-strong)] bg-[var(--chip)] font-bold"
              >
                <Images size={26} className="text-brand" /> {t("gallery")}
              </button>
            </div>
            <input ref={camRef} type="file" accept="image/*,video/*" capture="environment" className="hidden" onChange={(e) => onPickFile(e.target.files)} />
            <input ref={galRef} type="file" accept="image/*,video/*" className="hidden" onChange={(e) => onPickFile(e.target.files)} />
          </div>
        )}

        {sheet === "photoPrompt" && photo && (
          <div className="pop-in border-t border-line bg-surface px-4 pb-4 pt-3">
            <div className="relative mx-auto w-fit">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={photo} alt="preview" className="max-h-40 rounded-2xl border border-line object-cover" />
              <button
                onClick={() => { setPhoto(null); setSheet("attach"); }}
                className="btn-press absolute -right-2 -top-2 grid h-7 w-7 place-items-center rounded-full bg-red-500 text-white shadow"
                aria-label={t("removePhoto")}
              >
                <Trash2 size={13} />
              </button>
            </div>
            <p className="mb-1.5 mt-3 text-[12.5px] font-bold text-soft">{t("photoAskPrompt")}</p>
            <textarea
              value={photoPrompt}
              onChange={(e) => setPhotoPrompt(e.target.value)}
              rows={2}
              placeholder={t("typeSomething")}
              className="glass-input w-full resize-none rounded-2xl px-3.5 py-2.5 text-[14px]"
            />
            <button
              onClick={() => send(photoPrompt, photo, "photo")}
              className="btn-brand btn-press mt-2.5 flex h-12 w-full items-center justify-center gap-2 rounded-2xl font-display font-bold"
            >
              <SendHorizontal size={17} /> {t("sendPhoto")}
            </button>
          </div>
        )}

        {sheet === "voicePermit" && (
          <div className="pop-in border-t border-line bg-surface px-4 pb-5 pt-4 text-center">
            <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-orange-500 to-green-600 text-white shadow-lg">
              <Mic size={24} />
            </span>
            <p className="font-display text-[16px] font-bold">{t("allowMic")}</p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  setSheet("none");
                  setIntent("chat");
                  setMode("closed");
                }}
                className="btn-press h-12 rounded-2xl border border-line bg-surface font-bold text-soft"
              >
                {t("no")}
              </button>
              <button onClick={startListening} className="btn-brand btn-press h-12 rounded-2xl font-display font-bold">
                {t("yes")}
              </button>
            </div>
          </div>
        )}

        {sheet === "listening" && (
          <div className="pop-in border-t border-line bg-surface px-4 pb-5 pt-4 text-center">
            <button
              onClick={stopListening}
              className="rec-pulse btn-press mx-auto grid h-16 w-16 place-items-center rounded-full bg-red-500 text-white"
              aria-label={t("stop")}
            >
              {listening ? <StopCircle size={26} /> : <MicOff size={24} />}
            </button>
            <p className="mt-3 text-[13px] font-bold text-red-500">{t("listening")}</p>
            {(input || interim) && (
              <p className="mt-2 rounded-xl border border-line bg-[var(--chip)] px-3 py-2 text-[13px] text-soft">
                {input}{interim}
              </p>
            )}
          </div>
        )}

        {sheet === "offlineLock" && (
          <div className="pop-in border-t border-line bg-surface px-4 pb-5 pt-4 text-center">
            <span className="mx-auto mb-3 grid h-14 w-14 place-items-center rounded-full bg-red-500/15 text-red-500">
              <WifiOff size={24} />
            </span>
            <p className="font-display text-[15.5px] font-black">{t("aiOfflineLockTitle")}</p>
            <p className="mx-auto mt-1.5 max-w-[320px] text-[12.5px] leading-relaxed text-soft">
              {lockKind === "photo" ? t("aiOfflineLockPhoto") : t("aiOfflineLockVoice")}
            </p>
            <p className="mx-auto mt-2 max-w-[320px] rounded-xl border border-line bg-[var(--chip)] px-3 py-2 text-[11.5px] font-semibold text-soft">
              {t("aiOfflineCanDo")}
            </p>
            <button
              onClick={() => { setSheet("none"); setIntent("chat"); }}
              className="btn-brand btn-press mt-4 h-12 w-full rounded-2xl font-display font-bold"
            >
              {t("typeInstead")}
            </button>
          </div>
        )}

        {/* ---------- COMPOSER (animated saffron⇄green border) ---------- */}
        {sheet !== "voicePermit" && sheet !== "attach" && sheet !== "photoPrompt" && sheet !== "listening" && sheet !== "offlineLock" && (
          <div className="border-t border-line bg-surface p-3">
            <div className="ai-glow">
              <div className="flex items-end gap-1.5 rounded-[1.3rem] bg-[var(--surface-strong)] p-1.5">
                <button
                  aria-label={t("addPhotoAi")}
                  onClick={() => {
                    if (online) setSheet("attach");
                    else { setLockKind("photo"); setSheet("offlineLock"); }
                  }}
                  className={`btn-press relative grid h-10 w-10 shrink-0 place-items-center rounded-full ${online ? "text-soft" : "text-faint opacity-60"}`}
                >
                  <ImagePlus size={19} />
                  {!online && <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-red-500" />}
                </button>
                <textarea
                  ref={taRef}
                  value={input}
                  onChange={(e) => {
                    setInput(e.target.value);
                    setInputKind("chat");
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      send(input, undefined, inputKind);
                    }
                  }}
                  rows={1}
                  placeholder={t("aiPlaceholder")}
                  className="max-h-[120px] flex-1 resize-none bg-transparent px-1 py-2 text-[14.5px] leading-snug placeholder:text-faint focus:outline-none"
                  aria-label={t("aiPlaceholder")}
                />
                <button
                  aria-label={t("tapMic")}
                  onClick={() => {
                    if (online) setSheet("voicePermit");
                    else { setLockKind("voice"); setSheet("offlineLock"); }
                  }}
                  className={`btn-press relative grid h-10 w-10 shrink-0 place-items-center rounded-full ${online ? "text-soft" : "text-faint opacity-60"}`}
                >
                  <Mic size={19} />
                  {!online && <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-red-500" />}
                </button>
                <button
                  aria-label={t("send")}
                  disabled={!input.trim() && !photo}
                  onClick={() => send(input, photo || undefined, photo ? "photo" : inputKind)}
                  className="btn-press grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-orange-500 to-green-600 text-white shadow-md disabled:opacity-40"
                >
                  <SendHorizontal size={18} />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
