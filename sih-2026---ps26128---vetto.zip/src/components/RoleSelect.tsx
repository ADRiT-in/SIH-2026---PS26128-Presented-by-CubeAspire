"use client";

import React, { useState } from "react";
import { Sprout, Stethoscope, UserRound, ChevronRight, Sparkles, LogOut } from "lucide-react";
import { useStore, Role } from "@/lib/store";

export default function RoleSelect() {
  const { t, setRole, logout, profile } = useStore();
  const [picked, setPicked] = useState<Role | null>(null);

  const options: { id: Role; icon: React.ReactNode; title: string; sub: string; ring: string }[] = [
    {
      id: "farmer",
      icon: <Sprout size={22} />,
      title: t("roleFarmer"),
      sub: t("roleFarmerSub"),
      ring: "from-amber-400 to-orange-600",
    },
    {
      id: "vet",
      icon: <Stethoscope size={22} />,
      title: t("roleVet"),
      sub: t("roleVetSub"),
      ring: "from-teal-400 to-emerald-600",
    },
    {
      id: "guest",
      icon: <UserRound size={22} />,
      title: t("roleGuest"),
      sub: t("roleGuestSub"),
      ring: "from-sky-400 to-indigo-600",
    },
  ];

  const first = (profile.name || "").trim().split(/\s+/)[0];

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: "url(/img/login-hero.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center 30%",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/50 to-[#071310]/96" />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-[560px] flex-col px-5 pb-8 pt-12">
        <div className="fade-up text-center">
          <h1 className="font-display text-[40px] font-black tracking-tight text-white drop-shadow">
            <span className="bg-gradient-to-br from-amber-300 via-orange-400 to-green-400 bg-clip-text text-[50px] text-transparent">V</span>
            ETTO
          </h1>
          {first && (
            <p className="mt-1 text-[14px] font-bold text-amber-100/90">
              {t("namaste")}, {first}
            </p>
          )}
        </div>

        <div className="fade-up mt-8" style={{ animationDelay: "0.06s" }}>
          <h2 className="flex items-center justify-center gap-2 text-center font-display text-[20px] font-black leading-snug text-white">
            <Sparkles size={16} className="text-amber-300" />
            {t("whoAreYou")}
          </h2>
          <p className="mt-1.5 text-center text-[12.5px] leading-relaxed text-white/65">{t("whoAreYouSub")}</p>
        </div>

        <div className="mt-6 space-y-3">
          {options.map((o, i) => {
            const active = picked === o.id;
            return (
              <button
                key={o.id}
                onClick={() => setPicked(o.id)}
                aria-pressed={active}
                className={`fade-up btn-press flex w-full items-center gap-3.5 rounded-[26px] border p-4 text-left transition-all ${
                  active
                    ? "border-amber-300/70 bg-white/20 shadow-xl shadow-black/30"
                    : "border-white/20 bg-white/10"
                } backdrop-blur-xl`}
                style={{ animationDelay: `${0.1 + i * 0.07}s` }}
              >
                <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br ${o.ring} text-white shadow-lg`}>
                  {o.icon}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-[15px] font-black leading-snug text-white">{o.title}</span>
                  <span className="mt-0.5 block text-[11.5px] leading-snug text-white/70">{o.sub}</span>
                </span>
                <span
                  className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-all ${
                    active ? "border-amber-300 bg-amber-300" : "border-white/40"
                  }`}
                >
                  {active && <span className="h-2 w-2 rounded-full bg-[#071310]" />}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex-1" />

        <button
          disabled={!picked}
          onClick={() => picked && setRole(picked)}
          className="btn-brand btn-press mt-6 flex h-[56px] w-full items-center justify-center gap-2 rounded-2xl font-display text-[17px] font-bold disabled:opacity-40"
        >
          {t("continueBtn")} <ChevronRight size={19} />
        </button>

        <button
          onClick={logout}
          className="btn-press mx-auto mt-3 flex items-center gap-1.5 text-[12.5px] font-bold text-white/55"
        >
          <LogOut size={14} /> {t("logout")}
        </button>
      </div>
    </div>
  );
}
