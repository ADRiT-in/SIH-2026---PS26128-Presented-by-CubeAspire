import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Plus_Jakarta_Sans, Sora, Noto_Sans_Devanagari } from "next/font/google";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
  display: "swap",
});
const sora = Sora({
  subsets: ["latin"],
  variable: "--font-sora",
  display: "swap",
});
const devanagari = Noto_Sans_Devanagari({
  subsets: ["devanagari"],
  variable: "--font-dev",
  display: "swap",
});

export const metadata: Metadata = {
  title: "VETTO — Livestock Early-Warning & Response Intelligence",
  description:
    "VETTO — a one-stop solution for pastoralists. Detect the signal. Understand the risk. Act before it spreads.",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#fdf3e3" },
    { media: "(prefers-color-scheme: dark)", color: "#071410" },
  ],
  width: "device-width",
  initialScale: 1,
};

const themeBoot = `(function(){try{var u=JSON.parse(localStorage.getItem("vetto.v1")||"{}");var t=u.theme||(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");document.documentElement.setAttribute("data-theme",t);}catch(e){document.documentElement.setAttribute("data-theme","light");}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBoot }} />
      </head>
      <body className={`${jakarta.variable} ${sora.variable} ${devanagari.variable} min-h-screen antialiased`}>
        {children}
      </body>
    </html>
  );
}
