import { NextRequest, NextResponse } from "next/server";
import { localAnswer, isLivestockQuestion, offlineOffTopicReply } from "@/lib/localAI";

export const runtime = "nodejs";
export const maxDuration = 60;

interface ChatMsg {
  role: "user" | "assistant";
  content: string;
}

interface AiBody {
  messages: ChatMsg[];
  image?: string; // data URL
  lang?: "en" | "hi" | "auto";
  mode?: "chat" | "tip" | "care" | "vetdraft";
  seed?: string;
  context?: string; // extra context e.g. weather JSON
  appMode?: "online" | "offline";
}

const ONLINE_SYSTEM_BASE = `You are Vetto AI, a warm, knowledgeable assistant inside the Vetto app for Indian pastoralists and livestock farmers. You are online right now, so you can answer ANY question the user asks — about their animals, farming, weather, government schemes, or anything else in life, exactly like a full general-purpose assistant would. Never refuse a question just because it isn't about livestock.
When the question is about an animal's health, symptoms, feeding, breeding, vaccination or a photo/video/audio the user shared:
- Think step by step: identify the animal and the problem, ask one short follow-up only if a key detail is missing, then give a clear, specific, non-repetitive answer — likely cause, what to do now, what to avoid, when to see a vet, and how to prevent it next time.
- Never state a confirmed diagnosis or give exact medicine dosages. Say findings are AI-assisted and should be verified by a veterinarian.
For every other kind of question, just answer normally and helpfully, in the language the user wrote in (Hindi or English), in a friendly, plain-spoken tone suited to someone who may not be highly literate. Keep answers well-organized but not overly long. Never give the same canned answer twice — always reason freshly from what the user actually asked.

PRIVATE REASONING PROCESS (never reveal hidden chain-of-thought):
1. Read the user's prompt carefully, word by word. Identify every constraint, entity, number, timeframe, attachment and implied goal.
2. Decide whether the task needs calculation, comparison, current web information, image inspection, or domain-specific safety.
3. Check the answer for contradictions, missing parts and unsupported claims before responding.
4. Give only the useful final answer. Do not expose hidden reasoning.

STYLE AND FORMATTING:
- Match the user's language (Hindi or English) unless they explicitly ask otherwise.
- Use **bold** for clear headings or key conclusions, *italics* for emphasis or technical terms, and <u>underline</u> for critical numbers or warnings where useful.
- Vary the opening, structure and examples on every turn. Do not repeat your previous sentence patterns.
- If current web results are available, ground time-sensitive claims in them and include concise markdown source links. Never invent a citation.`;

function systemPrompt(lang: string, mode: string): string {
  const langRule =
    lang === "hi"
      ? "Reply ONLY in simple natural Hindi (Devanagari), conversational farmer-friendly."
      : lang === "en"
      ? "Reply ONLY in simple English."
      : "Detect the language of the user's message and reply in that same language (Hindi or English). Match their mother tongue naturally.";
  const modeRule =
    mode === "vetdraft"
      ? `YOU ARE NOW DRAFTING FOR A QUALIFIED VETERINARIAN / GOVERNMENT ANIMAL-HEALTH OFFICIAL.
The reader of your output is the DOCTOR, who will review, edit and then send it to the farmer. So this draft must be clinically serious yet written in language the farmer will finally understand.

THINK DEEPLY BEFORE WRITING (internal only):
- Parse every clinical clue in the case: species, number affected, exact symptom wording, duration, urgency flag, season, and any photo.
- Build a SHORT differential: the 2-3 most likely conditions for this exact presentation, most likely first.
- Decide what the farmer must do in the next few hours vs the next few days.
- Note the red flags that would require the doctor to visit in person or escalate.

OUTPUT EXACTLY THIS STRUCTURE, nothing else:
**Assessment**
2-3 sentences naming the *most likely* condition(s) using hedged clinical language ("findings are consistent with…", "most likely…"). Reference the farmer's own described signs.

**Immediate Care (next 24 hours)**
- 3-4 concrete bullets with <u>quantities</u>, <u>frequencies</u> and <u>timings</u>.

**Treatment Notes**
- 2-3 bullets. Name drug *classes* and mention that dosage must be confirmed by the attending veterinarian by body weight. Mention <u>milk/meat withdrawal</u> where relevant.

**Watch For — Call Immediately If**
- 3 bullets of red-flag signs.

**Prevention / Follow-up**
- 2 bullets, plus when to re-check.

FORMAT RULES: **bold** every heading and any key clinical term; *italics* for condition names and emphasis; <u>underline</u> every number, dose, duration, timing and warning. Keep the whole draft under ~220 words. Write a FRESH draft every time — never reuse sentence patterns from a previous draft.`
      : mode === "tip"
      ? "The user wants a fresh practical livestock tip for Indian farmers. Give ONE tip: **a catchy short bold title line**, then 2-3 crisp sentences using <u>underline</u> for numbers and *italics* for technical words. Make it specific and actionable (season, feed, water, housing, health or economics). Pick a DIFFERENT topic than typical: rotate through milk, fodder, calf, breeding, cleaning, market prices, poultry, goats, water, record-keeping."
      : mode === "care"
      ? `The user tapped a specific animal button while viewing their local weather. The JSON context contains the exact temperature, humidity, wind speed, precipitation and weather code at their location RIGHT NOW. The user message names the animal species.

YOUR JOB: Give advice that is SPECIFIC to THAT species AND THAT weather, not generic "give water" advice. Think about what makes THIS animal different from others in THIS weather:
- Cattle vs buffalo (buffalo overheat faster, need wallowing above 38°C; cattle tolerate more sun but lose milk in heat)
- Goats vs sheep (goats need browse not grass; sheep wool insulates in cold but traps heat; goats are more cold-sensitive)
- Poultry (panting threshold ~40°C; egg drop at humidity >75%; need 16h light in winter)
- Pigs (cannot sweat — must have mud/spray; cold piglets need heat lamps)
- Horses/donkeys (workload must halve in heat; hoof care critical in wet)
- Ducks (tolerate rain well but need dry sleeping area)

OUTPUT FORMAT:
**[Animal name] — care for today's weather**
Current: [restate temp, humidity, wind, rain from context].
Then 4-6 bullets, each with a <u>number</u> (quantity, timing, threshold). Each bullet must be something a farmer can DO today.
End with one sentence offering to go deeper.
Never give the same advice for two different species. Never give generic advice that ignores the weather numbers.`
      : "";
  return `${ONLINE_SYSTEM_BASE}\n\nLANGUAGE RULE:\n${langRule}\n\n${modeRule}`;
}

// Settings occasionally contain a key in VETTO_AI_MODEL. Never forward malformed
// values as model IDs: one bad ID would make OpenRouter reject the whole fallback list.
const configuredModel = process.env.VETTO_AI_MODEL?.trim();
const safeConfiguredModel =
  configuredModel &&
  !configuredModel.startsWith("sk-") &&
  /^[a-z0-9_.-]+\/[a-z0-9_.:/-]+$/i.test(configuredModel)
    ? configuredModel
    : undefined;

const TEXT_MODELS = Array.from(
  new Set(
    [
      safeConfiguredModel || "openai/gpt-5",
      "openai/gpt-4.1-mini",
      "google/gemini-2.5-flash",
    ].filter(Boolean) as string[]
  )
).slice(0, 3);

// All models in this list accept image_url input.
const VISION_MODELS = Array.from(
  new Set(
    [
      safeConfiguredModel || "openai/gpt-5",
      "openai/gpt-4.1-mini",
      "google/gemini-2.5-flash",
    ].filter(Boolean) as string[]
  )
).slice(0, 3);

// Tested zero-cost chains, used automatically when the paid account has no credits.
const FREE_TEXT_MODELS = [
  "nvidia/nemotron-3-ultra-550b-a55b:free",
  "nvidia/nemotron-3-super-120b-a12b:free",
  "nex-agi/nex-n2.5-pro:free",
];
const FREE_TEXT_MODELS_B = [
  "openrouter/free",
  "qwen/qwen3.8-27b:free",
  "google/gemma-4-31b-it:free",
];
const FREE_VISION_MODELS = [
  "nex-agi/nex-n2.5-pro:free",
  "inclusionai/ling-3.0-flash-vl:free",
  "dots-studio/dots-3-note-preview:free",
];
const FREE_VISION_MODELS_B = [
  "openrouter/free",
  "google/gemma-4-31b-it:free",
  "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free",
];

interface LiveAIResult {
  text: string;
  model: string;
  grounded: boolean;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isUsableAIText(text: string): boolean {
  const clean = text.trim();
  if (clean.length < 5) return false;
  const low = clean.toLowerCase();
  if ((low.match(/apolog(?:y|ies)/g) || []).length > 1) return false;
  if ((low.match(/correct below/g) || []).length > 1) return false;
  if ((clean.match(/✓/g) || []).length > 6) return false;

  const lines = clean
    .split("\n")
    .map((line) => line.replace(/\s+/g, " ").trim())
    .filter((line) => line.length > 28);
  const counts = new Map<string, number>();
  for (const line of lines) {
    const key = line.toLowerCase();
    counts.set(key, (counts.get(key) || 0) + 1);
    if ((counts.get(key) || 0) >= 3) return false;
  }
  return true;
}

async function callOpenRouter(body: AiBody): Promise<LiveAIResult | null> {
  const key = process.env.VETTO_AI_KEY || process.env.OPENROUTER_API_KEY;
  if (!key) return null;

  const sys = systemPrompt(body.lang || "auto", body.mode || "chat");
  const userMsgs = (body.messages || []).slice(-14).map((m, i, arr) => {
    const isLast = i === arr.length - 1;
    if (isLast && m.role === "user" && body.image) {
      return {
        role: "user" as const,
        content: [
          {
            type: "text",
            text:
              m.content ||
              "Analyze this image carefully. First identify only what is visibly supported, then explain likely interpretations, uncertainties, and useful next steps. Do not invent details.",
          },
          { type: "image_url", image_url: { url: body.image } },
        ],
      };
    }
    return { role: m.role, content: m.content };
  });

  if (body.context) {
    userMsgs.unshift({
      role: "user",
      content: `Context data supplied by the application (use it for reasoning; do not quote raw JSON): ${body.context}`,
    });
  }
  if (body.seed) {
    userMsgs.unshift({
      role: "user",
      content: `Variation token ${body.seed}. Use a new structure and vocabulary; do not mirror an earlier response.`,
    });
  }

  const priorAi = (body.messages || [])
    .filter((m) => m.role === "assistant")
    .slice(-5)
    .map((m) => m.content.split("\n")[0].slice(0, 100))
    .filter(Boolean);
  if (priorAi.length > 0) {
    userMsgs.unshift({
      role: "user",
      content:
        "Avoid repeating these earlier openings: " +
        priorAi.map((x) => `"${x}"`).join("; ") +
        ". Add new value and use a different organization.",
    });
  }

  const models = body.image ? VISION_MODELS : TEXT_MODELS;
  // General chat can search when current or niche information is needed.
  // Specialist care/draft modes stay grounded in supplied case/weather data.
  const enableWeb = (body.mode || "chat") === "chat" && !body.image;
  const requestBody = {
    models,
    provider: { allow_fallbacks: true },
    messages: [{ role: "system", content: sys }, ...userMsgs],
    ...(enableWeb
      ? {
          tools: [
            {
              type: "openrouter:web_search",
              parameters: {
                max_results: 4,
                max_total_results: 8,
                search_context_size: "low",
              },
            },
          ],
        }
      : {}),
    temperature: body.mode === "vetdraft" ? 0.65 : 0.78,
    top_p: 0.95,
    presence_penalty: 0.55,
    frequency_penalty: 0.35,
    max_tokens: body.mode === "vetdraft" ? 1000 : 1100,
  };

  // Availability ladder: paid quality first, then two tested zero-cost tiers.
  // The gateway also performs provider + model failover inside each tier.
  const tiers = [
    { models: body.image ? VISION_MODELS : TEXT_MODELS, web: enableWeb, budget: 26000 },
    { models: body.image ? FREE_VISION_MODELS : FREE_TEXT_MODELS, web: false, budget: 18000 },
    { models: body.image ? FREE_VISION_MODELS_B : FREE_TEXT_MODELS_B, web: false, budget: 12000 },
  ];

  for (let attempt = 0; attempt < tiers.length; attempt++) {
    const tier = tiers[attempt];
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), tier.budget);
    try {
      const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://vetto.app",
          "X-Title": "VETTO",
        },
        body: JSON.stringify({
          ...requestBody,
          models: tier.models,
          ...(tier.web ? {} : { tools: undefined }),
        }),
        signal: ctrl.signal,
        cache: "no-store",
      });

      const retryHeader = Number(res.headers.get("retry-after"));
      const data = (await res.json().catch(() => null)) as {
        model?: string;
        error?: { message?: string };
        choices?: {
          message?: {
            content?: string | { type: string; text?: string }[];
            annotations?: unknown[];
          };
        }[];
      } | null;

      const raw = data?.choices?.[0]?.message?.content;
      const text =
        typeof raw === "string"
          ? raw
          : Array.isArray(raw)
            ? raw.map((c) => (typeof c === "string" ? c : c.text || "")).join(" ")
            : "";
      if (res.ok && isUsableAIText(text)) {
        return {
          text: text.trim(),
          model: data?.model || tier.models[0],
          grounded: Boolean(data?.choices?.[0]?.message?.annotations?.length),
        };
      }

      if (attempt + 1 < tiers.length) {
        const retryMs =
          Number.isFinite(retryHeader) && retryHeader > 0
            ? Math.min(retryHeader * 1000, 1500)
            : 350 + Math.floor(Math.random() * 250);
        await sleep(retryMs);
      }
    } catch {
      if (attempt + 1 < tiers.length) await sleep(350 + Math.floor(Math.random() * 250));
    } finally {
      clearTimeout(timer);
    }
  }
  return null;
}

/* ---------- LOCAL FALLBACK (transparent offline helper) ---------- */

const KEYWORDS: { test: RegExp; en: string[]; hi: string[] }[] = [
  {
    test: /fever|बुखार|ताप|गर्म/i,
    en: [
      "That sounds like your animal may have a fever. **What to do now:**\n- Check body warmth and breathing\n- Keep clean, cool water nearby\n- Offer soft green fodder\nA vet visit within 24 hours is wise. Shall I suggest home-safe comfort steps?",
      "Fever often comes with low appetite. **Quick steps:**\n- Move the animal to shade\n- Wipe with a wet cloth\n- Note if milk or dung changed\nTell me — since when is it warm?",
    ],
    hi: [
      "ऐसा लगता है पशु को **बुखार** हो सकता है। **अभी करें:**\n- शरीर की गर्मी और साँस जांचें\n- साफ़ ठंडा पानी पास रखें\n- हरा नरम चारा दें\n24 घंटे में पशु चिकित्सक से दिखाना ठीक रहेगा। क्या घर पर आराम के उपाय बताऊँ?",
      "बुखार के साथ भूख भी कम होती है। **तुरंत कदम:**\n- पशु को छाँव में रखें\n- गीले कपड़े से पौंछें\n- दूध या गोबर में बदलाव देखें\nबताइए — कब से गर्मी है?",
    ],
  },
  {
    test: /milk|दूध|दुध/i,
    en: [
      "Milk drop usually links to feed, water, heat or stress. **Try:**\n- 15-20% more green fodder + clean water 4-5 times a day\n- Add salt-mineral mix (approx. 50g/day)\n- Keep milking time fixed\nIf udder is hot or hard, see a vet. Is the udder normal?",
      "Less milk can also mean early illness. **Check:**\n- Udder swelling/heat\n- Feed change recently?\n- Water availability\nShare the feed change, I'll guide further.",
    ],
    hi: [
      "दूध कम होना आमतौर पर चारा, पानी, गर्मी या तनाव से जुड़ा है। **करें:**\n- हरा चारा 15-20% बढ़ाएँ + दिन में 4-5 बार साफ़ पानी\n- नमक-खनिज मिश्रण (लगभग 50 ग्राम/दिन) दें\n- दुहाई का समय तय रखें\nथन गर्म या सख्त हो तो डॉक्टर दिखाएँ। थन ठीक है?",
      "दूध कम होना शुरुआती बीमारी का संकेत भी हो सकता है। **देखें:**\n- थन में सूजन/गर्मी\n- हाल में चारा बदला?\n- पानी की उपलब्धता\nचारे के बदलाव के बारे में बताइए, मैं आगे मार्गदर्शन करूँगा।",
    ],
  },
  {
    test: /\b(?:eat|eating|eats|eaten)\b|khana|खाना|खाती|खा रह/i,
    en: [
      "Loss of appetite for over a day is an early warning. **Do:**\n- Smell the feed — mouldy feed must go\n- Offer fresh jaggery water or salt lick\n- Watch for fever signs\nNot eating + not ruminating (chewing cud) = call a vet today. Is it chewing cud?",
      "When animals stop eating, start with the mouth and feed. **Quick checks:**\n- Mouth ulcers or wounds?\n- Fresh feed and water?\n- Any new smell in dung?\nReply with what you saw.",
    ],
    hi: [
      "एक दिन से ज्यादा भूख न लगना शुरुआती चेतावनी है। **करें:**\n- चारा सूँघें — फफूंदी वाला हटाएँ\n- गुड़ का पानी या नमक चटाने दें\n- बुखार के लक्षण देखें\nखाना बंद + जुगाली बंद = आज ही डॉक्टर बुलाएँ। पशु जुगाली कर रहा है?",
      "जब पशु खाना बंद कर दे, मुँह और चारा पहले जांचें। **झटपट जांच:**\n- मुँह में छाले?\n- ताज़ा चारा-पानी?\n- गोबर की गंध बदली?\nजो दिखा, उसके बारे में लिखिए।",
    ],
  },
  {
    test: /vaccin|टीका|tika|tiika/i,
    en: [
      "Good thought! **Key vaccines:**\n- FMD (free under NADCP — call 1962)\n- HS/BQ for cattle-buffalo\n- PPR for goats\nKeep a date card in the app under Vaccinations. Which animal is this for?",
      "Vaccines are cheap insurance. **General schedule:**\n- FMD every 6 months\n- PPR yearly for goats/sheep\n- Poultry: Ranikhet on time\nWant a reminder plan?",
    ],
    hi: [
      "अच्छा विचार! **मुख्य टीके:**\n- खुरपका-मुँहपका (NADCP में नि:शुल्क — 1962 पर कॉल करें)\n- गाय-भैंस के लिए HS/BQ\n- बकरियों के लिए PPR\nऐप के टीकाकरण सेक्शन में तारीख दर्ज करें। किस पशु के लिए पूछ रहे हैं?",
      "टीके सस्ती सुरक्षा हैं। **सामान्य समय:**\n- खुरपका-मुँहपका हर 6 माह\n- बकरी-भेड़ के लिए PPR हर वर्ष\n- मुर्गियों के लिए रानीखेत समय पर\nक्या याद-दहानी योजना बनाऊँ?",
    ],
  },
  {
    test: /diarr|rhea|loose|दस्त|पतला/i,
    en: [
      "Loose motion can dehydrate fast. **First-aid:**\n- ORS water (1 litre water + 6 tsp sugar + half tsp salt) 3-4 times a day\n- Stop green feed for 12 hrs, give dry hay\n- Keep warm and clean\nBlood in dung or weakness = vet urgently. Any blood?",
      "Diarrhoea needs fluids first, medicine later. **Steps:**\n- Homemade ORS every few hours\n- Dry roughage only today\n- Isolate from other animals\nHow many days has it been?",
    ],
    hi: [
      "दस्त से पानी की कमी जल्दी होती है। **प्राथमिक उपचार:**\n- ORS घोल (1 लीटर पानी + 6 चम्मच चीनी + आधा चम्मच नमक) दिन में 3-4 बार\n- हरा चारा 12 घंटे रोकें, सूखा घास दें\n- गर्म और साफ़ रखें\nगोबर में खून या कमज़ोरी हो तो तुरंत डॉक्टर। खून तो नहीं?",
      "दस्त में पहले तरल देना ज़रूरी, दवा बाद में। **कदम:**\n- घर का ORS हर कुछ घंटे में\n- आज केवल सूखा भूसा\n- बाकी जानवरों से अलग रखें\nकितने दिनों से है?",
    ],
  },
  {
    test: /preg|birth|delivery|गर्भ|गाभन|बच्चा|व्याई/i,
    en: [
      "Pregnancy care = calm, good feed, mild exercise. **Focus:**\n- Last 2 months: +500g good concentrate daily\n- Mineral mix daily\n- Dry her 2 months before due date\nLabour for 6+ hours without progress = emergency call. How far along is she?",
      "Before delivery, prepare a clean dry place. **Checklist:**\n- Clean straw bedding\n- Watch udder fill and vulva signs\n- Keep vet number ready\nDue date known?",
    ],
    hi: [
      "गर्भावस्था में शांति, अच्छा चारा, हल्की सैर चाहिए। **ध्यान दें:**\n- आख़िरी 2 माह: रोज़ +500 ग्राम अच्छा दाना\n- रोज़ खनिज मिश्रण\n- बच्चे की तारीख से 2 माह पहले दुहाई बंद करें\n6+ घंटे की प्रसव पीड़ा बिना प्रगति के = आपातकालीन कॉल। कितने महीने की है?",
      "प्रसव से पहले साफ सूखी जगह तैयार रखें। **सूची:**\n- साफ़ पुआल की बिछावनी\n- थन भरना व योनि के संकेत देखें\n- डॉक्टर का नंबर तैयार रखें\nपता है कि कब ब्याएगी?",
    ],
  },
];

const EXTRA_KEYWORDS: { test: RegExp; en: string[]; hi: string[] }[] = [
  {
    test: /wound|injur|cut|घाव|चोट|लहू/i,
    en: [
      "For a fresh wound: **first-aid now**\n- Wash gently with clean water or a weak antiseptic (povidone-iodine diluted to tea colour)\n- Press with a clean cloth to stop bleeding\n- Keep flies away; cover with a soft bandage\nDeep cut, non-stop bleeding or maggots = vet today. How big is the wound?",
      "Wounds heal fast if kept clean and fly-free. **Steps:**\n- Flush with clean water twice daily\n- Apply a vet-approved antiseptic\n- Isolate the animal from mud\nShow me a photo if you can — I'll tell you how serious it looks.",
    ],
    hi: [
      "ताज़ा घाव के लिए: **अभी प्राथमिक इलाज**\n- साफ़ पानी या हल्के बेंजारिस एंटीसेप्टिक (चाय के रंग तक मिलाकर) से धोएँ\n- रक्त रोकने के लिए साफ़ कपड़े से दबाएँ\n- मक्खियाँ न आने दें, नरम पट्टी से ढकें\nगहरा घाव, रुकता हुआ खून न हो या कीड़े लगें तो आज ही डॉक्टर। घाव कितना बड़ा है?",
      "घाव जल्दी भरते हैं अगर साफ़ और मक्खी-मुक्त रहें। **कदम:**\n- दिन में दो बार साफ़ पानी से धोएँ\n- पशु-चिकित्सक स्वीकृत एंटीसेप्टिक लगाएँ\n- पशु को कीचड़ से अलग रखें\nहो सके तो फोटो दिखाइए — गंभीरता बता दूँगा।",
    ],
  },
  {
    test: /breath|cough|saans|सांस|खांसी|खँखार/i,
    en: [
      "Fast or noisy breathing is serious if paired with fever or no eating. **Do:**\n- Move to open airy shade\n- Do NOT force-feed or drench now\n- Note nostril discharge colour\nLaboured breathing (flanks pumping) = emergency, call 1962. Is there fever too?",
      "Cough alone is often dust or weather change. **Watch:**\n- Any discharge from nose?\n- Still eating and ruminating?\n- Temperature normal?\nShare these and I'll guide you.",
    ],
    hi: [
      "तेज़ या शोर वाली सांस — अगर बुखार या भूख-बंद के साथ हो तो गंभीर है। **करें:**\n- खुली हवादार छाँव में ले जाएँ\n- अभी ज़बरदस्ती खाना या दवा न दें\n- नाक से बहने वाले रंग को नोट करें\nपेट उलट-पलट (फ्लैंक) चलाए तो आपातकाल — 1962 पर कॉल करें। बुखार भी है?",
      "केवल खांसी अक्सर धूल या मौसम-बदलाव से होती है। **देखें:**\n- नाक से कुछ बह रहा है?\n- खा रहा है और जुगाली कर रहा है?\n- तापमान सामान्य?\nये बातें बताइए, मैं मार्गदर्शन करूँगा।",
    ],
  },
  {
    test: /deworm|worm|kida|कीड़ा|पेट के कीड़े|कृमि/i,
    en: [
      "Deworming is due every 6 months for most cattle and goats. **Plan:**\n- Deworm calves/kids at 3 months first\n- Rotate the dewormer class yearly (ask vet)\n- Dose by body weight, after morning feed\nSigns of worms: weak, pot belly, pale eyes, dung with specks. Which animal, and last dewormed when?",
      "Worms silently steal 10-20% growth and milk. **Action:**\n- Whole herd same day\n- Clean shed that day, fresh bedding\n- Repeat after 14 days if heavy load\nTell me the herd size — I'll suggest a schedule.",
    ],
    hi: [
      "गाय-बकरी के लिए हर 6 माह में कृमिनाशक देना चाहिए। **योजना:**\n- बछड़े/मेमने को 3 माह की उम्र में पहली बार\n- हर वर्ष दवा की श्रेणी बदलें (वेट से पूछें)\n- सुबह के चारे के बाद, वज़न के हिसाब से खुराक\nलक्षण: कमज़ोरी, फूला पेट, पीली आँखें, गोबर में दाने। कौन-सा पशु, आख़िरी कृमिनाशक कब?",
      "कीड़े चुपके से 10-20% वज़न और दूध चुराते हैं। **कार्य:**\n- पूरे झुंड को एक ही दिन\n- उस दिन लीड़ा साफ़ करें, नया भूसा\n- भारी संक्रमण हो तो 14 दिन बाद दोहराएँ\nझुंड का आकार बताइए — समय-सारणी बना दूँगा।",
    ],
  },
  {
    test: /bloat|gas|phool|अफ़ारा|फूला/i,
    en: [
      "Bloat (left side swollen like a drum) is an emergency. **Immediate:**\n- Walk the animal slowly\n- Rub the left flank firmly\n- 50-100 ml edible oil + hing water can help mild cases\nIf breathing hard or unable to stand — vet NOW. Is the left stomach tight like a drum?",
      "Bloat comes after too much fresh green fodder or grains. **Prevention:**\n- Introduce green fodder gradually\n- Never let animals into lush fields hungry\n- Dry hay before greens\nWhen did it start, and what did it eat today?",
    ],
    hi: [
      "अफ़ारा (बायाँ पेट ढोल की तरह फूला) आपातकाल है। **तुरंत:**\n- पशु को धीरे-धीरे चलाएँ\n- बाएँ पेट को पूरी ताक़त से रगड़ें\n- 50-100 मिली खाद्य तेल + हींग वाला पानी हल्के मामलों में\nसांस भारी हो या खड़ा न हो — तुरंत वेट। बायाँ पेट ढोल जैसा सख्त है?",
      "अफ़ारा अधिक ताज़ा हरे चारे या अनाज से होता है। **बचाव:**\n- हरा चारा धीरे-धीरे शुरू करें\n- हरे खेतों में पशु को भूखा न छोड़ें\n- सूखा घास पहले, हरा बाद में\nकब शुरू हुआ, आज क्या खाया?",
    ],
  },
  {
    test: /chick|poultry|murghi|hen|मुर्गी|चूज़ा|अंडा/i,
    en: [
      "For poultry: **golden rules**\n- Warm, dry, draft-free brooding for chicks (33°C week 1)\n- Clean water 24x7; probiotics on stress days\n- Ranikhet & Gumboro vaccines on schedule (free at govt. camps)\nSudden deaths with bloody droppings = isolate now and call 1962. Broiler, layer or desi birds?",
      "Egg drop in layers? **Check:**\n- 16 hrs light exposure maintained?\n- Calcium (grit/shell) available?\n- Feed unchanged and fresh?\nMost drops trace to these three. What's the flock age?",
    ],
    hi: [
      "मुर्गीपालन के **सुनहरे नियम**\n- चूज़ों के लिए गर्म, सूखी, बिना रोंगटे की जगह (पहले हफ़्ते 33°C)\n- 24x7 साफ़ पानी; तनाव के दिनों में प्रोबायोटिक्स\n- रानीखेत व गुम्बोरो टीके समय पर (सरकारी शिविरों में नि:शुल्क)\nअचानक मौत + खूनी दस्त = तुरंत अलग करें और 1962 पर कॉल करें। ब्रॉयलर, लेयर या देसी?",
      "लेयर में अंडा घटा? **जांचें:**\n- 16 घंटे रोशनी बनी है?\n- कैल्शियम (कंकड़/खोल) उपलब्ध?\n- चारा ताज़ा व अपरिवर्तित?\nज़्यादातर गिरावट इन्हीं तीन से जुड़ी है। झुंड की उम्र क्या है?",
    ],
  },
  {
    test: /goat|bakri|बकरी|बकरा|मेमना/i,
    en: [
      "Goats need dry floors and browse over plain grass. **Basics:**\n- Deworm every 4 months in rainy season\n- PPR vaccine yearly (free under govt. programme)\n- Mineral lick always available\nKids must get colostrum in 2 hours. What question do you have about your goats?",
      "A herd of 5 goats can give a family steady monthly income. **Smart moves:**\n- Sell males at 9-12 months for best price\n- Keep one good buck for 25-30 does\n- Stall-feeding during monsoon cuts deaths sharply\nHow many goats do you keep?",
    ],
    hi: [
      "बकरियों को सूखा फ़र्श और झाड़ी-चारा चाहिए। **मूल बातें:**\n- बारिश के मौसम में हर 4 माह कृमिनाशक\n- PPR टीका हर वर्ष (सरकारी कार्यक्रम में नि:शुल्क)\n- खनिज चट्टा हमेशा उपलब्ध\nमेमनों को 2 घंटे में माँ का पहला दूध ज़रूर मिले। बकरियों के बारे में क्या सवाल है?",
      "5 बकरियों का झुंड हर माह नियमित आय दे सकता है। **चतुर कदम:**\n- नर मेमने 9-12 माह में बेचें — सबसे अच्छा भाव\n- 25-30 मादाओं पर एक अच्छा नर रखें\n- मानसून में बाड़े में चारा देने से मृत्यु बहुत घटती है\nकितनी बकरियाँ रखते हैं?",
    ],
  },
  {
    test: /summer|heat|garmi|गर्मी|लू/i,
    en: [
      "Heat protection plan: **today onwards**\n- Water always in shade, refresh twice daily\n- Feed 70% in morning/evening cool hours\n- Wet the shed roof or use a fan at noon\nA panting cow can lose 3 litres of milk daily. Want a day-wise summer schedule?",
      "Summer steals milk through heat-stress. **Watch for:** open-mouth panting, drooling, grouping near water. **Fix:** shade + 5x water checks + evening bath. Is your shed open on two sides?",
    ],
    hi: [
      "गर्मी की सुरक्षा योजना: **आज से**\n- छाँव में पानी हमेशा, दिन में दो बार बदलें\n- 70% चारा सुबह-शाम ठंडे समय में\n- दोपहर में शेड की छत भिगोएँ या पंखा\nखड़खड़ाती गाय रोज़ 3 लीटर दूध खो सकती है। दिन-प्रतिदिन की ग्रीष्म सूची बनाऊँ?",
      "गर्मी तनाव से दूध चुपके से घटता है। **लक्षण देखें:** मुँह खोलकर हाँफ़ना, लार, पानी के पास जुटना। **उपाय:** छाँव + पानी 5 बार जांचें + शाम को नहलाना। लीड़ा दो तरफ़ खुला है?",
    ],
  },
  {
    test: /rain|monsoon|barish|बारिश|सावन/i,
    en: [
      "Monsoon care: **keep feet and guts safe**\n- Dry, raised bedding; lime powder on wet floor 2x a week\n- Deworm before and after monsoon\n- Avoid waterlogged grazing (foot-rot risk)\n- Chop fodder; mouldy feed = straight to dustbin\nRainy season is when diseases ride in. Is your shed leaking anywhere?",
      "The biggest monsoon killers: wet floors and mouldy feed. **Daily checklist:**\n- Hooves dry and clean (mud traps bacteria)\n- Water trough scrubbed\n- Ticks surge — check ears/neck folds daily\nNeed a tick-control routine?",
    ],
    hi: [
      "मानसून की देखभाल: **खुर और पेट सुरक्षित रखें**\n- सूखी, ऊँची बिछावनी; गीले फ़र्श पर चूना पाउडर हफ़्ते में 2 बार\n- बारिश से पहले और बाद में कृमिनाशक\n- पानी भरे मैदान में न चराएँ (खुर सड़न का ख़तरा)\n- फफूंदी वाला चारा सीधे कूड़े में\nबारिश में रोग सवारी करके आते हैं। कहीं से लीड़ा टपकता तो नहीं?",
      "बारिश के सबसे बड़े दुश्मन: गीला फ़र्श और फफूंदी वाला चारा। **दैनिक सूची:**\n- खुर सूखे-साफ़ (कीचड़ में जीवाणु)\n- पानी के कटोरे रोज़ रगड़ें\n- किलनी बढ़ती है — कान व गर्दन की सिलवट रोज़ देखें\nकिलनी नियंत्रण की दिनचर्या बताऊँ?",
    ],
  },
  {
    test: /winter|cold|sardi|सर्दी|ठंड/i,
    en: [
      "Winter care: **warmth saves energy = saves milk**\n- Close drafts at night; dry thick bedding\n- Lukewarm water for drinkers\n- Add 100-200g extra concentrate for thin animals\nNewborn calves need rugs below 10°C. How cold is it at your place?",
      "Cold nights cut milk quietly. **Do:**\n- Feed extra grain in the evening (keeps rumen warm)\n- Block the north wind with a simple plastic sheet\n- Fresh straw nightly for calves\nWant a night-time checklist?",
    ],
    hi: [
      "सर्दी की देखभाल: **गर्माहट ऊर्जा बचाती है = दूध बचता है**\n- रात में हवा-रोक; सूखी मोटी बिछावनी\n- पीने के लिए हल्का गुनगुना पानी\n- दुबले पशुओं को 100-200 ग्राम अतिरिक्त दाना\n10°C से नीचे नवजात बछड़ों को कम्बल चाहिए। आपके यहाँ कितनी ठंड है?",
      "ठंडी रातें चुपके से दूध घटाती हैं। **करें:**\n- शाम को अतिरिक्त अनाज (जठर गर्म रहता है)\n- उत्तरी हवा के लिए सादा प्लास्टिक आवरण\n- बछड़ों के लिए रोज़ ताज़ा पुआल\nरात्रि की जाँच-सूची बना दूँ?",
    ],
  },
  {
    test: /feed|fodder|chara|चारा|पोषण|khurak|दाना/i,
    en: [
      "Rule of thumb: **a cow needs dry matter ≈ 2.5-3% of body weight daily.** For a 400kg cow: 10-12 kg dry feed — mix of green fodder, dry hay and 2-4 kg concentrate when milking. \n- Always mineral mixture 50g + clean water\n- Change feed gradually over 7 days\nWhat's your animal's weight and milk output?",
      "Feed like a business: **milk pays for the dana.**\n- 1 kg concentrate per 2.5 litres of milk (rough guide)\n- Never skip mineral mixture — fertility depends on it\n- Silage and azolla cut costs 20-30%\nWhich animal are you feeding?",
    ],
    hi: [
      "अंगूठे का नियम: **गाय को रोज़ शरीर के वज़न के 2.5-3% शुष्क चारा चाहिए।** 400 किलो की गाय = 10-12 किलो शुष्क चारा — हरा चारा, सूखा घास और दुहाई में 2-4 किलो दाना।\n- हमेशा 50 ग्राम खनिज मिश्रण + साफ़ पानी\n- चारा 7 दिन में धीरे-धीरे बदलें\nपशु का वज़न और दूध कितना है?",
      "व्यापार की तरह चारा दें: **दाना दूध से वसूलता है।**\n- लगभग 2.5 लीटर दूध पर 1 किलो दाना\n- खनिज मिश्रण कभी न छोड़ें — गर्भधारण इसी पर टिका\n- साइलेज व अज़ोला लागत 20-30% घटाते हैं\nकिस पशु को चारा दे रहे हैं?",
    ],
  },
  {
    test: /calf|bachhda|बछड़ा|बछिया/i,
    en: [
      "Calf care golden window — **first 60 days decide lifetime yield:**\n- Colostrum within 2 hours of birth\n- Navel dipped in iodine tincture\n- Deworm at 3 months, vaccinate as scheduled\n- Starter grain from week 3\nIs your calf drinking milk normally?",
      "Weak calf? **Check three things:** colostrum received? Navel infection? Warm and dry sleeping spot? Fix these and 90% of calf problems disappear. How old is the calf?",
    ],
    hi: [
      "बछड़े की देखभाल — **पहले 60 दिन पूरी ज़िंदगी की उपज तय करते हैं:**\n- जन्म के 2 घंटे में खीस\n- नाभि में आयोडीन टिंक्चर\n- 3 माह में कृमिनाशक, टीके समय पर\n- 3वें हफ़्ते से स्टार्टर दाना\nबछड़ा दूध ठीक से पी रहा है?",
      "कमज़ोर बछड़ा? **तीन बातें देखें:** खीस मिला? नाभि में संक्रमण? सोने की जगह गर्म-सूखी? ये ठीक करें — 90% समस्याएँ ख़त्म। बछड़ा कितने दिन का है?",
    ],
  },
  {
    test: /masiti|udder|than|थन|आदर/i,
    en: [
      "Hot, hard or painful udder points to mastitis. **Act fast:**\n- Milk out fully every 4-6 hours\n- Hot fomentation 10 minutes, 3x daily\n- Clean teat dip after milking\nIf fever or clots in milk — antibiotics need a vet (milk discard period applies). Is milk normal in colour?",
      "Mastitis silently halves milk. **Prevention beats cure:**\n- Wash + dry udder before every milking\n- Milk affected quarter last\n- Wash hands between animals\nHow long has the udder been hard?",
    ],
    hi: [
      "थन का गर्म-सख्त या दर्दनाक होना थनैला का संकेत है। **तुरंत करें:**\n- हर 4-6 घंटे में दूध पूरा निकालें\n- गर्म सिंकाई 10 मिनट, दिन में 3 बार\n- दुहाई के बाद थन साफ़ करके डिप लगाएँ\nबुखार या दूध में गांठ हो तो एंटीबायोटिक के लिए वेट चाहिए। दूध का रंग सामान्य है?",
      "थनैला चुपके से दूध आधा कर देता है। **बचाव ही इलाज:**\n- हर दुहाई से पहले थन धोकर पौंछें\n- पीड़ित थन सबसे आख़िर में दुहें\n- हर पशु के बीच हाथ धोएँ\nथन कब से सख्त है?",
    ],
  },
  {
    test: /dog|billing|billing?|kutta|कुत्ता|bite|काटा/i,
    en: [
      "Animal bite wound: **don't waste time**\n- Wash 10 minutes under running water with soap\n- Povidone-iodine dressing\n- Rabies risk is real — vet + vaccine decision the same day\nWas it a dog bite, and is the animal vaccinated?",
      "If a stray bites your livestock, the wound itself is only half the danger. Rabies has no cure after symptoms. **Same-day vet visit is non-negotiable.** Tell me which animal and when it happened.",
    ],
    hi: [
      "पशु काटने पर: **समय न खोएँ**\n- साबुन और बहते पानी से 10 मिनट धोएँ\n- पोविडोन-आयोडीन ड्रेसिंग\n- रेबीज़ का ख़तरा सच्चा है — उसी दिन वेट + टीके का फ़ैसला\nकुत्ते ने काटा था? पशु का टीकाकरण हुआ है?",
      "अगर आवारा कुत्ता पशु को काटे, घाव आधा ख़तरा है। लक्षण आने के बाद रेबीज़ का इलाज नहीं। **उसी दिन वेट के पास जाना अनिवार्य है।** बताइए कौन-सा पशु और कब हुआ।",
    ],
  },
];

const GENERIC_TIPS = {
  en: [
    "**Water beats feed.** A lactating cow needs 60-80 litres of clean water daily in summer. Keep two buckets always available — milk can rise by 10% with better water alone.",
    "**Mineral mix is a silent profit lever.** 50-60g of good mineral mixture daily can improve fertility and milk yield within a month.",
    "**Fixed milking times matter.** Milking at the same hour, twice daily, keeps hormones stable and yield higher. Even 1 hour of timing change can drop milk.",
    "**Shade adds milk.** Providing simple shade can add 1-2 litres per day in hot months — heat stress is a silent thief.",
    "**Colostrum first.** A newborn calf must get the mother's first milk within 2 hours — it carries immunity that no vaccine can replace.",
    "**Clean shed, healthy udder.** Wash the udder before milking with plain water and dry with a clean cloth — it halves infection risk.",
    "**Turn fodder into silage during surplus.** Cheap insurance for lean months when green fodder vanishes.",
  ],
  hi: [
    "**पानी चारे से भी ज़रूरी है।** दूध देने वाली गाय को गर्मी में रोज़ 60-80 लीटर साफ़ पानी चाहिए। दो बाल्टी हमेशा उपलब्ध रखें — केवल बेहतर पानी से दूध 10% तक बढ़ सकता है।",
    "**खनिज मिश्रण छुपा मुनाफ़ा है।** रोज़ 50-60 ग्राम अच्छा खनिज मिश्रण एक महीने में गर्भधारण और दूध दोनों सुधार सकता है।",
    "**दुहाई का समय तय रखें।** हर रोज़ एक ही समय, दो बार दुहाई करने से हार्मोन संतुलित रहते हैं और उपज बढ़ती है। 1 घंटे का फेरबदल भी दूध घटा सकता है।",
    "**छाँव दूध बढ़ाती है।** साधारण छाँव गर्म महीनों में रोज़ 1-2 लीटर दूध दुबारा ला सकती है — गर्मी का तनाव चुप चोर है।",
    "**पहला दूध पहले।** नवजात बछड़े को 2 घंटे के भीतर माँ का पहला दूध (खीस) ज़रूर मिले — यह प्रतिरक्षा कोई टीका नहीं दे सकता।",
    "**साफ लीड़ा, स्वस्थ थन।** दुहाई से पहले थन सादे पानी से धोकर साफ़ कपड़े से पोंछें — संक्रमण का ख़तरा आधा हो जाता है।",
    "**सरप्लस में चारे का साइलेज बनाएँ।** सूखे महीनों के लिए सस्ती बीमा, जब हरा चारा मिलना बंद हो जाता है।",
  ],
};

const GENERIC_ANSWERS = {
  en: [
    "**Let me help you.** For livestock, the basics decide <u>80%</u> of health: *clean water, dry shed, balanced feed, timely vaccines.*\nCould you describe what you're seeing — appetite, dung, milk, body warmth? I'll pinpoint what to do.",
    "**Tell me a little more.** Which animal, since when, and any change in eating or milk? The more detail you share, the sharper my advice gets.",
    "**A golden rule for every farmer:** watch the *three daily signals* — eating, ruminating (cud-chewing), and dung. Change in any two for over a day = call a vet (helpline <u>1962</u>, free).\nWhat's happening with your animal?",
  ],
  hi: [
    "**मैं आपकी मदद करता हूँ।** पशुओं में <u>80%</u> स्वास्थ्य मूल बातों से ठीक होता है: *साफ़ पानी, सूखा मकान, संतुलित चारा, समय पर टीके।*\nबताइए आप क्या देख रहे हैं — भूख, गोबर, दूध, शरीर की गर्मी? मैं सटीक उपाय बताऊँगा।",
    "**थोड़ा और बताइए।** कौन-सा पशु है, कब से है, और खाने-दूध में कोई बदलाव? जितनी जानकारी देंगे, उतनी सटीक सलाह मिलेगी।",
    "**हर किसान का सुनहरा नियम:** *रोज़ के तीन संकेत* देखें — खाना, जुगाली और गोबर। कोई दो एक दिन से ज्यादा बदलें तो डॉक्टर को बुलाएँ (हेल्पलाइन <u>1962</u>, नि:शुल्क)।\nआपके पशु के साथ क्या हो रहा है?",
  ],
};

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** Choose a reply that has not already been used in this conversation. */
function pickFresh(arr: string[], history: ChatMsg[]): string {
  const used = new Set(
    history.filter((m) => m.role === "assistant").map((m) => m.content.trim().slice(0, 60))
  );
  const unused = arr.filter((a) => !used.has(a.trim().slice(0, 60)));
  return unused.length > 0 ? pick(unused) : pick(arr);
}


/* ---------- clinical draft fallback (offline / model unreachable) ---------- */
function localVetDraft(body: AiBody): string {
  const src = (body.context || "") + " " + (body.messages || []).map((m) => m.content).join(" ");
  const has = (re: RegExp) => re.test(src);
  const hi = body.lang === "hi";

  let cond = hi ? "*सामान्य संक्रमण या पोषण असंतुलन*" : "a *general infection or nutritional imbalance*";
  let care: string[] = [];
  let tx: string[] = [];

  if (has(/udder|mastit|थन|clot|swollen/i)) {
    cond = hi ? "*थनैला (मैस्टाइटिस)*" : "*mastitis*";
    care = hi
      ? ["प्रभावित थन हर <u>4-6 घंटे</u> में पूरी तरह दुहें", "गर्म सिंकाई <u>10 मिनट</u>, दिन में <u>3 बार</u>", "दुहाई के बाद थन डिप लगाएँ; प्रभावित थन <u>सबसे आख़िर</u> में दुहें", "साफ़ सूखी बिछावनी, दिन में <u>2 बार</u> बदलें"]
      : ["Strip the affected quarter completely every <u>4-6 hours</u>", "Warm fomentation for <u>10 minutes</u>, <u>3 times</u> daily", "Post-milking teat dip; milk the affected quarter <u>last</u>", "Clean dry bedding, changed <u>twice</u> daily"];
    tx = hi
      ? ["*इंट्रामैमरी एंटीबायोटिक* — खुराक उपस्थित चिकित्सक द्वारा वज़न के अनुसार तय हो", "सूजन के लिए *NSAID*; <u>दूध निकासी अवधि</u> का पालन अनिवार्य"]
      : ["*Intramammary antibiotic* — dose to be confirmed by the attending veterinarian by body weight", "*NSAID* for inflammation; observe the <u>milk withdrawal period</u> strictly"];
  } else if (has(/diarr|loose|dung|दस्त|scour/i)) {
    cond = hi ? "*आंत्रशोथ / दस्त*" : "*enteritis / scours*";
    care = hi
      ? ["ORS: <u>1 लीटर</u> पानी + <u>6 चम्मच</u> चीनी + <u>½ चम्मच</u> नमक, दिन में <u>4 बार</u>", "<u>12 घंटे</u> हरा चारा रोकें, सूखा भूसा दें", "प्रभावित पशु को <u>अलग</u> रखें", "फ़र्श साफ़ कर चूना डालें"]
      : ["Oral rehydration: <u>1 litre</u> water + <u>6 tsp</u> sugar + <u>½ tsp</u> salt, <u>4 times</u> daily", "Withhold green fodder for <u>12 hours</u>; offer dry roughage", "<u>Isolate</u> affected animals from the herd", "Disinfect the floor and apply lime"];
    tx = hi
      ? ["निर्जलीकरण गंभीर हो तो *द्रव चिकित्सा*", "गोबर जाँच के बाद ही *कृमिनाशक / एंटीबायोटिक*; खुराक चिकित्सक तय करें"]
      : ["*Fluid therapy* if dehydration is moderate to severe", "*Anthelmintic / antibiotic* only after faecal examination; dosing by the attending veterinarian"];
  } else if (has(/fever|बुखार|temperature|not eating|भूख/i)) {
    cond = hi ? "*ज्वर सहित भूख न लगना*" : "*febrile illness with inappetence*";
    care = hi
      ? ["छाँव और हवादार जगह; <u>साफ़ पानी</u> हमेशा उपलब्ध", "गीले कपड़े से <u>10 मिनट</u> शरीर पोंछें", "नरम हरा चारा व गुड़ का पानी; ज़बरदस्ती न खिलाएँ", "सुबह-शाम तापमान लिखें (सामान्य <u>101.5-102.5°F</u>)"]
      : ["Shade and ventilation; <u>clean water</u> available at all times", "Sponge the body with a wet cloth for <u>10 minutes</u>", "Soft green fodder and jaggery water; do not force-feed", "Record temperature morning and evening (normal <u>101.5-102.5°F</u>)"];
    tx = hi
      ? ["*एंटीपायरेटिक / NSAID* — खुराक वज़न अनुसार चिकित्सक तय करें", "जीवाणु संक्रमण का संदेह हो तो *एंटीबायोटिक*; <u>दूध निकासी अवधि</u> ध्यान रखें"]
      : ["*Antipyretic / NSAID* — dose confirmed by the attending veterinarian by body weight", "*Antibiotic* if bacterial infection is suspected; note the <u>milk withdrawal period</u>"];
  } else if (has(/limp|hoof|foot|खुर|लंगड़/i)) {
    cond = hi ? "*खुर सड़न / पाद संक्रमण*" : "*foot-rot / hoof infection*";
    care = hi
      ? ["खुर साफ़ पानी से धोकर <u>पूरी तरह सुखाएँ</u>", "<u>10%</u> ज़िंक सल्फेट फुट-बाथ, <u>5 मिनट</u>", "सूखी ऊँची जगह पर रखें; कीचड़ से दूर", "गीले फ़र्श पर हफ़्ते में <u>2 बार</u> चूना"]
      : ["Wash the hoof with clean water and <u>dry it completely</u>", "<u>10%</u> zinc sulphate foot-bath for <u>5 minutes</u>", "House on dry raised ground, away from mud", "Lime on wet flooring <u>twice</u> weekly"];
    tx = hi
      ? ["घाव की सफ़ाई के बाद *सामयिक एंटीसेप्टिक*", "गहरा संक्रमण हो तो *प्रणालीगत एंटीबायोटिक*; खुराक चिकित्सक तय करें"]
      : ["*Topical antiseptic* after debridement", "*Systemic antibiotic* if infection is deep; dosing by the attending veterinarian"];
  } else if (has(/hen|poultry|bird|मुर्ग|died suddenly|sudden death/i)) {
    cond = hi ? "*तीव्र संक्रामक कुक्कुट रोग (रानीखेत का संदेह)*" : "*an acute infectious poultry disease (Ranikhet suspected)*";
    care = hi
      ? ["मृत पक्षियों को <u>तुरंत</u> हटाकर गहरा दफ़नाएँ", "बीमार पक्षी <u>अलग</u> करें; झुंड की आवाजाही रोकें", "पीने के पानी में *इलेक्ट्रोलाइट + विटामिन*", "बाड़े में <u>रोज़</u> कीटाणुनाशक"]
      : ["Remove and deep-bury dead birds <u>immediately</u>", "<u>Isolate</u> sick birds; stop all flock movement", "*Electrolytes + vitamins* in drinking water", "Disinfect the shed <u>daily</u>"];
    tx = hi
      ? ["स्वस्थ पक्षियों को *रानीखेत टीका* (पशुपालन विभाग से)", "पोस्टमॉर्टम व प्रयोगशाला पुष्टि की सलाह"]
      : ["*Ranikhet vaccination* for healthy birds (via the animal husbandry department)", "Post-mortem and laboratory confirmation advised"];
  } else {
    care = hi
      ? ["<u>साफ़ पानी</u> और सूखी बिछावनी सुनिश्चित करें", "भूख, जुगाली और गोबर <u>दिन में 2 बार</u> देखें", "प्रभावित पशु को झुंड से <u>अलग</u> रखें"]
      : ["Ensure <u>clean water</u> and dry bedding", "Monitor appetite, rumination and dung <u>twice daily</u>", "<u>Isolate</u> affected animals from the herd"];
    tx = hi
      ? ["लक्षणों की पुष्टि के बाद ही दवा; खुराक वज़न अनुसार चिकित्सक तय करें"]
      : ["Medicate only after confirming the signs; dose by body weight, decided by the attending veterinarian"];
  }

  const watch = hi
    ? ["पशु खड़ा न हो पा रहा हो या बेहोश लगे", "साँस बहुत तेज़ या मुँह खोलकर हाँफ़ना", "<u>24 घंटे</u> से पानी भी न पीना, या खून दिखना"]
    : ["The animal cannot stand or appears collapsed", "Very rapid or open-mouth breathing", "No water intake for <u>24 hours</u>, or any bleeding"];
  const prev = hi
    ? ["समय पर टीकाकरण और हर <u>6 माह</u> कृमिनाशक", "<u>48-72 घंटे</u> में पुनः जाँच; सुधार न हो तो व्यक्तिगत भ्रमण"]
    : ["Keep vaccination current and deworm every <u>6 months</u>", "Re-check in <u>48-72 hours</u>; arrange a physical visit if there is no improvement"];

  const H = hi
    ? ["**आकलन**", "**तुरंत देखभाल (अगले 24 घंटे)**", "**उपचार टिप्पणी**", "**इन पर नज़र रखें — तुरंत बुलाएँ यदि**", "**रोकथाम / अनुवर्ती**"]
    : ["**Assessment**", "**Immediate Care (next 24 hours)**", "**Treatment Notes**", "**Watch For — Call Immediately If**", "**Prevention / Follow-up**"];

  const intro = hi
    ? `किसान द्वारा बताए गए लक्षण ${cond} की ओर संकेत करते हैं। पुष्टि के लिए शारीरिक परीक्षण आवश्यक है।`
    : `The signs described by the farmer are consistent with ${cond}. Physical examination is required for confirmation.`;

  return [
    H[0], intro, "",
    H[1], ...care.map((x) => "- " + x), "",
    H[2], ...tx.map((x) => "- " + x), "",
    H[3], ...watch.map((x) => "- " + x), "",
    H[4], ...prev.map((x) => "- " + x),
  ].join("\n");
}

function localReply(body: AiBody): string {
  const lang = body.lang === "hi" ? "hi" : body.lang === "en" ? "en" : "auto";
  const lastUser = [...(body.messages || [])].reverse().find((m) => m.role === "user")?.content || "";
  const devanagari = /[ऀ-ॿ]/.test(lastUser);
  const useLang: "en" | "hi" = lang === "auto" ? (devanagari ? "hi" : "en") : lang;

  const hist = body.messages || [];
  const usedTexts = hist.filter((m) => m.role === "assistant").map((m) => m.content);

  if (body.mode === "vetdraft") return localVetDraft(body);
  if (body.mode === "tip") return pickFresh(GENERIC_TIPS[useLang], hist);
  if (body.mode === "care") {
    // Parse species + weather from the context the client sends.
    let ctx: { animalSpecies?: string; temperatureC?: number; humidityPct?: number; windKmh?: number; precipitationMm?: number } = {};
    try { ctx = JSON.parse(body.context || "{}"); } catch { /* ignore */ }
    const species = (ctx.animalSpecies || "").toLowerCase() || "animal";
    const T = Math.round(ctx.temperatureC ?? 30);
    const H = ctx.humidityPct ?? 50;
    const W = Math.round(ctx.windKmh ?? 0);
    const rain = ctx.precipitationMm ?? 0;
    const hot = T >= 33; const cold = T <= 12; const wet = rain > 1;
    const hi = useLang === "hi";

    const isCattle = ["cow", "cows", "buffalo", "buffaloes", "ox", "oxen"].includes(species);
    const isGoat = ["goat", "goats"].includes(species);
    const isSheep = ["sheep", "lamb", "lambs"].includes(species);
    const isPoultry = ["hen", "hens", "chicken", "duck", "ducks"].includes(species);
    const isPig = ["pig", "pigs"].includes(species);
    const isEquine = ["horse", "horses", "donkey", "donkeys"].includes(species);

    const lines: string[] = [];
    lines.push(hi ? `**${species} — आज का मौसम और देखभाल**` : `**${species} — care for today's weather**`);
    lines.push(hi ? `अभी <u>${T}°C</u>, नमी <u>${H}%</u>, हवा <u>${W} किमी/घंटा</u>।` : `Current: <u>${T}°C</u>, humidity <u>${H}%</u>, wind <u>${W} km/h</u>.`);
    lines.push("");

    if (hot) {
      if (species === "buffalo") {
        lines.push(hi ? "- भैंस गर्मी सबसे ज़्यादा महसूस करती है; <u>38°C</u> से ऊपर पानी में खड़ा करें या दिन में <u>2 बार</u> नहलाएँ" : "- Buffaloes overheat fastest; above <u>38°C</u> let them wallow or spray <u>twice daily</u>");
        lines.push(hi ? "- साफ़ ठंडा पानी <u>हर 3 घंटे</u> बदलें; दूध <u>20-30%</u> गिर सकता है" : "- Refresh cool water <u>every 3 hours</u>; milk can drop <u>20-30%</u> in extreme heat");
      } else if (isCattle) {
        lines.push(hi ? "- गाय/बैल को छाँव में रखें; <u>11-4</u> बजे बाहर न निकालें" : "- Keep cattle in shade; avoid sun <u>11am-4pm</u>");
        lines.push(hi ? "- दूध देने वाली गाय को <u>60-80 लीटर/दिन</u> साफ़ पानी चाहिए" : "- A lactating cow needs <u>60-80 litres/day</u> of clean water");
      } else if (isGoat) {
        lines.push(hi ? "- बकरी दोपहर की धूप बर्दाश्त नहीं करती; छाँव में बाँधें" : "- Goats cannot tolerate midday sun; tie them in shade");
        lines.push(hi ? "- हरा चारा (नीम, बेर) सुबह-शाम दें; साफ़ पानी <u>3-4 बार</u>" : "- Offer green browse (neem, ber) morning-evening; clean water <u>3-4 times</u>");
      } else if (isSheep) {
        lines.push(hi ? "- भेड़ की ऊन गर्मी में तकलीफ बढ़ाती है; <u>कतरनी</u> करवाएँ अगर नहीं हुई" : "- Sheep wool traps heat; <u>shear</u> if not done already");
        lines.push(hi ? "- छाँव और ताज़ा पानी <u>4 बार/दिन</u>" : "- Shade and fresh water <u>4 times/day</u>");
      } else if (isPoultry) {
        lines.push(hi ? "- बाड़े में पंखा लगाएँ; <u>40°C</u> से ऊपर मुर्गियाँ हाँफ़ती हैं" : "- Fan the shed; hens start panting above <u>40°C</u>");
        lines.push(hi ? "- पानी में *इलेक्ट्रोलाइट* मिलाएँ; <u>हर 2 घंटे</u> ताज़ा पानी" : "- Add *electrolytes* to water; refresh <u>every 2 hours</u>");
        lines.push(hi ? "- अंडा उत्पादन <u>10-20%</u> गिर सकता है; <u>कैल्शियम</u> बढ़ाएँ" : "- Egg production can drop <u>10-20%</u>; increase <u>calcium</u>");
      } else if (isPig) {
        lines.push(hi ? "- सूअर पसीना नहीं बहा सकते; कीचड़-स्नान या पानी छिड़काव ज़रूरी" : "- Pigs cannot sweat; provide a mud wallow or spray water");
      } else if (isEquine) {
        lines.push(hi ? "- काम का बोझ <u>आधा</u> करें; सुबह और शाम ही काम कराएँ" : "- Halve the workload; work only early morning and evening");
      } else {
        lines.push(hi ? "- छाँव और ठंडा पानी ज़रूरी" : "- Shade and cool water are essential");
      }
    } else if (cold) {
      if (isCattle) {
        lines.push(hi ? "- रात में बाड़ा बंद करें; सूखी मोटी बिछावनी दें" : "- Close the shed at night; give thick dry bedding");
        lines.push(hi ? "- पानी <u>गुनगुना</u> करें; ठंडा पानी दूध <u>10-15%</u> घटाता है" : "- Offer <u>lukewarm</u> water; cold water cuts milk by <u>10-15%</u>");
      } else if (isGoat) {
        lines.push(hi ? "- बकरी सर्दी में ज़्यादा कमज़ोर होती है; अतिरिक्त आश्रय और दाना दें" : "- Goats are more cold-sensitive than sheep; give extra shelter and concentrate");
      } else if (isSheep) {
        lines.push(hi ? "- भेड़ की ऊन सर्दी से बचाती है लेकिन मेमनों को <u>हीट लैंप</u> चाहिए" : "- Sheep wool insulates but lambs need a <u>heat lamp</u>");
      } else if (isPoultry) {
        lines.push(hi ? "- बाड़े में गर्मी बनाएँ; <u>18°C</u> से नीचे अंडा गिरता है; रोशनी <u>16 घंटे</u> रखें" : "- Keep shed warm; egg production drops below <u>18°C</u>; maintain <u>16h</u> of light");
      } else if (isPig) {
        lines.push(hi ? "- छोटे सूअरों के लिए <u>हीट लैंप</u>; सूखी बिछावनी ज़रूरी" : "- Use a <u>heat lamp</u> for piglets; dry bedding is essential");
      } else {
        lines.push(hi ? "- सूखी बिछावनी और गुनगुना पानी" : "- Dry bedding and lukewarm water");
      }
    } else {
      lines.push(hi ? "- मौसम अनुकूल है — सामान्य दिनचर्या रखें" : "- Weather is comfortable — keep the normal routine");
      if (isCattle) lines.push(hi ? "- <u>50g</u> खनिज मिश्रण रोज़ दें" : "- Give <u>50g</u> mineral mix daily");
      else if (isPoultry) lines.push(hi ? "- पानी साफ़ रखें, बाड़ा हवादार" : "- Keep water clean, shed ventilated");
    }

    if (wet) {
      if (isCattle || isGoat || isSheep) lines.push(hi ? "- बारिश: खुर सूखे रखें, गीले फ़र्श पर *चूना* डालें" : "- Rain: keep hooves dry, spread *lime* on wet floors");
      if (isPoultry) lines.push(hi ? "- बारिश: बिछावनी सूखी रखें; गीली से *श्वास रोग* बढ़ता है" : "- Rain: keep litter dry; wet litter → *respiratory disease*");
      if (isPig) lines.push(hi ? "- बारिश: बाड़ा पानी न भरे; *त्वचा संक्रमण* का ख़तरा" : "- Rain: prevent flooding; risk of *skin infections*");
      if (isGoat) lines.push(hi ? "- बकरी को भीगने से बचाएँ — ये बारिश बर्दाश्त नहीं करतीं" : "- Goats hate getting wet — keep them under cover in rain");
    }
    if (H >= 70 && !wet) lines.push(hi ? "- नमी ज़्यादा: हवा बहाव बढ़ाएँ, किलनी-मक्खी जाँचें" : "- High humidity: increase airflow, check ticks and flies daily");
    if (W >= 25) lines.push(hi ? "- तेज़ हवा: बाड़े में आड़ लगाएँ" : "- Strong wind: add wind-breaks to the shed");

    lines.push("");
    lines.push(hi ? `और कुछ पूछना हो ${species} के बारे में — बताइए!` : `Any other question about your ${species}? Just ask!`);
    return lines.join("\n");
  }

  const livestockTopic = isLivestockQuestion(lastUser);

  if (body.image) {
    if (livestockTopic) {
      const base = localAnswer(lastUser || (useLang === "hi" ? "मेरे पशु की फोटो" : "my animal photo"), useLang, usedTexts);
      return useLang === "hi"
        ? `${base}

*नोट:* लाइव फोटो-जाँच अभी उपलब्ध नहीं है, इसलिए यह जवाब आपके लिखे हुए विवरण और ऑफलाइन पशु-ज्ञान पर आधारित है।`
        : `${base}

*Note:* Live image inspection is unavailable right now, so this answer is based on your written description and offline livestock knowledge.`;
    }
    return offlineOffTopicReply(lastUser || (useLang === "hi" ? "इस फोटो में क्या है" : "what is in this image"), useLang);
  }

  if (livestockTopic) {
    for (const k of [...EXTRA_KEYWORDS, ...KEYWORDS]) {
      if (k.test.test(lastUser)) return pickFresh(k[useLang], hist);
    }
    return localAnswer(lastUser, useLang, usedTexts);
  }

  return offlineOffTopicReply(lastUser, useLang);
}

export async function POST(req: NextRequest) {
  const requestId = crypto.randomUUID();
  let body: AiBody;
  try {
    body = (await req.json()) as AiBody;
  } catch {
    return NextResponse.json(
      { reply: "Invalid request.", source: "error", requestId },
      { status: 400 }
    );
  }
  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    body.messages = [{ role: "user" as const, content: "Hello" }];
  }
  body.messages = body.messages
    .filter((m) => m && (m.role === "user" || m.role === "assistant"))
    .map((m) => ({ role: m.role, content: String(m.content || "").slice(0, 12000) }))
    .slice(-14);

  const live = await callOpenRouter(body);
  if (live) {
    return NextResponse.json({
      reply: live.text,
      source: "live",
      model: live.model,
      grounded: live.grounded,
      limitedMode: false,
      requestId,
    });
  }

  // If live AI is unavailable, fall back to the offline livestock-only contract.
  return NextResponse.json({
    reply: localReply(body),
    source: "local",
    grounded: false,
    limitedMode: body.appMode !== "offline",
    requestId,
  });
}
